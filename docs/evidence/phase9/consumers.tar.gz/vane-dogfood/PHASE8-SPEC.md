Here is the result of "fetch" for the Page with URL https://app.notion.com/p/3d251cfc265c81ec965fc7a54f78b8d8 as of 2026-10-08T01:04:05.266Z:
<page url="https://app.notion.com/p/3d251cfc265c81ec965fc7a54f78b8d8">
<ancestor-path>
<parent-data-source url="collection://b060dc02-fe6c-4d2c-b78e-fa6d49fa2e34" name="Roadmap de implementação"/>
<ancestor-2-database url="https://app.notion.com/p/f0108bab4632438e8e3e9d70a0c157f7" title="Roadmap de implementação"/>
<ancestor-3-page url="https://app.notion.com/p/3cc51cfc265c816f9d14d5890e5e1ab8" title="Implementação"/>
<ancestor-4-page url="https://app.notion.com/p/3ca51cfc265c81ecaad1e42b047ed79f" title="Entity Event"/>
<ancestor-5-data-source url="collection://607e352a-28c9-46fe-a73a-e9b4c0034cc4" name="Projetos"/>
<ancestor-6-database url="https://app.notion.com/p/106c86b2064a4ebd843549896a479720" title=""/>
<ancestor-7-page url="https://app.notion.com/p/224ea83977114386b97c93270f9ec861" title="Projetos"/>
</ancestor-path>
<properties>
{"Evidência":"https://app.notion.com/p/3d251cfc265c814d86e1df25ff45e238","Fase":"Fase 8","Item":"Fase 8 — DevXP & Dogfood","Notas":"Validar adoção real a partir de projetos externos, documentação pública, PostgreSQL real e Moto para mocks AWS. Três domínios: simples, commerce e reservation.","Prioridade":"P0","Requisitos do PRD":"VR-DX-001–008; VR-LOCAL-001–006; Definition of Done da Fase 8","Status":"Backlog","url":"https://app.notion.com/p/3d251cfc265c81ec965fc7a54f78b8d8","Área":"Documentação","Última edição":"2026-10-08T01:04:05.266Z"}
</properties>
<iconMetadata>null</iconMetadata>
<content>
# Missão
Provar que alguém consegue usar Vane como framework, não como código-fonte conhecido pelo autor.
# Gate
- [ ] 3 apps externas ao repo do framework;
- [ ] dependência instalada via tarball/package, sem workspace linking;
- [ ] quickstart seguido literalmente;
- [ ] PostgreSQL 16 real;
- [ ] Moto Server para AWS mocks aplicáveis;
- [ ] ao menos um caso ACL + Saga + compensation/retry;
- [ ] ao menos um caso concorrência + restart/recovery;
- [ ] zero blockers P0/P1 de adoção;
- [ ] todas as fricções classificadas e resolvidas/aceitas;
- [ ] nenhum pivô conceitual pendente.
# Especificação executável dos dogfoods — baseline PR #14
Atualização em <mention-date start="2026-10-07"/>. **Estado: especificação preparada; execução dos três dogfoods ainda pendente. Status da Fase 8 permanece Backlog.** Os gates acima continuam desmarcados.
## 1. Reconciliação da evidência
[PR #14 — Complete Phase 7 conformance contracts and remaining evidence](https://github.com/Caleul/vane/pull/14): aberta, draft e não mergeada na consulta. Head `3465e6c60353796d880022d09f6771d2f46509fe`; árvore verificada `7dd8c72e53f4f5452507a6ac74d1730fba2100c8`.
[CI 36730968855](https://github.com/Caleul/vane/actions/runs/36730968855), executada em <mention-date start="2026-09-30"/>: jobs verify, postgres-integration e conformance concluídos com success, confirmados pela API do GitHub.
A descrição registra 107/107 casos independentes, 161 requisitos PASS, 0 FAIL, 0 GAP e 1 N/A explícito para distribuição produtiva futura; registra container gerado real executando Order/Payment/SSE contra PostgreSQL. [JSON de evidência da CI](https://github.com/Caleul/vane/actions/runs/36730968855/artifacts/11104492961). Os totais foram reconciliados com a descrição; esta atualização não reexecutou a suíte nem auditou novamente cada resultado do JSON.
O trecho de validação local da PR registra 106 PASS + 1 GAP de Docker; a execução posterior da CI resolve esse GAP ambiental para a árvore identificada. Não tratar os dois registros como resultados concorrentes da mesma execução.
[Findings na revisão exata](https://github.com/Caleul/vane/blob/3465e6c60353796d880022d09f6771d2f46509fe/docs/conformance-findings.md) explicita que a referência Sales/Billing instalada por tarball valida a baseline original, não os projetos externos da Fase 8; Moto e release não fazem parte daquela mudança.
<table header-row="true">
<tr>
<td>Evidência reutilizável</td>
<td>Nova obrigação da Fase 8</td>
</tr>
<tr>
<td>DSL/tipos, Rules, owner-only, contratos Event/View/Saga e controles negativos.</td>
<td>Expressar três domínios novos pela API pública, sem copiar fixtures nem depender de internals.</td>
</tr>
<tr>
<td>Tarball, bootstrap, quickstart e container da referência.</td>
<td>Instalação e execução de cada consumidor independente desde diretório vazio; outra pessoa/agente reproduz seguindo apenas suas docs.</td>
</tr>
<tr>
<td>Persistência/recovery e PostgreSQL demonstrados na suíte.</td>
<td>Estados, falhas, concorrência e retomada de cada aplicação real definidos abaixo.</td>
</tr>
<tr>
<td>CI verde e hashes da árvore.</td>
<td>Novos relatórios dos três dogfoods ligados ao mesmo tarball e revisões das aplicações; nenhuma transferência automática de PASS.</td>
</tr>
<tr>
<td>N/A para distribuição futura.</td>
<td>Manter escopo monolítico. Não exigir runtime distribuído nem usar esse N/A para dispensar adoção, Moto aplicável ou recovery.</td>
</tr>
</table>
Autoridade: <mention-page url="https://app.notion.com/p/3d251cfc265c814d86e1df25ff45e238"/>; preservar vocabulário e PRD funcional. <mention-page url="https://app.notion.com/p/3d251cfc265c81aca312eb1cd5026b07"/> continua Backlog e depende do fechamento das Fases 7 e 8. Conformidade positiva da candidata não declara merge, Fase 8 concluída ou release pronta.
## 2. Protocolo comum obrigatório
1. Fornecer tarball construído de checkout limpo da revisão identificada. Registrar commit, tree, SHA-256 do tarball, versão do pacote, Node e dependências. A candidata usa `@lilka/vane@0.0.0`, `private: true` e Node \>=24: tarball local é válido para dogfood; publicação pertence à Fase 9.
2. Criar três projetos fora do repositório do framework, cada um com package.json, lockfile, código, testes e README próprios. Instalar o tarball como dependência normal; proibir npm link, workspace, symlinks para o core e imports privados. Resolução do pacote deve apontar para node_modules local. Disponibilizar ao adotante tarball e docs públicas, sem necessidade de checkout do core.
3. Seguir literalmente README/quickstart versionados antes de consultar source. Registrar tempo até primeira View/Event funcional, comandos, decisões não óbvias e cada consulta ao source. A referência serve de tutorial; copiá-la inteira e renomeá-la não demonstra domínio independente.
4. Usar Node 24 com patch fixado, PostgreSQL 16 real com versão registrada, schema/banco isolado por aplicação e migrations geradas pela API/CLI pública. Aplicação não escreve SQL de domínio para contornar Entity Events. SQL somente leitura é permitido no harness para verificar evidência de persistência.
5. Publicar rotas/contratos gerados e rodar processo Node real. HTTP 202 comprova admissão durável, não sucesso de negócio. Afirmar sucesso apenas pelo terminal View após persistência; SSE deve retornar somente View/fail seguro, inclusive após reconnect.
6. Para crash/recovery, usar barreiras observáveis do harness: admissão persistida, mutação confirmada, resposta externa recebida e checkpoint pendente. Matar processo abruptamente nesses pontos e reiniciar com o mesmo banco, plano e bindings. SIGTERM também é testado, mas não substitui crash. Nenhuma alteração no core para injetar falhas.
7. Fixar seeds, quantidade de repetições, timeout e políticas de retry antes da execução. Defaults de teste propostos: healthcheck 30 s; conclusão/recovery 60 s após restaurar dependência, com backoff/leases configurados para caber nesse limite. Registrar qualquer ajuste antes de rerodar; esses limites são orçamento do teste, não garantia de performance do produto.
8. Cada aplicação fornece scripts de setup, typecheck/build, migrate, start, teste e limpeza, além de runner que retorna exit code não zero diante de FAIL ou GAP obrigatório. CI deve executar os mesmos scripts, sem testes obrigatórios skipped.
### AWS/Moto e dependências externas
Todo/Project não precisa de AWS: registrar N/A por ausência de integração AWS, não por conveniência. Commerce exercita um adapter de aplicação para emissão de comprovante em S3 via Moto Server; não alegar provider AWS nativo do Vane. Reservation usa serviço externo HTTP determinístico para confirmação; AWS fica N/A se não houver integração AWS adicional.
Para Commerce: fixar imagem/versão de Moto Server e SDK AWS, healthcheck, endpoint local explícito, região fixa, credenciais dummy, bucket isolado e seed/reset determinístico. Recusar inicialização quando endpoint estiver ausente ou não autorizado; restringir egress a dependências locais e desabilitar busca de credenciais reais/metadata. Repetir criação, leitura e cleanup do recurso; desligar Moto para provar falha/retry. Não exigir LocalStack.
Moto não comprova IAM, quotas, consistência ou operação AWS integral. Registrar limites por serviço. Se garantia crítica depender de comportamento não emulado, caso fica GAP até smoke AWS mínimo, justificado e opt-in; esta especificação não autoriza executá-lo.
## 3. Dogfood 1 — Todo/Project
Item existente: <mention-page url="https://app.notion.com/p/3d251cfc265c8109a51bd2377eaa74fa"/>.
**Comportamento:** Project e Todo com identidade, referência explícita Todo→Project, título e estado; Events próprios Create/Update/Complete; Views list/detail com filtro e paginação. Usar duas Columns numéricas `completedUnits` e `totalUnits` para Rule `completedUnits <= totalUnits`; não inventar Rule unária contrária ao vocabulário. Cada Event altera somente seu owner.
**Dependências:** tarball, Node/TypeScript, PostgreSQL 16 e HTTP/SSE; sem gateway ou Moto.
- **TD-01 positivo:** criar Project e Todo, editar título, completar Todo e consultar list/detail. Assertar identidade, referência, valores e estado final; View não cria persistência própria.
- **TD-02 negativo:** input de tipo inválido, identidade duplicada, Project inexistente e conclusão acima do total. Cada caso deve produzir rejeição conforme contrato, sem mutação parcial ou resultado success; comparar estado anterior/posterior.
- **TD-03 diagnóstico:** DSL com referência inexistente, operação sobre owner alheio e configuração sem binding obrigatório. Esperar falha de validação/start acionável, conceito/origem/ação possível, exit code não zero e ausência de IR parcial/efeitos. Corrigir conforme docs e repetir até passar.
- **TD-04 persistência:** criar e completar, parar processo, reiniciar com mesmo schema e reler Views por HTTP e nova conexão PostgreSQL. Identidade e valores permanecem; schema/history de migration não deriva no restart.
- **TD-05 recuperação:** crash após admissão antes da execução e após commit antes de checkpoint. Retomar o sagaId admitido; uma única mutação efetiva e terminal recuperável. Reentrega deve reutilizar o envelope/Event ID persistido por API documentada. Repetir POST sem contrato de idempotência HTTP documentado não equivale a replay deduplicado.
- **TD-06 pacote/docs:** build/typecheck com imports públicos, erros de tipos positivos/negativos e reprodução limpa por outro adotante.
**Evidências:** transcripts HTTP/SSE, Views e snapshots antes/depois, migration/Storage IR, relatório TD-01–06, logs de restart e registro de adoção.
**Aprovação:** todos os seis grupos PASS em execução limpa e reprodução independente; nenhum dado inválido persistido, sucesso prematuro, import privado ou blocker P0/P1.
## 4. Dogfood 2 — Commerce com ACL + Saga
Item existente: <mention-page url="https://app.notion.com/p/3d251cfc265c81a693d6dc0d8179aab7"/>.
**Comportamento:** User, Coupon, Inventory, Order e Payment; compra reserva estoque, consome cupom quando aplicável, autoriza pagamento por ACL e conclui Order. Falha compensa os passos concluídos em ordem causal reversa, liberando estoque/cupom e cancelando Payment; se autorização já ocorreu, registrar refund/void externo idempotente. Terminal de sucesso é View de pedido/recibo. Resultado interno da ACL não vira retorno intermediário público.
**Dependências:** PostgreSQL 16; gateway HTTP controlável para approved/declined/timeout/resultado malformado; ledger persistente separado do gateway para chaves de idempotência e cobranças/refunds; Moto Server/S3 para comprovante. Mock em memória da referência não basta para crash do gateway.
- **CM-01 positivo:** estoque inicial 2, compra 1 unidade, usuário e cupom válidos. Assertar estoque final 1, cupom consumido uma vez, pagamento autorizado uma vez e Order completo; S3 contém um comprovante com conteúdo/hash esperado após etapa bem-sucedida.
- **CM-02 negativo:** quantidade acima do estoque, usuário ausente, cupom inválido/consumido, payment declined e resultado externo não declarado/malformado. Não concluir pedido; aplicar fail/compensation conforme ponto alcançado, sem saldo negativo nem cobrança indevida. Rejeição de domínio é final, não retry transitório.
- **CM-03 retry:** gateway indisponível/timeout, depois recuperado dentro da política; manter Event ID e idempotency key, tentativas/backoff registrados, sucesso final único. Exaustão produz fail seguro e registro operacional, não loop infinito.
- **CM-04 compensation:** falhar depois de reservar estoque/consumir cupom; e falhar emissão de comprovante depois de autorizar pagamento, desligando Moto. Restaurar contagens e disponibilidade; refund/void no segundo caso. Falha transitória de compensation deve ser retomada conforme política; falha exaurida fica registrada, demais compensações continuam e inconsistência não é disfarçada como success.
- **CM-05 crash/replay:** crash depois de mutação Entity e antes de checkpoint; crash depois de cobrança externa e antes de persistir resultado; restart do runtime e gateway preservando seus bancos. Assertar envelope estável, uma mutação por Event e um efeito financeiro por chave, apesar de múltiplas chamadas at-least-once.
- **CM-06 terminal:** desconectar SSE durante execução e reconectar após restart; receber mesmo terminal imutável, sem progresso, payload ACL ou secrets. Consultar View final em nova conexão.
- **CM-07 Moto/persistência:** round-trip S3, isolamento e reset; reiniciar Moto preservando armazenamento se suportado pelo setup, ou recriar explicitamente recurso e documentar a limitação. Banco do domínio e ledger do gateway sobrevivem restart. Não confundir recuperação do domínio com durabilidade do emulador S3.
**Evidências:** relatório CM-01–07, ledger de chamadas/chaves/efeitos, estoque/cupom/payment/order antes/depois, trace causal e compensações, SSE, objeto S3/hash, versões e logs Moto, snapshots duráveis.
**Aprovação:** todos os sete grupos PASS; zero oversell/cobrança duplicada sob identidade reutilizada; rollback causal demonstrado; Moto aplicável validado; failure queue e terminal corretos. Idempotência externa depende do gateway, não de promessa exactly-once do framework.
## 5. Dogfood 3 — Reservation/Booking adversarial
Item existente: <mention-page url="https://app.notion.com/p/3d251cfc265c81358106d9aaa9433662"/>.
**Comportamento:** Resource/Slot e Booking; capacidade 1, reserva temporária, confirmação antes do deadline e expiração com liberação; cancelamento/falha externa compensa reserva. Invariante persistente `reservedUnits <= capacity` no owner Resource/Slot; Booking muda somente por seus Events. Reservas de owners distintos são coordenadas por Saga, sem mutação cruzada. Expiração usa deadline persistido e acionador/scheduler explícito da aplicação com API pública; não presumir scheduler automático do framework.
**Dependências:** PostgreSQL 16, serviço HTTP de confirmação com ledger idempotente, processos/worker/scheduler supervisionados e relógio/deadline observável. Moto apenas se houver integração AWS concreta, registrada antes do teste.
- **RB-01 positivo:** reservar recurso livre, confirmar antes do deadline e consultar View Booking confirmada; liberação/cancelamento muda capacidade conforme contrato de domínio.
- **RB-02 concorrência:** duas solicitações sincronizadas para mesmo slot/capacidade 1, identidades distintas, repetir 50 rodadas com banco isolado. Exatamente uma reserva válida por rodada; outra termina com fail de domínio; nunca duas confirmadas nem contador maior que 1. Inspecionar estado persistido também após restart.
- **RB-03 expiração:** reserva não confirmada expira e libera capacidade uma vez; confirmação tardia é rejeitada. Reiniciar scheduler antes/depois do deadline: pendências vencidas são processadas, sem perder expiração.
- **RB-04 corrida:** confirmar versus expirar, sincronizar ambos no deadline e repetir 50 rodadas. Resultado permitido: confirmação válida anterior ao deadline ou expiração; nunca confirmado com reserva liberada nem duas liberações. Oráculo usa deadline persistido e transição atômica declarada, não ordem de chegada do teste.
- **RB-05 falha/retry:** confirmação externa indisponível, recuperada dentro do deadline e orçamento → confirmação; ultrapassar deadline ou exaurir retry → fail e liberação/compensation. Falha de compensation fica inspecionável e segue política documentada.
- **RB-06 crash/recovery:** interromper worker após reserva commitada, após efeito externo e durante liberação; reiniciar com mesmo plano e ledger. Assertar estado convergente, reserva não órfã após prazo, identidade estável e nenhum incremento/liberação duplicado.
- **RB-07 duplicate/failure operations:** reentregar envelope persistido e recuperar lease; uma mutação por Event. Exaurir publicação outbox, listar failure, corrigir publisher e usar retry-outbox preservando ID. Resolver failure não reexecuta Saga nem modifica terminal; não usar retry-outbox para replay de passos.
- **RB-08 negativos/contrato:** capacidade inválida, binding incompleto, plano/adapter incompatível e attempts mal configurados são rejeitados sem reinterpretar trabalho pendente. SSE após reconnect expõe apenas View/fail seguro; inspeção privilegiada não fica em rota pública.
**Evidências:** relatórios por seed/rodada, IDs e timelines/deadlines, estados persistidos/invariantes, barreiras e sinais de crash, trace causal, attempts/leases/failures, ledger externo e terminais.
**Aprovação:** todos os oito grupos PASS, incluindo 50/50 rodadas em cada grupo concorrente; zero oversubscription, reserva órfã após recuperação, terminal contraditório ou efeito duplicado pela mesma chave. Não alegar exclusividade global/distribuição produtiva.
## 6. Rastreabilidade, fricções e gate de fechamento
Cada aplicação entrega manifest de evidência e relatório humano/JSON contendo: scenarioId, requisito VR-DX/VR-LOCAL e IDs EE efetivamente aplicáveis, precondição, ação, expectativa, observado, status PASS/FAIL/GAP/N/A, hash/revisão da app/tarball/docs, versões, seed, comando, exit code, timestamps e links aos logs. Mapear IDs EE a partir do catálogo existente; não inventar IDs nem usar contagem agregada como prova do cenário.
- **VR-DX-001–003:** diretório vazio, tarball, resolução e auditoria de imports públicos de cada app.
- **VR-DX-004 e 007:** negativos acionáveis e CLI help/exit codes, com erro→correção→sucesso registrado.
- **VR-DX-005–006:** scripts executáveis em CI e segunda reprodução literal sem leitura obrigatória de internals.
- **VR-DX-008 e VR-LOCAL-001:** defaults explícitos, credenciais locais falsas e PostgreSQL 16 real.
- **VR-LOCAL-002–006:** Moto e serviço AWS exercitado, bootstrap/reset, ausência de AWS acidental, limites de fidelidade e decisão sobre smoke opt-in; N/A justificado somente quando aplicável.
Cada fricção registra cenário, reprodução, impacto, severidade, classificação BUG/DX/MISSING CAPABILITY/CONCEPTUAL FAILURE, solução/aceite e rerun. P0: perda/corrupção de dados ou violação grave de garantia; P1: impede caminho obrigatório de adoção/recovery ou exige internals/workaround incompatível. Nenhum P0/P1 pode ser encerrado apenas por aceite. Demais fricções podem ser aceitas conscientemente com limite e justificativa.
Quando caso válido exigir violar owner-only ou outra regra normativa, registrar CONCEPTUAL FAILURE e parar a solução daquele caso antes de alterar ontologia. Pivô precisa de decisão explícita.
Documentação atual tem descrição de caminhos legados em sagas e caminho configurado durável em operations; verificar o Runtime/Contract IR usado e documentar rota exata. Não presumir que retenção de terminal por si só torna rota legada recuperável.
**Gate futuro da Fase 8:** três aplicações independentes verdes no mesmo tarball identificado, PostgreSQL real, Moto aplicável, docs corrigidas e revalidadas literalmente por outro adotante, zero P0/P1 e zero pivô pendente. Correção no pacote exige novo hash e rerun afetado mais regressão dos três consumidores; nunca transplantar evidência de outra revisão. Nenhum cenário desta especificação está marcado PASS por antecipação.
## 7. Ordem limitada de implementação
1. Congelar e entregar candidata/tarball/docs com proveniência; obter relatório de conformance daquela árvore. Sem merge ou publicação nesta atividade.
2. Construir harness externo mínimo, scripts e formato de evidência; concluir TD-01–06 e reprodução limpa.
3. Implementar Commerce, gateway com ledger persistente e Moto; concluir CM-01–07.
4. Implementar Reservation com scheduler explícito e barreiras; concluir RB-01–08.
5. Classificar/corrigir fricções, repetir cenários afetados e reprodução literal dos três projetos; produzir matriz e decisão explícita do gate. Até novas evidências, Fase 8 permanece Backlog; Fase 9 permanece dependente.
</content>
</page>

<parent-data-source-schema url="collection://b060dc02-fe6c-4d2c-b78e-fa6d49fa2e34">
The SQLite table definition for this page's parent data source. Use these column names and option values to set this page's properties, create sibling pages, or query the data source.
These columns are read-only, so don't set them: "Última edição".
<sqlite-table>
CREATE TABLE IF NOT EXISTS "collection://b060dc02-fe6c-4d2c-b78e-fa6d49fa2e34" (
	url TEXT UNIQUE,
	createdTime TEXT, -- ISO-8601 datetime string, automatically set. This is the canonical time for when the page was created.
	"Evidência" TEXT,
	"Última edição" TEXT NOT NULL, -- ISO-8601 datetime string, automatically set. This is the canonical time for when the page was last edited.
	"Fase" TEXT, -- one of ["Fase 1", "Fase 2", "Fase 3", "Fase 4", "Fase 5", "Fase 6", "Fase 7", "Fase 8", "Fase 9"]
	"Prioridade" TEXT, -- one of ["P0", "P1", "P2", "P3"]
	"Status" TEXT, -- one of ["Backlog", "Em andamento", "Revisão", "Bloqueado", "Concluído"]
	"Notas" TEXT,
	"Requisitos do PRD" TEXT,
	"Área" TEXT, -- one of ["Fundação", "DSL", "Compilador", "Configuração", "Persistência", "Runtime", "Contrato", "Observabilidade", "Documentação"]
	"Item" TEXT
)
</sqlite-table>
</parent-data-source-schema>
