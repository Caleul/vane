// External provider fixture: SQL owns only provider state, never framework/domain tables.
import { createServer } from "node:http";
import { Pool } from "pg";
import {
	S3Client,
	CreateBucketCommand,
	PutObjectCommand,
} from "@aws-sdk/client-s3";
const endpoint = process.env.VANE_DOGFOOD_MOTO_URL;
if (!endpoint) throw new Error("VANE_DOGFOOD_MOTO_URL is required");
const target = new URL(endpoint);
if (
	target.protocol !== "http:" ||
	!["127.0.0.1", "localhost"].includes(target.hostname)
)
	throw new Error("Moto must use loopback HTTP");
process.env.AWS_EC2_METADATA_DISABLED = "true";
const s3 = new S3Client({
	region: "us-east-1",
	endpoint,
	forcePathStyle: true,
	credentials: { accessKeyId: "dummy", secretAccessKey: "dummy" },
	maxAttempts: 1,
	followRegionRedirects: false,
});
const bucket = "vane-dogfood-commerce";
const pool = new Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
});
await pool.query("CREATE SCHEMA IF NOT EXISTS dogfood_commerce_gateway");
await pool.query(
	"CREATE TABLE IF NOT EXISTS dogfood_commerce_gateway.effects (key text PRIMARY KEY, operation text NOT NULL, order_id uuid NOT NULL, reference text NOT NULL, created_at timestamptz NOT NULL DEFAULT clock_timestamp())",
);
await pool.query(
	"CREATE TABLE IF NOT EXISTS dogfood_commerce_gateway.calls (sequence bigserial PRIMARY KEY,key text NOT NULL,operation text NOT NULL,order_id uuid NOT NULL, mode text NOT NULL,created_at timestamptz NOT NULL DEFAULT clock_timestamp())",
);
try {
	await s3.send(new CreateBucketCommand({ Bucket: bucket }));
} catch (e) {
	if (!["BucketAlreadyOwnedByYou", "BucketAlreadyExists"].includes(e.name))
		throw e;
}
const blocked = new Map();
const server = createServer(async (req, res) => {
	try {
		if (req.url.startsWith("/control/release/")) {
			const id = req.url.split("/").pop();
			const pending = blocked.get(id);
			if (pending) {
				pending.res
					.writeHead(200, { "content-type": "application/json" })
					.end(JSON.stringify(pending.existing));
				blocked.delete(id);
			}
			res.writeHead(200).end("{}");
			return;
		}
		const chunks = [];
		for await (const chunk of req) chunks.push(chunk);
		const body = JSON.parse(Buffer.concat(chunks).toString());
		const key = req.headers["idempotency-key"];
		if (typeof key !== "string") {
			res.writeHead(400).end();
			return;
		}
		const operation = req.url.slice(1);
		if (!["authorize", "refund", "receipt"].includes(operation)) {
			res.writeHead(404).end();
			return;
		}
		await pool.query(
			"INSERT INTO dogfood_commerce_gateway.calls (key,operation,order_id,mode) VALUES ($1,$2,$3,$4)",
			[key, operation, body.id, body.mode],
		);
		const calls = await pool.query(
			"SELECT count(*)::int AS count FROM dogfood_commerce_gateway.calls WHERE key=$1",
			[key],
		);
		if (
			operation === "authorize" &&
			(body.mode === "exhaust" ||
				(body.mode === "retry" && calls.rows[0].count < 3))
		) {
			req.socket.destroy();
			return;
		}
		if (operation === "authorize" && body.mode === "malformed") {
			res
				.writeHead(200, { "content-type": "application/json" })
				.end(JSON.stringify({ reference: 42, secret: "DO-NOT-EXPOSE" }));
			return;
		}
		if (operation === "authorize" && body.mode === "timeout") {
			return;
		}
		if (operation === "authorize" && body.mode === "decline") {
			res.writeHead(402).end("{}");
			return;
		}
		if (operation === "refund" && body.mode === "refund-exhaust") {
			req.socket.destroy();
			return;
		}
		if (
			operation === "refund" &&
			body.mode === "refund-retry" &&
			calls.rows[0].count < 3
		) {
			req.socket.destroy();
			return;
		}
		if (operation === "refund" && body.mode === "refund-fail") {
			res.writeHead(402).end("{}");
			return;
		}
		if (
			operation === "receipt" &&
			["s3-fail", "refund-fail", "refund-retry", "refund-exhaust"].includes(
				body.mode,
			)
		) {
			// Actually call Moto with a nonexistent bucket, proving a real storage failure.
			try {
				await s3.send(
					new PutObjectCommand({
						Bucket: "missing-commerce-bucket",
						Key: body.id,
						Body: "receipt",
					}),
				);
				throw new Error("Missing bucket unexpectedly succeeded");
			} catch (error) {
				if (error.name !== "NoSuchBucket") throw error;
				res.writeHead(402).end("{}");
				return;
			}
		}
		let existing = (
			await pool.query(
				"SELECT reference FROM dogfood_commerce_gateway.effects WHERE key=$1",
				[key],
			)
		).rows[0];
		if (!existing) {
			if (operation === "receipt")
				await s3.send(
					new PutObjectCommand({
						Bucket: bucket,
						Key: `${body.id}.json`,
						Body: JSON.stringify({ orderId: body.id }),
						ContentType: "application/json",
					}),
				);
			existing = (
				await pool.query(
					"INSERT INTO dogfood_commerce_gateway.effects (key,operation,order_id,reference) VALUES ($1,$2,$3,$4) ON CONFLICT (key) DO UPDATE SET key=EXCLUDED.key RETURNING reference",
					[key, operation, body.id, `${operation}-${key}`],
				)
			).rows[0];
			if (
				operation === "authorize" &&
				["effect-barrier", "moto-barrier"].includes(body.mode)
			) {
				blocked.set(body.id, { res, existing });
				console.log(
					JSON.stringify({
						barrier: "external-effect-committed",
						key,
						orderId: body.id,
					}),
				);
				// Deliberately leave request open; test kills actual gateway + app processes.
				return;
			}
		}
		res
			.writeHead(200, { "content-type": "application/json" })
			.end(JSON.stringify(existing));
	} catch (error) {
		console.error(error.name);
		res.writeHead(500).end("{}");
	}
});
server.listen(Number(process.env.COMMERCE_GATEWAY_PORT ?? 0), "127.0.0.1", () =>
	console.log(JSON.stringify({ state: "running", address: server.address() })),
);
const stop = () => {
	server.close();
	server.closeAllConnections();
	pool.end().catch(() => {});
};
process.once("SIGTERM", stop);
process.once("SIGINT", stop);
