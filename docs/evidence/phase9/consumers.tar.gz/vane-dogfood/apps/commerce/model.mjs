import { readFileSync } from "node:fs";
import { compileProjectSources, materializePostgreSql } from "@lilka/vane";
export const project = compileProjectSources([
	{
		fileName: "commerce.vane.ts",
		sourceText: readFileSync(
			new URL("./commerce.vane.ts", import.meta.url),
			"utf8",
		),
	},
]);
if (!project.success) throw new Error(JSON.stringify(project.diagnostics));
export const module = project.ir.modules.find((m) => m.name === "Commerce");
const physical = materializePostgreSql(project.ir, {
	namespace: "dogfood_commerce",
	targetVersion: 16,
});
if (!physical.success) throw new Error(JSON.stringify(physical.diagnostics));
export const storage = physical.ir;
