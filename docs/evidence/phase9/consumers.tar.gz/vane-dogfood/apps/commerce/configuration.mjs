import { readFileSync } from "node:fs";
import {
	http,
	BUILTIN_PROVIDERS,
	compileProjectSources,
	env,
	httpAcl,
	monolith,
	node,
	postgres,
	postgresDeduplication,
	postgresFailureQueue,
	postgresMailbox,
	postgresOutbox,
	postgresSaga,
	serviceConfiguration,
	sse,
} from "@lilka/vane";
const compiled = compileProjectSources([
	{
		fileName: "commerce.vane.ts",
		sourceText: readFileSync(
			new URL("./commerce.vane.ts", import.meta.url),
			"utf8",
		),
	},
]);
if (!compiled.success) throw new Error(JSON.stringify(compiled.diagnostics));
const acl = (path, result, failure) => ({
	provider: httpAcl(),
	version: "1",
	endpoint: env(`COMMERCE_${path.toUpperCase()}_URL`),
	idempotencyHeader: "Idempotency-Key",
	responses: [
		{ status: 200, result, fields: { reference: "reference" } },
		{ status: 402, result: failure, fields: {} },
	],
});
export default serviceConfiguration({
	application: "commerce",
	project: compiled.ir,
	providers: BUILTIN_PROVIDERS,
	profiles: {
		test: {
			environment: "test",
			topology: monolith({
				name: "api",
				modules: ["Commerce"],
				runtime: node(),
				persistence: {
					provider: postgres(),
					namespace: "dogfood_commerce",
					targetVersion: 16,
					connection: env("VANE_DOGFOOD_DATABASE_URL"),
				},
			}),
			communication: {
				mailbox: postgresMailbox(),
				outbox: postgresOutbox(),
				deduplication: postgresDeduplication(),
				saga: postgresSaga(),
				failureQueue: postgresFailureQueue(),
			},
			http: {
				provider: http(),
				sagaStream: sse(),
				security: {
					authentication: "none",
					authorization: "allow",
					cors: [],
					rateLimit: null,
				},
			},
			telemetry: { exporter: "none" },
			policies: {
				defaults: {
					timeoutMs: 3000,
					retry: { attempts: 3, backoff: "fixed", delayMs: 30, maxDelayMs: 30 },
				},
			},
			acls: {
				"Commerce.Gateway.Authorize": acl("authorize", "approved", "declined"),
				"Commerce.Gateway.Refund": acl("refund", "refunded", "declined"),
				"Commerce.ReceiptStorage.Store": acl("receipt", "stored", "failed"),
			},
			contracts: {
				Commerce: {
					basePath: "/commerce",
					events: [
						{
							event: "Order.Place",
							saga: "Checkout",
							terminal: {
								view: "OrderDetails",
								input: { id: { kind: "eventInput", input: "id" } },
							},
						},
					],
					views: [
						{ view: "OrderDetails" },
						{ view: "PaymentDetails" },
						{ view: "InventoryDetails" },
						{ view: "CouponDetails" },
					],
				},
			},
		},
	},
});
