import {
	Entity,
	Column,
	Event,
	Rule,
	View,
	Saga,
	Module,
	ACL,
	ACLEvent,
	input,
	literal,
	create,
	update,
	column,
	add,
	subtract,
	gte,
	lte,
	eq,
	field,
	reference,
	event,
	eventRef,
	success,
	fail,
} from "@lilka/vane";
@Entity()
export class User {
	id = Column({ type: "uuid", identity: true });
	email = Column({ type: "string" });
	Register = Event({
		input: { id: "uuid", email: "string" },
		operation: create({ id: input("id"), email: input("email") }),
	});
}
@Entity()
export class Coupon {
	id = Column({ type: "uuid", identity: true });
	used = Column({ type: "integer", minimum: 0 });
	maximum = Column({ type: "integer", minimum: 0 });
	@Rule({ expression: lte(column("used"), column("maximum")) }) Available() {}
	Issue = Event({
		input: { id: "uuid", maximum: "integer" },
		operation: create({
			id: input("id"),
			maximum: input("maximum"),
			used: literal(0),
		}),
	});
	Use = Event({
		input: { couponId: "uuid" },
		operation: update(input("couponId"), {
			used: add(column("used"), literal(1)),
		}),
	});
	Restore = Event({
		input: { couponId: "uuid" },
		operation: update(input("couponId"), {
			used: subtract(column("used"), literal(1)),
		}),
	});
}
@Entity()
export class Inventory {
	id = Column({ type: "uuid", identity: true });
	quantity = Column({ type: "integer", minimum: 0 });
	capacity = Column({ type: "integer", minimum: 0 });
	@Rule({ expression: lte(column("quantity"), column("capacity")) })
	WithinCapacity() {}
	Stock = Event({
		input: { id: "uuid", quantity: "integer" },
		operation: create({
			id: input("id"),
			quantity: input("quantity"),
			capacity: input("quantity"),
		}),
	});
	Reserve = Event({
		input: { stockId: "uuid", quantity: "integer" },
		operation: update(input("stockId"), {
			quantity: subtract(column("quantity"), input("quantity")),
		}),
	});
	Release = Event({
		input: { stockId: "uuid", quantity: "integer" },
		operation: update(input("stockId"), {
			quantity: add(column("quantity"), input("quantity")),
		}),
	});
}
@Entity()
export class Order {
	id = Column({ type: "uuid", identity: true });
	userId = Column({ type: "uuid", references: reference(User, "id") });
	couponId = Column({ type: "uuid", references: reference(Coupon, "id") });
	stockId = Column({ type: "uuid", references: reference(Inventory, "id") });
	quantity = Column({ type: "integer", minimum: 1 });
	amount = Column({ type: "integer", minimum: 1 });
	status = Column({ type: "string" });
	Place = Event({
		input: {
			id: "uuid",
			userId: "uuid",
			couponId: "uuid",
			stockId: "uuid",
			amount: "integer",
			quantity: "integer",
			mode: "string",
		},
		operation: create({
			id: input("id"),
			userId: input("userId"),
			couponId: input("couponId"),
			stockId: input("stockId"),
			amount: input("amount"),
			quantity: input("quantity"),
			status: literal("placed"),
		}),
	});
	Cancel = Event({
		input: { id: "uuid" },
		operation: update(input("id"), { status: literal("cancelled") }),
	});
	Complete = Event({
		input: { id: "uuid" },
		operation: update(input("id"), { status: literal("complete") }),
	});
}
@Entity()
export class Payment {
	id = Column({ type: "uuid", identity: true });
	orderId = Column({ type: "uuid", references: reference(Order, "id") });
	amount = Column({ type: "integer", minimum: 1 });
	status = Column({ type: "string" });
	Create = Event({
		input: { id: "uuid", amount: "integer" },
		operation: create({
			id: input("id"),
			orderId: input("id"),
			amount: input("amount"),
			status: literal("created"),
		}),
	});
	Cancel = Event({
		input: { id: "uuid" },
		operation: update(input("id"), { status: literal("cancelled") }),
	});
}
@ACL()
export class Gateway {
	Authorize = ACLEvent({
		input: { id: "uuid", amount: "integer", mode: "string" },
		results: { approved: success({ reference: "string" }), declined: fail({}) },
	});
	Refund = ACLEvent({
		input: { id: "uuid", mode: "string" },
		results: { refunded: success({ reference: "string" }), declined: fail({}) },
	});
}
@ACL()
export class ReceiptStorage {
	Store = ACLEvent({
		input: { id: "uuid", mode: "string" },
		results: { stored: success({ reference: "string" }), failed: fail({}) },
	});
}
@View({
	input: { id: "uuid" },
	output: {
		id: field(Order, "id"),
		status: field(Order, "status"),
		amount: field(Order, "amount"),
	},
	query: { root: Order, where: eq(field(Order, "id"), input("id")) },
})
export class OrderDetails {}
@View({
	input: { id: "uuid" },
	output: {
		id: field(Payment, "id"),
		status: field(Payment, "status"),
		amount: field(Payment, "amount"),
	},
	query: { root: Payment, where: eq(field(Payment, "id"), input("id")) },
})
export class PaymentDetails {}
@View({
	input: { id: "uuid" },
	output: {
		id: field(Inventory, "id"),
		quantity: field(Inventory, "quantity"),
	},
	query: { root: Inventory, where: eq(field(Inventory, "id"), input("id")) },
})
export class InventoryDetails {}
@View({
	input: { id: "uuid" },
	output: { id: field(Coupon, "id"), used: field(Coupon, "used") },
	query: { root: Coupon, where: eq(field(Coupon, "id"), input("id")) },
})
export class CouponDetails {}
@Saga({
	input: {
		id: "uuid",
		userId: "uuid",
		couponId: "uuid",
		stockId: "uuid",
		amount: "integer",
		quantity: "integer",
		mode: "string",
	},
	steps: {
		place: event(Order, "Place", { compensateWith: eventRef(Order, "Cancel") }),
		coupon: event(Coupon, "Use", {
			causedBy: ["place"],
			compensateWith: eventRef(Coupon, "Restore"),
		}),
		reserve: event(Inventory, "Reserve", {
			causedBy: ["coupon"],
			compensateWith: eventRef(Inventory, "Release"),
		}),
		payment: event(Payment, "Create", {
			causedBy: ["reserve"],
			compensateWith: eventRef(Payment, "Cancel"),
		}),
		authorize: event(Gateway, "Authorize", {
			causedBy: ["payment"],
			compensateWith: eventRef(Gateway, "Refund"),
		}),
		receipt: event(ReceiptStorage, "Store", { causedBy: ["authorize"] }),
		complete: event(Order, "Complete", { causedBy: ["receipt"] }),
	},
	terminal: { step: "complete", view: OrderDetails },
})
export class Checkout {}
@Module({
	entities: [User, Coupon, Inventory, Order, Payment],
	antiCorruptionLayers: [Gateway, ReceiptStorage],
	views: [OrderDetails, PaymentDetails, InventoryDetails, CouponDetails],
	sagas: [Checkout],
})
export class Commerce {}
