import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import { readFile, writeFile, unlink } from "node:fs/promises";
import { Pool } from "pg";
import {
	S3Client,
	ListObjectsV2Command,
	DeleteObjectsCommand,
	DeleteBucketCommand,
} from "@aws-sdk/client-s3";
export const directory = new URL(".", import.meta.url).pathname;
export const cli = new URL(
	"./node_modules/@lilka/vane/dist/cli.js",
	import.meta.url,
).pathname;
export const common = [
	"--config",
	`${directory}configuration.mjs`,
	"--profile",
	"test",
	"--json",
];
export const defaultEnv = {
	...process.env,
	VANE_DOGFOOD_DATABASE_URL:
		process.env.VANE_DOGFOOD_DATABASE_URL ??
		"postgresql://vane:vane-local-only@127.0.0.1:55432/vane_dogfood",
	VANE_DOGFOOD_MOTO_URL:
		process.env.VANE_DOGFOOD_MOTO_URL ?? "http://127.0.0.1:55000",
	AWS_EC2_METADATA_DISABLED: "true",
};
export async function invoke(args, env = defaultEnv) {
	return JSON.parse(
		(
			await promisify(execFile)(process.execPath, [cli, ...args, ...common], {
				env,
				timeout: 30000,
			})
		).stdout,
	);
}
export async function start(args, env = defaultEnv) {
	const child = spawn(process.execPath, args, {
		env,
		cwd: directory,
		stdio: ["ignore", "pipe", "pipe"],
	});
	child.lines = [];
	child.stderrText = "";
	child.exited = new Promise((resolve) =>
		child.once("exit", (code, signal) => resolve({ code, signal })),
	);
	let buffer = "";
	child.stdout.on("data", (data) => {
		buffer += data;
		while (buffer.includes("\n")) {
			const i = buffer.indexOf("\n");
			const line = buffer.slice(0, i);
			buffer = buffer.slice(i + 1);
			try {
				child.lines.push(JSON.parse(line));
			} catch {
				child.lines.push({ text: line });
			}
		}
	});
	child.stderr.on("data", (data) => (child.stderrText += data));
	await until(
		() => child.lines.find((x) => x.state === "running"),
		10000,
		() => (child.exitCode !== null ? new Error(child.stderrText) : null),
	);
	const ready = child.lines.find((x) => x.state === "running");
	child.url = `http://127.0.0.1:${ready.address.port}`;
	return child;
}
export async function until(predicate, timeout = 10000, fail = () => null) {
	const end = Date.now() + timeout;
	while (Date.now() < end) {
		const error = fail();
		if (error) throw error;
		const value = await predicate();
		if (value) return value;
		await new Promise((r) => setTimeout(r, 10));
	}
	throw new Error("Observable condition timed out");
}
export async function stop(child, signal = "SIGTERM") {
	if (child.exitCode === null && child.signalCode === null) child.kill(signal);
	const timer = setTimeout(() => child.kill("SIGKILL"), 5000);
	try {
		return await child.exited;
	} finally {
		clearTimeout(timer);
	}
}
export async function migrate(env = defaultEnv) {
	const pool = new Pool({ connectionString: env.VANE_DOGFOOD_DATABASE_URL });
	await pool.query("CREATE SCHEMA IF NOT EXISTS dogfood_commerce");
	await pool.end();
	const file = `${directory}.migration.json`;
	await writeFile(file, JSON.stringify(await invoke(["migrate", "diff"], env)));
	try {
		return await invoke(["migrate", "apply", "--migration", file], env);
	} finally {
		await unlink(file).catch(() => {});
	}
}
export function gatewayEnv(gateway, env = defaultEnv) {
	return {
		...env,
		COMMERCE_AUTHORIZE_URL: `${gateway.url}/authorize`,
		COMMERCE_REFUND_URL: `${gateway.url}/refund`,
		COMMERCE_RECEIPT_URL: `${gateway.url}/receipt`,
	};
}
export async function cleanup() {
	const pool = new Pool({
		connectionString: defaultEnv.VANE_DOGFOOD_DATABASE_URL,
	});
	try {
		await pool.query("DROP SCHEMA IF EXISTS dogfood_commerce CASCADE");
		await pool.query("DROP SCHEMA IF EXISTS dogfood_commerce_gateway CASCADE");
	} finally {
		await pool.end();
	}
	const endpoint = defaultEnv.VANE_DOGFOOD_MOTO_URL;
	if (!/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(endpoint))
		throw new Error("Only local Moto cleanup permitted");
	const s3 = new S3Client({
		region: "us-east-1",
		endpoint,
		forcePathStyle: true,
		credentials: { accessKeyId: "dummy", secretAccessKey: "dummy" },
		maxAttempts: 1,
	});
	try {
		const objects = await s3.send(
			new ListObjectsV2Command({ Bucket: "vane-dogfood-commerce" }),
		);
		if (objects.Contents?.length)
			await s3.send(
				new DeleteObjectsCommand({
					Bucket: "vane-dogfood-commerce",
					Delete: { Objects: objects.Contents.map((x) => ({ Key: x.Key })) },
				}),
			);
		await s3.send(new DeleteBucketCommand({ Bucket: "vane-dogfood-commerce" }));
	} catch (e) {
		if (e.name !== "NoSuchBucket") throw e;
	}
}
