import assert from "node:assert/strict";
import { randomUUID, createHash } from "node:crypto";
import { writeFile, mkdir } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { Pool } from "pg";
import {
	S3Client,
	GetObjectCommand,
	HeadObjectCommand,
	HeadBucketCommand,
	CreateBucketCommand,
} from "@aws-sdk/client-s3";
import {
	PostgreSqlModuleRuntime,
	PostgreSqlSagaStore,
	PostgreSqlOperations,
	createEventEnvelope,
} from "@lilka/vane";
import { createReporter } from "../../harness/evidence.mjs";
import { module, storage } from "./model.mjs";
import {
	defaultEnv,
	start,
	stop,
	migrate,
	cleanup,
	directory,
	gatewayEnv,
	until,
} from "./lib.mjs";
const reporter = createReporter("commerce");
const requirements = [
	"VR-DX-001",
	"VR-DX-002",
	"VR-DX-003",
	"VR-DX-005",
	"VR-DX-008",
	"VR-LOCAL-001",
];
const ee = {
	"CM-01": ["EE-EVT-004", "EE-VIEW-006", "EE-HTTP-002"],
	"CM-02": ["EE-COMP-003", "EE-ACL-002"],
	"CM-03": ["EE-SVC-018", "EE-NFR-008"],
	"CM-04": ["EE-SAGA-004"],
	"CM-05": ["EE-SAGA-003", "EE-PG-006", "EE-NFR-008"],
	"CM-06": ["EE-SAGA-007", "EE-HTTP-006", "EE-OBS-005"],
	"CM-07": ["EE-PG-006"],
};
const spec = (id, action, expected, extra = []) => ({
	id,
	requirements: [...requirements, ...extra, ...(ee[id] ?? [])],
	precondition:
		"Independent installed tarball; PostgreSQL16; isolated dogfood_commerce and provider ledger; local Moto",
	action,
	expected,
});
const pool = new Pool({
	connectionString: defaultEnv.VANE_DOGFOOD_DATABASE_URL,
	max: 20,
});
const s3 = new S3Client({
	region: "us-east-1",
	endpoint: defaultEnv.VANE_DOGFOOD_MOTO_URL,
	forcePathStyle: true,
	credentials: { accessKeyId: "dummy", secretAccessKey: "dummy" },
	maxAttempts: 1,
	followRegionRedirects: false,
});
const evidence = {
	seed: "phase-8-fixed",
	snapshots: [],
	transcripts: [],
	crashes: [],
	moto: [],
};
const operations = new PostgreSqlOperations(pool, storage);
let gateway, application, seeds, store;
const children = [];
async function bootGateway() {
	gateway = await start([`${directory}gateway.mjs`], defaultEnv);
	children.push(gateway);
	return gateway;
}
async function bootApp(env = {}) {
	application = await start([`${directory}server.mjs`], {
		...gatewayEnv(gateway),
		...env,
	});
	children.push(application);
	return application;
}
async function dispatch(identity, payload) {
	const result = await seeds.dispatch(
		createEventEnvelope({
			eventId: randomUUID(),
			eventIdentity: identity,
			occurredAt: new Date().toISOString(),
			payload,
		}),
	);
	assert.equal(result.kind, "success", JSON.stringify(result));
	return result;
}
async function seed({ stock = 2, maximum = 1 } = {}) {
	const userId = randomUUID(),
		couponId = randomUUID(),
		stockId = randomUUID();
	await dispatch("User.Register", { id: userId, email: "buyer@example.test" });
	await dispatch("Coupon.Issue", { id: couponId, maximum });
	await dispatch("Inventory.Stock", { id: stockId, quantity: stock });
	return {
		id: randomUUID(),
		userId,
		couponId,
		stockId,
		amount: 500,
		quantity: 1,
		mode: "normal",
	};
}
async function post(path, payload) {
	const response = await fetch(`${application.url}/commerce/${path}`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify(payload),
		signal: AbortSignal.timeout(10000),
	});
	const body = await response.json();
	evidence.transcripts.push({
		method: "POST",
		path,
		payload,
		status: response.status,
		body,
	});
	return { status: response.status, body };
}
async function admit(input) {
	const response = await post("events/Order.Place", input);
	assert.equal(response.status, 202, JSON.stringify(response));
	assert.ok(response.body.sagaId);
	return response.body.sagaId;
}
async function terminal(sagaId) {
	const response = await fetch(`${application.url}/commerce/sagas/${sagaId}`, {
		signal: AbortSignal.timeout(15000),
	});
	assert.equal(response.status, 200);
	const text = await response.text();
	assert.equal((text.match(/event: /g) ?? []).length, 1);
	assert.ok(/^event: (view|fail)\n/.test(text));
	assert.ok(
		!/DO-NOT-EXPOSE|dummy|reference|external_reference|retry|compensation|progress/.test(
			text,
		),
	);
	evidence.transcripts.push({ sagaId, text });
	return { text, state: await store.read(sagaId) };
}
async function view(name, id) {
	const result = await post(`views/${name}`, { id });
	assert.equal(result.status, 200);
	return result.body;
}
async function ledger(id) {
	return {
		calls: (
			await pool.query(
				"SELECT sequence,key,operation,order_id,mode,created_at FROM dogfood_commerce_gateway.calls WHERE order_id=$1 ORDER BY sequence",
				[id],
			)
		).rows,
		effects: (
			await pool.query(
				"SELECT * FROM dogfood_commerce_gateway.effects WHERE order_id=$1 ORDER BY created_at",
				[id],
			)
		).rows,
	};
}
async function snapshot(input, sagaId) {
	const value = {
		input,
		sagaId,
		order: await view("OrderDetails", input.id),
		payment: await view("PaymentDetails", input.id),
		inventory: await view("InventoryDetails", input.stockId),
		coupon: await view("CouponDetails", input.couponId),
		ledger: await ledger(input.id),
		state: await store.read(sagaId),
	};
	evidence.snapshots.push(value);
	return value;
}
async function purchase(input) {
	const sagaId = await admit(input);
	const done = await terminal(sagaId);
	return { sagaId, done, snapshot: await snapshot(input, sagaId) };
}
async function restored(
	result,
	input,
	{ charged = false, refund = true, couponUsed = 0 } = {},
) {
	assert.ok(result.done.text.startsWith("event: fail"));
	const snap = result.snapshot;
	assert.equal(snap.inventory[0].quantity, 2);
	if (snap.coupon.length) assert.equal(snap.coupon[0].used, couponUsed);
	if (snap.order.length) assert.equal(snap.order[0].status, "cancelled");
	if (snap.payment.length) assert.equal(snap.payment[0].status, "cancelled");
	assert.equal(
		snap.ledger.effects.filter((e) => e.operation === "authorize").length,
		charged ? 1 : 0,
	);
	assert.equal(
		snap.ledger.effects.filter((e) => e.operation === "refund").length,
		charged && refund ? 1 : 0,
	);
}
async function moto(action) {
	const env = { ...process.env };
	for (const name of [
		"DOCKER_HOST",
		"DOCKER_CONTEXT",
		"DOCKER_TLS",
		"DOCKER_TLS_VERIFY",
		"DOCKER_CERT_PATH",
	])
		delete env[name];
	const result = await promisify(execFile)(
		"docker",
		["--host=unix:///var/run/docker.sock", action, "vane-dogfood-moto"],
		{ env, timeout: 15000 },
	);
	evidence.moto.push({
		action,
		stdout: result.stdout,
		time: new Date().toISOString(),
	});
	if (action === "start")
		await until(async () => {
			try {
				return (await fetch(`${defaultEnv.VANE_DOGFOOD_MOTO_URL}/moto-api/`))
					.ok;
			} catch {
				return false;
			}
		}, 15000);
}
try {
	await cleanup();
	await bootGateway();
	await migrate(gatewayEnv(gateway));
	seeds = new PostgreSqlModuleRuntime({ module, storage, pool });
	await seeds.start();
	store = new PostgreSqlSagaStore(pool, storage);
	await bootApp();
	await reporter.case(
		spec(
			"CM-01",
			"Buy one unit from stock 2 using valid buyer/coupon; read terminal, Views, external ledger and S3",
			"Stock 1, coupon used once, one authorization, complete Order, exact S3 SHA-256",
			["VR-LOCAL-002"],
		),
		async () => {
			const input = await seed();
			const result = await purchase(input);
			assert.ok(result.done.text.startsWith("event: view"));
			assert.equal(result.snapshot.order[0].status, "complete");
			assert.equal(result.snapshot.inventory[0].quantity, 1);
			assert.equal(result.snapshot.coupon[0].used, 1);
			assert.equal(
				result.snapshot.ledger.effects.filter(
					(e) => e.operation === "authorize",
				).length,
				1,
			);
			const object = await s3.send(
				new GetObjectCommand({
					Bucket: "vane-dogfood-commerce",
					Key: `${input.id}.json`,
				}),
			);
			const content = await object.Body.transformToString();
			assert.equal(content, JSON.stringify({ orderId: input.id }));
			const sha256 = createHash("sha256").update(content).digest("hex");
			evidence.positive = { input, sagaId: result.sagaId, sha256 };
			return { ...result.snapshot, s3: { content, sha256 } };
		},
	);
	await reporter.case(
		spec(
			"CM-02",
			"Overstock, missing user/coupon, consumed coupon, declined/malformed gateway, invalid quantity/amount; inspect terminal/state/counts",
			"No completion or undue charge; domain rejection never retries",
		),
		async () => {
			const outcomes = [];
			for (const mode of [
				"overstock",
				"missing-user",
				"missing-coupon",
				"consumed-coupon",
				"decline",
				"malformed",
				"undeclared",
				"zero-quantity",
				"negative-quantity",
				"zero-amount",
			]) {
				const input = await seed();
				if (mode === "consumed-coupon")
					await dispatch("Coupon.Use", { couponId: input.couponId });
				if (mode === "overstock") input.quantity = 3;
				if (mode === "missing-user") input.userId = randomUUID();
				if (mode === "missing-coupon") input.couponId = randomUUID();
				if (["decline", "malformed", "undeclared"].includes(mode))
					input.mode = mode;
				if (mode === "zero-quantity") input.quantity = 0;
				if (mode === "negative-quantity") input.quantity = -1;
				if (mode === "zero-amount") input.amount = 0;
				const result = await purchase(input);
				await restored(result, input, {
					couponUsed: mode === "consumed-coupon" ? 1 : 0,
				});
				for (const step of result.done.state.steps)
					assert.ok(
						(step.attempts ?? 0) <= 1,
						`${mode}: retried final rejection ${step.name}`,
					);
				outcomes.push({
					mode,
					sagaId: result.sagaId,
					fail: result.done.state.fail,
				});
			}
			return outcomes;
		},
	);
	await reporter.case(
		spec(
			"CM-03",
			"Disconnect provider first two attempts; exhaust three disconnects and three timeouts",
			"Retry stable Event ID/key and fixed backoff; one external effect; finite safe exhaustion",
		),
		async () => {
			const outcomes = [];
			for (const mode of ["retry", "exhaust", "timeout"]) {
				const input = { ...(await seed()), mode };
				const result = await purchase(input);
				const calls = result.snapshot.ledger.calls.filter(
					(c) => c.operation === "authorize",
				);
				assert.equal(calls.length, 3);
				assert.equal(new Set(calls.map((c) => c.key)).size, 1);
				const authorization = result.done.state.steps.find(
					(s) => s.name === "authorize",
				);
				assert.equal(authorization.attempts, 3);
				assert.equal(calls[0].key, authorization.envelope.eventId);
				for (let i = 1; i < calls.length; i++)
					assert.ok(
						new Date(calls[i].created_at) - new Date(calls[i - 1].created_at) >=
							20,
						"Retry should observe fixed 30ms backoff",
					);
				if (mode === "retry") {
					assert.ok(result.done.text.startsWith("event: view"));
					assert.equal(
						result.snapshot.ledger.effects.filter(
							(e) => e.operation === "authorize",
						).length,
						1,
					);
				} else {
					await restored(result, input);
					const queued = (await operations.failures(1000)).find(
						(f) => f.event_id === authorization.envelope.eventId,
					);
					assert.ok(queued);
					assert.equal(Number(queued.attempt_count), 3);
					result.snapshot.operationalFailure = queued;
					result.snapshot.operationalInspection = await operations.inspectSaga(
						result.sagaId,
					);
				}
				outcomes.push(result.snapshot);
			}
			return outcomes;
		},
	);
	await reporter.case(
		spec(
			"CM-04",
			"Fail S3 after authorization; test transient/exhausted refund; stop real Moto at external authorization barrier",
			"Reverse compensation refunds or records failure, restores stock/coupon/payment/order, continues after failed compensation",
			["VR-LOCAL-002", "VR-LOCAL-003", "VR-LOCAL-004"],
		),
		async () => {
			const outcomes = [];
			for (const mode of [
				"s3-fail",
				"refund-retry",
				"refund-fail",
				"refund-exhaust",
			]) {
				const input = { ...(await seed()), mode };
				const result = await purchase(input);
				await restored(result, input, {
					charged: true,
					refund: !["refund-fail", "refund-exhaust"].includes(mode),
				});
				const state = result.done.state;
				const author = state.steps.find((s) => s.name === "authorize");
				assert.equal(
					author.compensationStatus,
					["refund-fail", "refund-exhaust"].includes(mode) ? "fail" : "success",
				);
				if (["refund-fail", "refund-exhaust"].includes(mode))
					assert.ok(author.compensationFail);
				if (["refund-retry", "refund-exhaust"].includes(mode)) {
					assert.equal(author.compensationAttempts, 3);
					const refunds = result.snapshot.ledger.calls.filter(
						(c) => c.operation === "refund",
					);
					assert.equal(refunds.length, 3);
					assert.equal(new Set(refunds.map((c) => c.key)).size, 1);
				}
				for (const name of ["payment", "reserve", "coupon", "place"])
					assert.equal(
						state.steps.find((s) => s.name === name).compensationStatus,
						"success",
					);
				const compensationIds = new Set(
					state.steps.map((s) => s.compensation?.eventId).filter(Boolean),
				);
				const trace = application.lines.filter(
					(x) => x.dispatch && compensationIds.has(x.eventId),
				);
				const ordered = [...new Set(trace.map((x) => x.eventIdentity))];
				assert.deepEqual(ordered, [
					"Gateway.Refund",
					"Payment.Cancel",
					"Inventory.Release",
					"Coupon.Restore",
					"Order.Cancel",
				]);
				result.snapshot.compensationTrace = trace;
				if (["refund-fail", "refund-exhaust"].includes(mode)) {
					const queue = (await operations.failures(1000)).find(
						(f) => f.event_id === author.compensation.eventId,
					);
					assert.ok(queue);
					assert.ok(["pending", "dead"].includes(queue.status));
					assert.equal(
						Number(queue.attempt_count),
						mode === "refund-exhaust" ? 3 : 1,
					);
					result.snapshot.operationalFailure = queue;
					result.snapshot.operationalInspection = await operations.inspectSaga(
						result.sagaId,
					);
					const beforeTerminal = state.terminal;
					const beforeLedger = await ledger(input.id);
					assert.equal(await operations.resolveFailure(queue.failure_id), true);
					assert.deepEqual(
						(await store.read(result.sagaId)).terminal,
						beforeTerminal,
					);
					assert.deepEqual(await ledger(input.id), beforeLedger);
					assert.equal((await terminal(result.sagaId)).text, result.done.text);
				}
				outcomes.push(result.snapshot);
			}
			const input = { ...(await seed()), mode: "moto-barrier" };
			const sagaId = await admit(input);
			await until(() =>
				gateway.lines.find(
					(x) =>
						x.barrier === "external-effect-committed" && x.orderId === input.id,
				),
			);
			try {
				await moto("stop");
				await fetch(`${gateway.url}/control/release/${input.id}`);
				const done = await terminal(sagaId);
				const snapshotValue = await snapshot(input, sagaId);
				const result = { done, snapshot: snapshotValue };
				await restored(result, input, { charged: true });
				outcomes.push(snapshotValue);
			} finally {
				await moto("start");
				await s3.send(
					new CreateBucketCommand({ Bucket: "vane-dogfood-commerce" }),
				);
			}
			return outcomes;
		},
	);
	await reporter.case(
		spec(
			"CM-05",
			"SIGKILL after Entity commit before Saga checkpoint and after gateway authorization commit before response; restart app and gateway",
			"Original complete envelope and key reused; one stock mutation and one charge; PG survives",
		),
		async () => {
			const outcomes = [];
			await stop(application);
			await bootApp({ COMMERCE_ENTITY_BARRIER: "1" });
			const input = await seed();
			const sagaId = await admit(input);
			const barrier = await until(() =>
				application.lines.find(
					(x) => x.barrier === "entity-committed-before-checkpoint",
				),
			);
			const before = await store.read(sagaId);
			assert.equal(
				before.steps.find((s) => s.name === "reserve").status,
				"executing",
			);
			assert.equal(
				(await view("InventoryDetails", input.stockId))[0].quantity,
				1,
			);
			const death = await stop(application, "SIGKILL");
			assert.equal(death.signal, "SIGKILL");
			await bootApp();
			const done = await terminal(sagaId);
			assert.ok(done.text.startsWith("event: view"));
			const after = await store.read(sagaId);
			assert.deepEqual(
				after.steps.find((s) => s.name === "reserve").envelope,
				barrier.envelope,
			);
			assert.equal(
				(await view("InventoryDetails", input.stockId))[0].quantity,
				1,
			);
			outcomes.push(await snapshot(input, sagaId));
			evidence.crashes.push({
				kind: "entity",
				sagaId,
				before,
				after,
				death,
				barrier,
			});
			const external = { ...(await seed()), mode: "effect-barrier" };
			const externalSaga = await admit(external);
			const effect = await until(() =>
				gateway.lines.find(
					(x) =>
						x.barrier === "external-effect-committed" &&
						x.orderId === external.id,
				),
			);
			const externalBefore = await store.read(externalSaga);
			assert.equal(
				externalBefore.steps.find((s) => s.name === "authorize").status,
				"executing",
			);
			assert.equal(
				(await ledger(external.id)).effects.filter(
					(x) => x.operation === "authorize",
				).length,
				1,
			);
			const gatewayDeath = await stop(gateway, "SIGKILL");
			const appDeath = await stop(application, "SIGKILL");
			await bootGateway();
			await bootApp();
			const externalDone = await terminal(externalSaga);
			assert.ok(externalDone.text.startsWith("event: view"));
			const externalAfter = await store.read(externalSaga);
			assert.deepEqual(
				externalAfter.steps.find((s) => s.name === "authorize").envelope,
				externalBefore.steps.find((s) => s.name === "authorize").envelope,
			);
			const persisted = await ledger(external.id);
			assert.equal(
				persisted.effects.filter((x) => x.operation === "authorize").length,
				1,
			);
			const calls = persisted.calls.filter((x) => x.operation === "authorize");
			assert.ok(calls.length >= 2);
			assert.equal(new Set(calls.map((x) => x.key)).size, 1);
			assert.equal(calls[0].key, effect.key);
			outcomes.push(await snapshot(external, externalSaga));
			evidence.crashes.push({
				kind: "external",
				sagaId: externalSaga,
				before: externalBefore,
				after: externalAfter,
				gatewayDeath,
				appDeath,
				effect,
			});
			return outcomes;
		},
	);
	await reporter.case(
		spec(
			"CM-06",
			"Disconnect pending SSE at authorization barrier; kill/restart runtime; reconnect twice and read View via new HTTP connections",
			"Identical immutable terminal-only SSE with no provider secrets/progress",
		),
		async () => {
			const input = { ...(await seed()), mode: "effect-barrier" };
			const sagaId = await admit(input);
			await until(() =>
				gateway.lines.find(
					(x) =>
						x.barrier === "external-effect-committed" && x.orderId === input.id,
				),
			);
			const controller = new AbortController();
			const stream = fetch(`${application.url}/commerce/sagas/${sagaId}`, {
				signal: controller.signal,
			})
				.then((r) => r.text())
				.catch((e) => e.name);
			await new Promise((r) => setTimeout(r, 50));
			controller.abort();
			assert.equal(await stream, "AbortError");
			await stop(application, "SIGKILL");
			await stop(gateway, "SIGKILL");
			await bootGateway();
			await bootApp();
			const first = await terminal(sagaId);
			const second = await terminal(sagaId);
			const freshPool = new Pool({
				connectionString: defaultEnv.VANE_DOGFOOD_DATABASE_URL,
			});
			try {
				assert.deepEqual(
					(await new PostgreSqlSagaStore(freshPool, storage).read(sagaId))
						.terminal,
					first.state.terminal,
				);
			} finally {
				await freshPool.end();
			}
			assert.equal(first.text, second.text);
			assert.deepEqual(first.state.terminal, second.state.terminal);
			assert.equal(
				(await view("OrderDetails", input.id))[0].status,
				"complete",
			);
			return { sagaId, terminal: first.text, state: first.state };
		},
	);
	await reporter.case(
		spec(
			"CM-07",
			"Round-trip object, graceful process restart, Moto stop/start and explicit bucket recreation, isolated cleanup",
			"Domain/ledger survive restart; Moto reset limitation demonstrated; no implicit real AWS",
			[
				"VR-LOCAL-002",
				"VR-LOCAL-003",
				"VR-LOCAL-004",
				"VR-LOCAL-005",
				"VR-LOCAL-006",
			],
		),
		async () => {
			const input = await seed();
			const result = await purchase(input);
			const before = await snapshot(input, result.sagaId);
			const object = await s3.send(
				new GetObjectCommand({
					Bucket: "vane-dogfood-commerce",
					Key: `${input.id}.json`,
				}),
			);
			assert.equal(
				await object.Body.transformToString(),
				JSON.stringify({ orderId: input.id }),
			);
			await stop(application);
			await stop(gateway);
			await bootGateway();
			await bootApp();
			const after = await snapshot(input, result.sagaId);
			assert.deepEqual(after.order, before.order);
			assert.deepEqual(after.ledger, before.ledger);
			assert.deepEqual(after.state.terminal, before.state.terminal);
			await moto("stop");
			await moto("start");
			let missing = false;
			try {
				await s3.send(
					new HeadObjectCommand({
						Bucket: "vane-dogfood-commerce",
						Key: `${input.id}.json`,
					}),
				);
			} catch (e) {
				missing = e.$metadata?.httpStatusCode === 404;
			}
			assert.ok(
				missing,
				"Moto in-memory object disappearance expected and documented",
			);
			await s3.send(
				new CreateBucketCommand({ Bucket: "vane-dogfood-commerce" }),
			);
			const newInput = await seed();
			const recreated = await purchase(newInput);
			assert.ok(recreated.done.text.startsWith("event: view"));
			await s3.send(
				new HeadObjectCommand({
					Bucket: "vane-dogfood-commerce",
					Key: `${newInput.id}.json`,
				}),
			);
			const namespacesBefore = (
				await pool.query(
					"SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%'",
				)
			).rows
				.map((r) => r.nspname)
				.filter(
					(n) => !["dogfood_commerce", "dogfood_commerce_gateway"].includes(n),
				);
			await stop(application);
			await stop(gateway);
			await seeds.stop();
			seeds = undefined;
			await cleanup();
			const namespacesAfter = (
				await pool.query(
					"SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%'",
				)
			).rows.map((r) => r.nspname);
			assert.ok(!namespacesAfter.includes("dogfood_commerce"));
			assert.ok(!namespacesAfter.includes("dogfood_commerce_gateway"));
			for (const namespace of namespacesBefore)
				assert.ok(namespacesAfter.includes(namespace));
			let bucketAbsent = false;
			try {
				await s3.send(
					new HeadBucketCommand({ Bucket: "vane-dogfood-commerce" }),
				);
			} catch (e) {
				bucketAbsent = e.$metadata?.httpStatusCode === 404;
			}
			assert.ok(bucketAbsent);
			return {
				before,
				after,
				reset: {
					schemasAbsent: true,
					bucketAbsent,
					otherNamespacesPreserved: namespacesBefore,
				},
				motoPersistence:
					"Moto 5.1.18 Docker process is in-memory. Stop/start clears S3; explicit bucket recreation verified. PG domain/ledger persist.",
				smoke:
					"Real AWS smoke deliberately opt-in and out of phase-8 default; no AWS account credentials used",
			};
		},
	);
} catch (error) {
	await reporter.gap(
		spec(
			"CM-BOOTSTRAP",
			"Install/migrate/start consumer",
			"Ready isolated consumer",
		),
		error.stack,
	);
} finally {
	for (const child of children.reverse()) await stop(child).catch(() => {});
	if (seeds) await seeds.stop();
	await pool.end();
	await mkdir(`${directory}../../evidence`, { recursive: true });
	evidence.processLogs = children.map((c) => ({
		url: c.url,
		exitCode: c.exitCode,
		signal: c.signalCode,
		stdout: c.lines,
		stderr: c.stderrText,
	}));
	await writeFile(
		`${directory}../../evidence/commerce-detail.json`,
		JSON.stringify(evidence, null, 2),
	);
	await reporter.finish();
}
