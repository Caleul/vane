import { createServer } from "node:http";
import { Pool } from "pg";
import {
	AclEventRuntime,
	httpAclAdapter,
	materializeSagaPlan,
	PostgreSqlModuleRuntime,
	PostgreSqlViewRuntime,
	PostgreSqlSagaStore,
	PostgreSqlSagaRuntime,
	PostgreSqlPublicSagaAdmission,
	PublicHttpRuntime,
	materializeContract,
	createNodeHttpHandler,
} from "@lilka/vane";
import { module, storage } from "./model.mjs";
const pool = new Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
	max: 20,
});
const adapter = (owner, event, url, success, failure) =>
	httpAclAdapter({
		eventIdentity: `${owner}.${event}`,
		version: "1",
		url,
		idempotencyHeader: "Idempotency-Key",
		responses: [
			{ status: 200, result: success, fields: { reference: "reference" } },
			{ status: 402, result: failure, fields: {} },
		],
	});
const adapters = [
	adapter(
		"Gateway",
		"Authorize",
		process.env.COMMERCE_AUTHORIZE_URL,
		"approved",
		"declined",
	),
	adapter(
		"Gateway",
		"Refund",
		process.env.COMMERCE_REFUND_URL,
		"refunded",
		"declined",
	),
	adapter(
		"ReceiptStorage",
		"Store",
		process.env.COMMERCE_RECEIPT_URL,
		"stored",
		"failed",
	),
];
const authorize = adapters[0];
adapters[0] = {
	...authorize,
	async execute(envelope, signal) {
		if (envelope.payload.mode === "undeclared")
			return { result: "unknown-provider-result", data: {} };
		return authorize.execute(envelope, signal);
	},
};
const acls = new AclEventRuntime(
	module.antiCorruptionLayers.flatMap((x) => x.events),
	adapters,
);
const plan = materializeSagaPlan(module, "Checkout", {}, adapters);
const events = new PostgreSqlModuleRuntime({ module, storage, pool });
const views = new PostgreSqlViewRuntime(module, pool, storage);
await events.start();
const terminals = new PostgreSqlSagaStore(pool, storage);
const defaultPolicy = {
	timeoutMs: 3000,
	retry: { attempts: 3, backoff: "fixed", delayMs: 30, maxDelayMs: 30 },
	idempotency: "required",
	deduplication: "durable",
};
const policies = Object.fromEntries(
	plan.steps
		.flatMap((s) => [s.event, s.compensation?.event].filter(Boolean))
		.map((e) => [e, defaultPolicy]),
);
// Consumer-level dispatch boundary: no private runtime imports or fault injection.
const dispatch = {
	semanticHash: events.semanticHash,
	async dispatch(envelope) {
		const result = await events.dispatch(envelope);
		console.log(
			JSON.stringify({
				dispatch: "entity",
				eventIdentity: envelope.eventIdentity,
				eventId: envelope.eventId,
				result: result.kind,
			}),
		);
		if (
			process.env.COMMERCE_ENTITY_BARRIER === "1" &&
			envelope.eventIdentity === "Inventory.Reserve"
		) {
			console.log(
				JSON.stringify({
					barrier: "entity-committed-before-checkpoint",
					envelope,
					result,
				}),
			);
			await new Promise(() => {});
		}
		return result;
	},
};
const sagas = new PostgreSqlSagaRuntime({
	plans: [plan],
	store: terminals,
	events: dispatch,
	acls: {
		bindings: acls.bindings,
		async dispatch(envelope, timeoutMs) {
			const result = await acls.dispatch(envelope, timeoutMs);
			console.log(
				JSON.stringify({
					dispatch: "acl",
					eventIdentity: envelope.eventIdentity,
					eventId: envelope.eventId,
					result: result.kind,
				}),
			);
			return result;
		},
	},
	views,
	policies,
});
const contract = materializeContract(module, {
	basePath: "/commerce",
	events: [
		{
			event: "Order.Place",
			saga: "Checkout",
			terminal: {
				view: "OrderDetails",
				input: { id: { kind: "eventInput", input: "id" } },
			},
		},
	],
	views: [
		{ view: "OrderDetails" },
		{ view: "PaymentDetails" },
		{ view: "InventoryDetails" },
		{ view: "CouponDetails" },
	],
});
if (!contract.success) throw new Error(JSON.stringify(contract.diagnostics));
const http = new PublicHttpRuntime({
	contract: contract.ir,
	events,
	views,
	terminals,
	admission: new PostgreSqlPublicSagaAdmission(sagas, { "Order.Place": plan }),
});
const server = createServer(createNodeHttpHandler(http));
server.listen(Number(process.env.PORT ?? 0), "127.0.0.1", () =>
	console.log(JSON.stringify({ state: "running", address: server.address() })),
);
const worker = sagas.start(10);
worker.catch((error) => {
	console.error(error);
	process.exitCode = 1;
	server.close();
});
async function shutdown() {
	server.close();
	server.closeAllConnections();
	await sagas.stop();
	await worker;
	await events.stop();
	await pool.end();
}
process.once("SIGTERM", shutdown);
process.once("SIGINT", shutdown);
