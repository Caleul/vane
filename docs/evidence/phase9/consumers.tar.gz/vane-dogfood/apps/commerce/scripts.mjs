import {
	migrate,
	cleanup,
	start,
	stop,
	gatewayEnv,
	cli,
	common,
	directory,
} from "./lib.mjs";
const command = process.argv[2];
if (command === "migrate") console.log(JSON.stringify(await migrate()));
else if (command === "cleanup") await cleanup();
else if (command === "start") {
	const gateway = await start([`${directory}gateway.mjs`]);
	const application = await start(
		[`${directory}server.mjs`],
		gatewayEnv(gateway),
	);
	console.log(
		JSON.stringify({ application: application.url, gateway: gateway.url }),
	);
	const shutdown = async () => {
		await stop(application);
		await stop(gateway);
	};
	process.once("SIGTERM", shutdown);
	process.once("SIGINT", shutdown);
	await application.exited;
	await stop(gateway);
} else throw new Error("Expected migrate, cleanup or start");
