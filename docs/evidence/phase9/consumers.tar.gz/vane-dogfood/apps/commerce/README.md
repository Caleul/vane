# Commerce installed-package dogfood

This application lives outside the Vane repository and installs only `../../artifacts/vane.tgz`. It uses public `@lilka/vane` exports. User, Coupon, Inventory, Order and Payment each own their Events. Checkout creates the order, consumes one coupon, reserves stock, creates Payment, authorizes via ACL, writes an S3 receipt through an application HTTP adapter, and completes Order. Entity compensation releases stock/restores coupon/cancels rows; gateway compensation refunds authorization.

Prerequisite: the root harness has started PostgreSQL 16 and Moto on loopback and generated the identified normal tarball. The following block runs from this folder and does not require opening framework source. Moto restart tests require access to the local Docker daemon and its `vane-dogfood-moto` container.

```sh
export VANE_DOGFOOD_DATABASE_URL=postgresql://vane:vane-local-only@127.0.0.1:55432/vane_dogfood
export VANE_DOGFOOD_MOTO_URL=http://127.0.0.1:55000
export AWS_EC2_METADATA_DISABLED=true
npm ci
npm run typecheck
npm run build
npm run cleanup
npm run migrate
npm test
npm run cleanup
```

`npm test` is the functional HTTP/SSE smoke and complete CM-01–07 suite. It starts real app and gateway processes, seeds using their own public Entity Events, then invokes `POST /commerce/events/Order.Place`, reconnects `/commerce/sagas/:sagaId` and reads Views over HTTP. All assertions inspect durable state after the terminal, never treat admission 202 as success. Test records go to `../../evidence/commerce.json`, `commerce.md` and `commerce-detail.json`.

For interactive operation run `npm run migrate`, then `npm start` in one terminal. It prints application and gateway URLs. `PORT=54002 npm start` binds a known application port. The gateway URLs are wired automatically; the runtime needs the three explicit COMMERCE_* URLs supplied by the start script. Stop with Ctrl-C; `npm run cleanup` drops only `dogfood_commerce`, `dogfood_commerce_gateway`, and the dedicated `vane-dogfood-commerce` S3 bucket. Stop processes before cleanup. Migration is idempotent; repeated `npm test` performs an isolated reset itself.

The stand-in payment provider persists calls and effects in its own PostgreSQL schema. Each authorize/refund operation has a unique Event ID key and one ledger effect per key. Gateway restart retains this ledger. S3 receipt keys are stable per order. All AWS calls use pinned SDK, an explicit loopback HTTP endpoint, dummy credentials, `AWS_EC2_METADATA_DISABLED=true`, one transport attempt, and region redirects disabled. There is no fallback endpoint or cloud account access. Moto is a functional protocol fixture, not evidence of real S3 durability/fidelity. The current Moto server is in-memory: Docker stop/start clears S3; the tests explicitly observe missing objects and recreate the bucket. Domain and payment ledger durability are asserted independently. Real AWS smoke is a future explicit opt-in activity, outside this suite.

Crash tests SIGKILL actual processes at observable public dispatch boundaries. An application wrapper awaits successful Inventory Event dispatch and then deliberately holds the returned result before the Saga checkpoint. The external gateway commits its authorization ledger and holds the HTTP response. Restart replays original persisted envelopes/keys; tests assert one protected stock mutation/charge despite multiple provider calls. There are no private imports or framework fault injection. Retry/compensation fault modes belong to this external test fixture, not the domain API.

## Coverage

- CM-01: stock 2→1, coupon 0→1, one charge, complete order, S3 bytes/hash.
- CM-02: overstock, absent User/Coupon, unusable coupon, payment declined, malformed and undeclared ACL result, nonpositive quantity/amount; final rejection, no retries or charge, compensated state.
- CM-03: two transport failures then success; three failures and three timeouts exhaust; stable Event ID/key, fixed backoff, one success effect.
- CM-04: real Moto shutdown after authorization and missing-bucket S3 failures; refund success, transient refund retry, exhausted refund, final refund decline; reverse-causal compensation and remaining steps continue.
- CM-05: Entity commit before checkpoint and external effect before checkpoint; SIGKILL/restart, complete immutable envelopes, durable ledger, one mutation/effect.
- CM-06: cancel pending SSE, runtime/gateway restart, identical terminal reconnect twice, fresh View and no progress/provider fields/secrets.
- CM-07: S3 round-trip, app/provider graceful restart, domain/ledger preservation, explicit Moto loss/recreation; cleanup separately validates isolation.

## Implementer source consultations and friction

Implementation consulted `docs/phase-8-plan.md`, `docs/sagas.md`, `docs/postgresql.md`, `docs/service-configuration.md`, the public Sales/Billing example, installed package public `.d.ts`, and source `dsl.ts`, `execution-policy.ts`, `service-compiler.ts`, `acl-runtime.ts` for diagnosis. These are recorded consultations; this implementation run is not an independent adoption reproduction.

1. DX/P2: a Rule referring to one Column is rejected (`VANE_SEM_RULE_ARITY`); the correction states to use a Column constraint. Inventory now uses `quantity >= 0` as a Column minimum and a two-column `quantity <= capacity` Rule. Error→correction→successful compile is reproduced by the installed compiler.
2. DX/P2: exposing a direct Entity Event without a terminal View produces generic CLI failure. Installed typed contract requires a terminal. Bootstrap now dispatches owned Events through the documented public module runtime; only Checkout is an HTTP Event exposure.
3. DX/P2: direct HTTP View response is a row array, while terminal SSE View includes `{kind, view, data}`. Tests now use their actual public formats.
4. Conceptual/P2: Moto process restart has no object persistence in this setup. Explicit recreation is tested and documented; no domain recovery claim depends on Moto object survival.

No framework source change was needed. Node 24+, PostgreSQL16+, and gateway/runtime endpoints are mandatory. The account, coupon and inventory IDs are independent per purchase; order quantities persist with `minimum:1`, so nonpositive requests fail at Order creation before stock/coupon/payment effects.
