import { createServer } from "node:http";
import pg from "pg";
import { createServiceRuntime } from "@lilka/vane";
import { configuration, namespace, result } from "./configuration.mjs";
const raw = new pg.Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
	max: 10,
});
let armed = false,
	barrier = null;
const outbox = result.plan.storage.tables.find(
	(t) => t.semanticId === "vane.infrastructure.outbox",
).name;
// Public structural pool binding. Domain writes remain entirely framework-owned.
// Observe INSERT into generated outbox then the matching transaction's successful COMMIT.
const pool = {
	query: (...args) => raw.query(...args),
	connect: async () => {
		const client = await raw.connect();
		let eventId = null;
		return {
			release: () => client.release(),
			query: async (text, values) => {
				const response = await client.query(text, values);
				if (
					armed &&
					typeof text === "string" &&
					text.startsWith(`INSERT INTO "${namespace}"."${outbox}"`)
				)
					eventId = values[1];
				if (armed && eventId && text === "COMMIT") {
					armed = false;
					barrier = {
						kind: "entity-commit-before-checkpoint",
						eventId,
						timestamp: new Date().toISOString(),
						identification: `INSERT ${outbox} then successful COMMIT on same reserved client`,
					};
					console.log(JSON.stringify({ barrier }));
					await new Promise(() => {});
				}
				return response;
			},
		};
	},
};
const runtime = await createServiceRuntime(configuration, "test", { pool });
await runtime.start();
let worker;
function workers() {
	if (!worker)
		worker = runtime.runWorkers().catch((e) => {
			console.error(e);
			process.exitCode = 1;
			server.close();
		});
}
const server = createServer(async (req, res) => {
	try {
		if (
			process.env.VANE_TODO_TEST_CONTROL === "1" &&
			req.url.startsWith("/__test/")
		) {
			res.setHeader("content-type", "application/json");
			if (req.url === "/__test/workers" && req.method === "POST") {
				workers();
				res.end("{}");
				return;
			}
			if (req.url === "/__test/arm" && req.method === "POST") {
				armed = true;
				res.end("{}");
				return;
			}
			if (req.url === "/__test/barrier") {
				res.end(JSON.stringify(barrier));
				return;
			}
			if (req.url.startsWith("/__test/saga/")) {
				res.end(
					JSON.stringify(
						await runtime.modules[0].store.read(req.url.split("/").at(-1)),
					),
				);
				return;
			}
			if (req.url === "/__test/replay" && req.method === "POST") {
				let data = "";
				for await (const chunk of req) data += chunk;
				res.end(
					JSON.stringify(
						await runtime.modules[0].events.dispatch(JSON.parse(data)),
					),
				);
				return;
			}
			res.statusCode = 404;
			res.end("{}");
			return;
		}
		await runtime.handler(req, res);
	} catch (e) {
		res.statusCode = 500;
		res.end(JSON.stringify({ error: e.message }));
	}
});
await new Promise((resolve) =>
	server.listen(Number(process.env.PORT ?? 0), "127.0.0.1", resolve),
);
if (process.env.VANE_TODO_PAUSE_WORKERS !== "1") workers();
console.log(
	JSON.stringify({ ready: true, address: server.address(), namespace }),
);
async function stop() {
	server.close();
	await runtime.stop();
	await worker;
	await raw.end();
}
process.once("SIGTERM", () =>
	stop()
		.then(() => process.exit(0))
		.catch((e) => {
			console.error(e);
			process.exit(1);
		}),
);
