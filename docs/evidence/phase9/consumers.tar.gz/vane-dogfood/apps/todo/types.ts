import type {
	CreateTodoInput,
	TodoCardInput,
	TodoCardRow,
} from "./model.vane.js";
const input: CreateTodoInput = {
	id: "id",
	projectId: "id",
	title: "task",
	totalUnits: 3,
	completedUnits: 0,
};
const query: TodoCardInput = { id: "id" };
const row: TodoCardRow = { ...input };
// @ts-expect-error inferred numeric Column rejects a string
const invalid: CreateTodoInput = { ...input, totalUnits: "3" };
// @ts-expect-error inferred View input requires id
const missing: TodoCardInput = {};
void [query, row, invalid, missing];
