import { readFileSync } from "node:fs";
import {
	BUILTIN_PROVIDERS,
	compileProjectSources,
	serviceConfiguration,
	monolith,
	node,
	postgres,
	env,
	postgresMailbox,
	postgresOutbox,
	postgresDeduplication,
	postgresSaga,
	postgresFailureQueue,
	http,
	sse,
	compileServiceConfiguration,
} from "@lilka/vane";
export const sourceText = readFileSync(
	new URL("model.vane.ts", import.meta.url),
	"utf8",
);
export const compiled = compileProjectSources([
	{ fileName: "model.vane.ts", sourceText },
]);
if (!compiled.success) throw new Error(JSON.stringify(compiled.diagnostics));
export const namespace = process.env.VANE_TODO_NAMESPACE ?? "dogfood_todo";
export const configuration = serviceConfiguration({
	application: "todo",
	project: compiled.ir,
	providers: BUILTIN_PROVIDERS,
	profiles: {
		test: {
			environment: "test",
			topology: monolith({
				name: "api",
				modules: ["Tasks"],
				runtime: node(),
				persistence: {
					provider: postgres(),
					namespace,
					targetVersion: 16,
					connection: env("VANE_DOGFOOD_DATABASE_URL"),
				},
			}),
			communication: {
				mailbox: postgresMailbox(),
				outbox: postgresOutbox(),
				deduplication: postgresDeduplication(),
				saga: postgresSaga(),
				failureQueue: postgresFailureQueue(),
			},
			http: {
				provider: http(),
				sagaStream: sse(),
				security: {
					authentication: "none",
					authorization: "allow",
					cors: [],
					rateLimit: null,
				},
			},
			contracts: {
				Tasks: {
					basePath: "/tasks",
					events: [
						"Project.Create",
						"Project.Update",
						"Project.Delete",
						"Todo.Create",
						"Todo.Update",
						"Todo.Complete",
						"Todo.Delete",
					].map((event) => ({
						event,
						saga: event.replace(".", ""),
						terminal: {
							view: event.startsWith("Project") ? "ProjectCard" : "TodoCard",
							input: { id: { kind: "eventInput", input: "id" } },
						},
					})),
					views: [
						{ view: "ProjectCard" },
						{ view: "TodoCard" },
						{ view: "TodoList" },
					],
				},
			},
		},
	},
});
export const result = compileServiceConfiguration(configuration, "test");
if (!result.success) throw new Error(JSON.stringify(result.diagnostics));
export default configuration;
