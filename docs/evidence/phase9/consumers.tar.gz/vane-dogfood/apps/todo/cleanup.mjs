import pg from "pg";
const namespace = process.env.VANE_TODO_NAMESPACE ?? "dogfood_todo";
if (!/^dogfood_todo(?:_[a-z0-9_]+)?$/.test(namespace))
	throw new Error("Refusing namespace outside Todo test scope");
const pool = new pg.Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
});
try {
	await pool.query(`DROP SCHEMA IF EXISTS "${namespace}" CASCADE`);
	console.log(`Cleaned ${namespace}`);
} finally {
	await pool.end();
}
