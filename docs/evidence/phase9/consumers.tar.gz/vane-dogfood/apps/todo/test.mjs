import assert from "node:assert/strict";
import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import { randomUUID, createHash } from "node:crypto";
import { mkdir, writeFile, readFile } from "node:fs/promises";
import pg from "pg";
import { compileProjectSources } from "@lilka/vane";
import { createReporter } from "../../harness/evidence.mjs";
const started = Date.now(),
	report = createReporter("todo"),
	namespace = `dogfood_todo_${process.pid}`;
process.env.VANE_TODO_NAMESPACE = namespace;
const { sourceText, result } = await import("./configuration.mjs");
const pool = new pg.Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
});
const children = [],
	transcripts = [],
	snapshots = [],
	processLogs = [];
let app, projectId, todoId;
const sqlTable = (id) =>
	`"${namespace}"."${result.plan.storage.tables.find((t) => t.semanticId === id).name}"`;
const invoke = (file, args = []) =>
	promisify(execFile)(process.execPath, [file, ...args], {
		env: process.env,
		timeout: 20000,
	});
function spec(id, action, expected) {
	return {
		id,
		requirements: {
			"TD-01": [
				"VR-DX-001",
				"VR-LOCAL-001",
				"EE-EVT-005",
				"EE-VIEW-003",
				"EE-VIEW-004",
			],
			"TD-02": ["VR-DX-004", "EE-EVT-010", "EE-EVT-016"],
			"TD-03": ["VR-DX-004", "EE-EVT-005", "EE-COMP-003"],
			"TD-04": ["VR-LOCAL-004", "EE-PG-006"],
			"TD-05": ["VR-LOCAL-005", "EE-PG-005", "EE-RUN-005", "EE-NFR-008"],
			"TD-06": ["VR-DX-002", "VR-DX-003", "VR-DX-008", "VR-LOCAL-002"],
			"TD-06-package": ["VR-DX-002", "VR-DX-003", "VR-LOCAL-002"],
		}[id] ?? ["VR-LOCAL-001"],
		precondition:
			"Installed normal tarball; PostgreSQL16; isolated namespace; actual Node server",
		action,
		expected,
	};
}
async function start(pause = false) {
	const child = spawn(process.execPath, ["server.mjs"], {
		env: {
			...process.env,
			VANE_TODO_TEST_CONTROL: "1",
			VANE_TODO_PAUSE_WORKERS: pause ? "1" : "0",
			PORT: "0",
		},
		stdio: ["ignore", "pipe", "pipe"],
	});
	children.push(child);
	const lifecycle = {
		pid: child.pid,
		startedAt: new Date().toISOString(),
		paused: pause,
		stdout: "",
		stderr: "",
	};
	processLogs.push(lifecycle);
	child.stdout.on("data", (d) => (lifecycle.stdout += d));
	child.stderr.on("data", (d) => (lifecycle.stderr += d));
	child.once("exit", (code, signal) =>
		Object.assign(lifecycle, {
			exitedAt: new Date().toISOString(),
			code,
			signal,
		}),
	);
	child.exited = new Promise((resolve) =>
		child.once("exit", (code, signal) => resolve({ code, signal })),
	);
	let out = "",
		err = "";
	child.stderr.on("data", (d) => (err += d));
	return new Promise((resolve, reject) => {
		const timer = setTimeout(
			() => reject(new Error(`Readiness timeout: ${err}`)),
			15000,
		);
		child.once("exit", () => {
			clearTimeout(timer);
			reject(new Error(`Server exited ${err}`));
		});
		child.stdout.on("data", (d) => {
			out += d;
			for (const line of out.split("\n")) {
				try {
					const v = JSON.parse(line);
					if (v.ready) {
						clearTimeout(timer);
						resolve({ child, url: `http://127.0.0.1:${v.address.port}` });
					}
				} catch {}
			}
		});
	});
}
async function stop(application, signal = "SIGTERM") {
	if (
		!application ||
		application.child.exitCode !== null ||
		application.child.signalCode !== null
	)
		return;
	application.child.kill(signal);
	const timer = setTimeout(() => application.child.kill("SIGKILL"), 10000);
	const outcome = await application.child.exited;
	clearTimeout(timer);
	if (signal === "SIGTERM")
		assert.deepEqual(outcome, { code: 0, signal: null });
	else assert.equal(outcome.signal, "SIGKILL");
	return outcome;
}
async function request(
	path,
	body,
	method = body === undefined ? "GET" : "POST",
) {
	const response = await fetch(`${app.url}${path}`, {
		method,
		headers: { "content-type": "application/json" },
		body: body === undefined ? undefined : JSON.stringify(body),
		signal: AbortSignal.timeout(12000),
	});
	const text = await response.text();
	transcripts.push({
		timestamp: new Date().toISOString(),
		method,
		path,
		body,
		status: response.status,
		text,
	});
	let data;
	try {
		data = JSON.parse(text);
	} catch {
		data = text;
	}
	return { status: response.status, data, text };
}
async function admit(event, payload) {
	const r = await request(`/tasks/events/${event}`, payload);
	assert.equal(r.status, 202, r.text);
	assert.equal(typeof r.data.sagaId, "string");
	assert.deepEqual(Object.keys(r.data), ["sagaId"]);
	return r.data.sagaId;
}
async function terminal(sagaId, kind = "view") {
	const r = await request(`/tasks/sagas/${sagaId}`);
	assert.equal(r.status, 200, r.text);
	assert.ok(r.text.startsWith(`event: ${kind}\n`), r.text);
	assert.equal((r.text.match(/^event:/gm) ?? []).length, 1);
	const data = JSON.parse(r.text.split("\ndata: ")[1].trim());
	return { data, frame: r.text };
}
async function event(name, payload, kind = "view") {
	return terminal(await admit(name, payload), kind);
}
async function view(name, input) {
	const r = await request(`/tasks/views/${name}`, input);
	assert.equal(r.status, 200, r.text);
	return { data: r.data };
}
async function snapshot(label) {
	const data = {
		label,
		timestamp: new Date().toISOString(),
		todos: (
			await pool.query(`SELECT * FROM ${sqlTable("Tasks.Todo")} ORDER BY id`)
		).rows,
		projects: (
			await pool.query(`SELECT * FROM ${sqlTable("Tasks.Project")} ORDER BY id`)
		).rows,
		mailbox: (
			await pool.query(
				`SELECT * FROM ${sqlTable("vane.infrastructure.mailbox")} ORDER BY event_id`,
			)
		).rows,
		outbox: (
			await pool.query(
				`SELECT * FROM ${sqlTable("vane.infrastructure.outbox")} ORDER BY event_id`,
			)
		).rows,
		sagas: (
			await pool.query(
				`SELECT * FROM ${sqlTable("vane.infrastructure.sagas")} ORDER BY saga_id`,
			)
		).rows,
	};
	snapshots.push(data);
	return data;
}
async function counts(eventId, id) {
	return {
		todo: (
			await pool.query(`SELECT * FROM ${sqlTable("Tasks.Todo")} WHERE id=$1`, [
				id,
			])
		).rows[0],
		mailbox: Number(
			(
				await pool.query(
					`SELECT count(*) n FROM ${sqlTable("vane.infrastructure.mailbox")} WHERE event_id=$1`,
					[eventId],
				)
			).rows[0].n,
		),
		outbox: Number(
			(
				await pool.query(
					`SELECT count(*) n FROM ${sqlTable("vane.infrastructure.outbox")} WHERE event_id=$1`,
					[eventId],
				)
			).rows[0].n,
		),
	};
}
try {
	await report.case(
		spec(
			"TD-01",
			"Create Project/Todo, atomic Complete, update/delete, filter and paginate HTTP Views",
			"Owner mutations succeed; final-only SSE; explicit reference; stable ordered pages",
		),
		async () => {
			await invoke("cleanup.mjs");
			await invoke("migrate.mjs");
			app = await start();
			projectId = randomUUID();
			todoId = randomUUID();
			assert.equal(
				(
					await pool.query("SHOW server_version_num")
				).rows[0].server_version_num.slice(0, 2),
				"16",
			);
			await event("Project.Create", { id: projectId, name: "Dogfood" });
			const input = {
				id: todoId,
				projectId,
				title: "initial-alpha",
				totalUnits: 5,
				completedUnits: 0,
			};
			const created = await event("Todo.Create", input);
			assert.deepEqual(created.data.data, [input]);
			const timeToFirstSuccessMs = Date.now() - started;
			await event("Todo.Complete", { id: todoId, units: 2 });
			await event("Todo.Update", { id: todoId, title: "alpha", totalUnits: 6 });
			const a = await view("TodoCard", { id: todoId });
			assert.equal(a.data[0].completedUnits, 2);
			assert.equal(a.data[0].totalUnits, 6);
			const ids = [];
			for (const title of ["bravo", "charlie", "delta"]) {
				const id = randomUUID();
				ids.push(id);
				await event("Todo.Create", {
					id,
					projectId,
					title,
					totalUnits: 5,
					completedUnits: 0,
				});
			}
			const p1 = await view("TodoList", {
				projectId,
				completedUnits: 0,
				limit: 2,
				offset: 0,
			});
			const p2 = await view("TodoList", {
				projectId,
				completedUnits: 0,
				limit: 2,
				offset: 2,
			});
			assert.deepEqual(
				p1.data.map((r) => r.title),
				["bravo", "charlie"],
			);
			assert.deepEqual(
				p2.data.map((r) => r.title),
				["delta"],
			);
			await event("Todo.Delete", { id: ids[2] });
			assert.deepEqual((await view("TodoCard", { id: ids[2] })).data, []);
			const temporary = randomUUID();
			await event("Project.Create", { id: temporary, name: "temporary" });
			await event("Project.Update", { id: temporary, name: "renamed" });
			assert.equal(
				(await view("ProjectCard", { id: temporary })).data[0].name,
				"renamed",
			);
			await event("Project.Delete", { id: temporary });
			assert.equal(
				result.plan.storage.tables.filter((t) => !t.technical).length,
				2,
			);
			const viewBefore = (
				await pool.query(`SELECT * FROM ${sqlTable("Tasks.Todo")} ORDER BY id`)
			).rows;
			await view("TodoList", {
				projectId,
				completedUnits: 0,
				limit: 50,
				offset: 0,
			});
			assert.deepEqual(
				(
					await pool.query(
						`SELECT * FROM ${sqlTable("Tasks.Todo")} ORDER BY id`,
					)
				).rows,
				viewBefore,
			);
			await snapshot("TD-01");
			return {
				projectId,
				todoId,
				pages: [p1.data, p2.data],
				timeToFirstSuccessMs,
			};
		},
	);
	await report.case(
		spec(
			"TD-02",
			"Typed input, nonexistent reference, numeric bounds, Rule, forbidden parent delete, malformed View input",
			"Safe fail or rejected request; no protected state change",
		),
		async () => {
			const initial = await view("TodoCard", { id: todoId });
			const initialDomain = await snapshot("TD-02 before");
			const failures = [];
			const duplicate = await event(
				"Todo.Create",
				{
					id: todoId,
					projectId,
					title: "duplicate",
					totalUnits: 8,
					completedUnits: 0,
				},
				"fail",
			);
			failures.push(duplicate.data);
			for (const payload of [
				{
					id: randomUUID(),
					projectId: randomUUID(),
					title: "fk",
					totalUnits: 1,
					completedUnits: 0,
				},
				{
					id: randomUUID(),
					projectId,
					title: "rule",
					totalUnits: 1,
					completedUnits: 2,
				},
				{
					id: randomUUID(),
					projectId,
					title: "negative",
					totalUnits: -1,
					completedUnits: 0,
				},
				{
					id: randomUUID(),
					projectId,
					title: "",
					totalUnits: 1,
					completedUnits: 0,
				},
			]) {
				const f = await event("Todo.Create", payload, "fail");
				failures.push(f.data);
				assert.ok(!f.frame.includes("stack"));
			}
			failures.push(
				(await event("Todo.Complete", { id: todoId, units: 99 }, "fail")).data,
			);
			failures.push(
				(
					await event(
						"Todo.Update",
						{ id: todoId, title: "bad", totalUnits: 1 },
						"fail",
					)
				).data,
			);
			failures.push(
				(await event("Project.Delete", { id: projectId }, "fail")).data,
			);
			const bad = await request("/tasks/events/Todo.Create", {
				id: "bad",
				projectId,
				title: "bad",
				totalUnits: "1",
				completedUnits: 0,
			});
			assert.equal(bad.status, 400);
			assert.equal(
				(
					await request("/tasks/views/TodoList", {
						projectId,
						completedUnits: 0,
						limit: "bad",
						offset: 0,
					})
				).status,
				400,
			);
			assert.deepEqual(
				(await view("TodoCard", { id: todoId })).data,
				initial.data,
			);
			const afterDomain = await snapshot("TD-02");
			assert.deepEqual(afterDomain.todos, initialDomain.todos);
			assert.deepEqual(afterDomain.projects, initialDomain.projects);
			return { failures, typedRejection: bad.data };
		},
	);
	await report.case(
		spec(
			"TD-03",
			"Compile a one-Column Rule, invalid reference, unknown Event column, illegal runtime/domain callback",
			"Actionable diagnostics with code/source/correction; no partial IR",
		),
		async () => {
			const variants = [
				sourceText.replace(
					'lte(column("completedUnits"), column("totalUnits"))',
					'lte(column("completedUnits"), column("completedUnits"))',
				),
				sourceText.replace(
					'reference(Project, "id")',
					'reference(Project, "missing")',
				),
				sourceText.replace(
					/title:\s*input\("title"\),\s*totalUnits:\s*input\("totalUnits"\)/,
					'"Project.name": input("title"), totalUnits: input("totalUnits")',
				),
				sourceText.replace('name: input("name")', 'name: (() => "hidden")()'),
			];
			const diagnostics = [];
			for (const source of variants) {
				assert.notEqual(
					source,
					sourceText,
					"Negative fixture must change the valid source",
				);
				const c = compileProjectSources([
					{ fileName: "invalid.vane.ts", sourceText: source },
				]);
				assert.equal(c.success, false);
				assert.ok(!("ir" in c));
				assert.ok(c.diagnostics.length);
				for (const d of c.diagnostics) {
					assert.ok(d.code);
					assert.ok(d.message);
					assert.ok(d.correction);
					assert.ok(d.location);
				}
				diagnostics.push(c.diagnostics);
				const file = "evidence/invalid.vane.ts";
				await mkdir("evidence", { recursive: true });
				await writeFile(file, source);
				let exit;
				try {
					await invoke("diagnose.mjs", [file]);
				} catch (e) {
					exit = e.code;
				}
				assert.equal(exit, 1);
			}
			let bindingFailure;
			try {
				await invoke("diagnose.mjs", ["--missing-binding"]);
			} catch (e) {
				assert.equal(e.code, 1);
				bindingFailure = JSON.parse(e.stdout);
			}
			assert.ok(bindingFailure.diagnostics.length);
			assert.ok(
				bindingFailure.diagnostics.every(
					(d) => d.message && d.correction && d.path,
				),
			);
			assert.ok(!("plan" in bindingFailure));
			assert.equal(
				compileProjectSources([{ fileName: "corrected.vane.ts", sourceText }])
					.success,
				true,
			);
			await invoke("diagnose.mjs", ["--correct-binding"]);
			return {
				diagnostics,
				bindingFailure,
				corrected:
					"Original documented declaration and binding validate; negative processes exit1",
			};
		},
	);
	await report.case(
		spec(
			"TD-04",
			"Inspect generated schema, persist state/terminals through graceful process replacement",
			"Identity/reference/Rule/revision/mailbox/outbox installed; data and terminal match after restart",
		),
		async () => {
			const before = await view("TodoCard", { id: todoId });
			const sid = await admit("Todo.Complete", { id: todoId, units: 1 });
			const final = await terminal(sid);
			const constraints = (
				await pool.query(
					"SELECT conname,pg_get_constraintdef(oid) definition FROM pg_constraint WHERE connamespace=$1::regnamespace",
					[namespace],
				)
			).rows;
			assert.ok(
				constraints.some((c) =>
					c.definition.includes("completed_units <= total_units"),
				),
			);
			assert.ok(
				constraints.some((c) => c.definition.startsWith("FOREIGN KEY")),
			);
			const historyBefore = (
				await pool.query(
					`SELECT * FROM "${namespace}"."__vane_migrations" ORDER BY applied_at`,
				)
			).rows;
			const schemaBefore = (
				await pool.query(
					"SELECT table_name,column_name,data_type,is_nullable FROM information_schema.columns WHERE table_schema=$1 ORDER BY table_name,ordinal_position",
					[namespace],
				)
			).rows;
			const data = await snapshot("TD-04 before restart");
			assert.ok(data.mailbox.length > 0);
			assert.ok(data.outbox.length > 0);
			assert.ok(data.todos.some((r) => Number(r.__vane_revision) > 0));
			await stop(app);
			app = await start();
			assert.equal(
				(await view("TodoCard", { id: todoId })).data[0].completedUnits,
				before.data[0].completedUnits + 1,
			);
			assert.deepEqual((await terminal(sid)).data, final.data);
			const fresh = new pg.Client({
				connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
			});
			await fresh.connect();
			try {
				assert.equal(
					Number(
						(
							await fresh.query(
								`SELECT completed_units FROM ${sqlTable("Tasks.Todo")} WHERE id=$1`,
								[todoId],
							)
						).rows[0].completed_units,
					),
					before.data[0].completedUnits + 1,
				);
				assert.deepEqual(
					(
						await fresh.query(
							`SELECT * FROM "${namespace}"."__vane_migrations" ORDER BY applied_at`,
						)
					).rows,
					historyBefore,
				);
				assert.deepEqual(
					(
						await fresh.query(
							"SELECT table_name,column_name,data_type,is_nullable FROM information_schema.columns WHERE table_schema=$1 ORDER BY table_name,ordinal_position",
							[namespace],
						)
					).rows,
					schemaBefore,
				);
			} finally {
				await fresh.end();
			}
			return {
				constraints,
				persistedTerminal: final.data,
				migrationHistory: historyBefore,
				schema: schemaBefore,
			};
		},
	);
	await report.case(
		spec(
			"TD-05",
			"SIGKILL after durable admission and after Entity COMMIT before Saga checkpoint; restart and replay exact stored envelope",
			"Same persisted Event ID; one protected mutation, mailbox/outbox each one; final-only retained terminal",
		),
		async () => {
			const timelines = [];
			await stop(app);
			app = await start(true);
			const admissionId = randomUUID(),
				payload = {
					id: admissionId,
					projectId,
					title: "admission-recovery",
					totalUnits: 10,
					completedUnits: 0,
				};
			const sagaId = await admit("Todo.Create", payload);
			const admitted = (await request(`/__test/saga/${sagaId}`)).data;
			assert.equal(
				(await view("TodoCard", { id: admissionId })).data.length,
				0,
			);
			const admissionEnvelope = admitted.steps.find(
				(s) => s.name === "apply",
			).envelope;
			assert.equal(
				(await counts(admissionEnvelope.eventId, admissionId)).mailbox,
				0,
			);
			timelines.push({
				point: "admission durable/no execution",
				sagaId,
				state: admitted,
				timestamp: new Date().toISOString(),
			});
			await stop(app, "SIGKILL");
			app = await start();
			const recovered = await terminal(sagaId);
			assert.equal(recovered.data.data[0].id, admissionId);
			const admissionAfter = (await request(`/__test/saga/${sagaId}`)).data;
			assert.deepEqual(
				admissionAfter.steps.find((s) => s.name === "apply").envelope,
				admissionEnvelope,
			);
			const admissionCounts = await counts(
				admissionEnvelope.eventId,
				admissionId,
			);
			assert.equal(admissionCounts.mailbox, 1);
			assert.equal(admissionCounts.outbox, 1);
			assert.equal(Number(admissionCounts.todo.__vane_revision), 1);
			await stop(app);
			app = await start(true);
			await request("/__test/arm", {});
			const before = await view("TodoCard", { id: todoId });
			const crashSaga = await admit("Todo.Complete", { id: todoId, units: 2 });
			await request("/__test/workers", {});
			let barrier;
			for (let n = 0; n < 200; n++) {
				barrier = (await request("/__test/barrier")).data;
				if (barrier) break;
				await new Promise((r) => setTimeout(r, 25));
			}
			assert.ok(barrier, "Event transaction barrier was not reached");
			const executing = (await request(`/__test/saga/${crashSaga}`)).data;
			const persistedEnvelope = executing.steps.find(
				(s) => s.name === "apply",
			).envelope;
			assert.equal(persistedEnvelope.eventId, barrier.eventId);
			assert.equal(
				executing.steps.find((s) => s.name === "apply").status,
				"executing",
			);
			const committed = await counts(barrier.eventId, todoId);
			assert.equal(
				Number(committed.todo.completed_units),
				before.data[0].completedUnits + 2,
			);
			assert.equal(committed.mailbox, 1);
			assert.equal(committed.outbox, 1);
			timelines.push({
				point: "commit before checkpoint",
				barrier,
				state: executing,
				counts: committed,
				timestamp: new Date().toISOString(),
			});
			await snapshot("TD-05 before SIGKILL");
			await stop(app, "SIGKILL");
			app = await start();
			const final = await terminal(crashSaga);
			assert.equal(
				final.data.data[0].completedUnits,
				before.data[0].completedUnits + 2,
			);
			const after = await counts(barrier.eventId, todoId);
			assert.equal(after.todo.__vane_revision, committed.todo.__vane_revision);
			assert.equal(after.mailbox, 1);
			assert.equal(after.outbox, 1);
			const resumed = (await request(`/__test/saga/${crashSaga}`)).data;
			assert.deepEqual(
				resumed.steps.find((s) => s.name === "apply").envelope,
				persistedEnvelope,
			);
			const replay = await request("/__test/replay", persistedEnvelope);
			assert.equal(replay.status, 200);
			assert.equal(replay.data.kind, "duplicate");
			assert.deepEqual(await counts(barrier.eventId, todoId), after);
			timelines.push({
				point: "recovered and exact envelope duplicate",
				final: final.data,
				state: resumed,
				replay: replay.data,
				counts: after,
				timestamp: new Date().toISOString(),
			});
			await snapshot("TD-05 recovered");
			return {
				admissionSaga: sagaId,
				commitSaga: crashSaga,
				persistedEnvelope,
				timelines,
			};
		},
	);
	await report.case(
		spec(
			"TD-06-package",
			"Typecheck/build consumer and infer EventInput/View types using installed public package",
			"Positive and negative TypeScript fixtures compile; only public imports; own lockfile/scripts",
		),
		async () => {
			await promisify(execFile)("npm", ["run", "typecheck"], {
				timeout: 30000,
			});
			await promisify(execFile)("npm", ["run", "build"], { timeout: 30000 });
			const pkg = JSON.parse(await readFile("package.json", "utf8"));
			const lock = JSON.parse(await readFile("package-lock.json", "utf8"));
			assert.equal(
				pkg.dependencies["@lilka/vane"],
				"file:../../artifacts/vane.tgz",
			);
			assert.equal(
				lock.packages["node_modules/@lilka/vane"].integrity,
				"sha512-" +
					createHash("sha512")
						.update(await readFile("../../artifacts/vane.tgz"))
						.digest("base64"),
			);
			assert.ok(
				import.meta
					.resolve("@lilka/vane")
					.startsWith(
						new URL("node_modules/@lilka/vane/", import.meta.url).href,
					),
			);
			return {
				package: pkg.name,
				scripts: Object.keys(pkg.scripts),
				sourceConsultations: [
					"published semantic/compiler/runtime guides",
					"public Sales/Billing example",
					"framework service-runtime return members",
					"framework event transaction COMMIT identification",
				],
				independentAdopter: false,
			};
		},
	);
} catch (error) {
	await report.case(
		spec(
			"TD-INFRA",
			"Initialize PostgreSQL16 and consumer",
			"Available infrastructure",
		),
		async () => {
			throw error;
		},
	);
} finally {
	await report.na(
		{ id: "TD-AWS", requirements: ["VR-LOCAL-006"] },
		"Todo has no AWS dependency; Moto is inapplicable.",
	);
	await mkdir("evidence", { recursive: true });
	await writeFile(
		"evidence/storage-ir.json",
		JSON.stringify(result.plan.storage, null, 2),
	);
	await writeFile(
		"evidence/contracts.json",
		JSON.stringify(result.plan.contracts, null, 2),
	);
	await writeFile(
		"evidence/transcripts.json",
		JSON.stringify(transcripts, null, 2),
	);
	await writeFile(
		"evidence/snapshots.json",
		JSON.stringify(snapshots, null, 2),
	);
	try {
		await stop(app);
	} catch (e) {
		console.error(e.message);
	}
	for (const child of children) {
		if (child.exitCode === null && child.signalCode === null) {
			child.kill("SIGKILL");
			await child.exited;
		}
	}
	await writeFile(
		"evidence/process-lifecycle.json",
		JSON.stringify(processLogs, null, 2),
	);
	await pool.end();
	await invoke("cleanup.mjs").catch((e) => console.error(e.message));
	await report.finish();
}
