# Todo / Project external dogfood

This consumer installs `@lilka/vane` exclusively from `../../artifacts/vane.tgz`. It lives outside the framework checkout and has its own lockfile. Node 24 and PostgreSQL 16 are required.

```sh
export VANE_DOGFOOD_DATABASE_URL=postgresql://vane:vane-local-only@127.0.0.1:55432/vane_dogfood
npm ci
npm run typecheck
npm run build
npm run cleanup
npm run migrate
npm start
# In another terminal, same directory and database variable:
npm test
npm run cleanup
```

Tests manage ephemeral Node HTTP processes and use a unique `dogfood_todo_<pid>` namespace, then remove that namespace. They never mutate application data through SQL; database assertions are read-only. Schema reset is restricted to the Todo test namespace prefix. Start without `VANE_TODO_TEST_CONTROL=1` to omit all test control routes.

Project and Todo own their create/update/delete Events. Todo has an explicit Project reference and a Rule comparing completedUnits to totalUnits. Completing a Todo uses the framework's atomic numeric operation. TodoList filters by project/completed units and orders/paginates by title. Every Event is exposed through an explicit single-step Saga so admission is recoverable; HTTP 202 is only admission, and terminal SSE supplies the View/fail.

TD-05 first starts with workers paused, records durable admission, then sends SIGKILL. Its second crash uses the public structural `pool` binding to observe an INSERT into the materialized outbox and the successful COMMIT on that same reserved client. The wrapper withholds the resolved COMMIT response, so the Entity transaction has committed while the Saga checkpoint cannot advance. No core hooks, altered SQL or injected domain handlers are used. The test confirms persisted executing state, envelope identity, mailbox/outbox cardinality and unchanged owner revision after recovery and explicit exact-envelope replay.

Evidence is written by the external reporter to `../../evidence/todo.json` and `.md`; additional transcripts/snapshots are in this app's `evidence/`. Any required FAIL/GAP exits nonzero. The implementer consulted published docs and public example files first, then the framework service/runtime source to locate public return members and understand the transaction barrier. This implementation is not independent adopter evidence; that reproduction must be separate.

## Recorded adoption frictions

- DX: root README exposes no complete minimal Todo HTTP bootstrap. Compose semantic-compiler, PostgreSQL, Saga and ServiceConfiguration guides plus executable Sales/Billing configuration.
- Explicit single-step Sagas are chosen to declare the Todo/Project terminal Views. Candidate operations docs also describe automatically generated durable Entity Event plans; the older Saga guide needs reconciliation.
- DX: materialized public terminal route is `/tasks/sagas/:sagaId`; use the documented durable Saga example rather than assuming an `/events/.../stream` route.
- Source consultation: `src/service-runtime.ts` for `runtime.modules[0].store` and `runWorkers`; `src/postgresql/runtime.ts` for matching COMMIT to outbox INSERT. Neither file is imported or patched by the consumer.

- DX: initial migration requires `previous: null`; omitting the property throws a TypeError rather than a validated error. Public declaration supplies the mandatory shape. Diagnostics expose `message`, `correction`, `location`, while the semantic guide describes cause/correction/source generically.

## Acceptance boundary

`npm test` reports the scoped TD-06-package obligation. The root final gate owns combined TD-06 acceptance and requires the separate independent-adopter manifest before accepting the group. No implementation run counts as independent adoption. First-success timing in the suite measures harness startup through the first persisted Todo terminal, rather than an independent adopter's setup time.

The coordinator addressed the observed docs frictions in `docs/postgresql.md` (explicit `previous: null`), `docs/sagas.md` (configured automatic durable Events versus legacy direct routes), and `docs/service-configuration.md` (public module controls and exact stored-envelope replay). Reproduction uses those frozen, versioned public docs; the app imports only the package export root.
