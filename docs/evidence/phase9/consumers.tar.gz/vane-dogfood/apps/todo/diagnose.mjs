import { readFile } from "node:fs/promises";
import {
	compileProjectSources,
	compileServiceConfiguration,
} from "@lilka/vane";
import { configuration } from "./configuration.mjs";
let result;
if (
	process.argv[2] === "--missing-binding" ||
	process.argv[2] === "--correct-binding"
) {
	const c = structuredClone(configuration);
	if (process.argv[2] === "--missing-binding")
		delete c.profiles.test.topology.service.persistence.connection;
	result = compileServiceConfiguration(c, "test");
} else
	result = compileProjectSources([
		{
			fileName: process.argv[2],
			sourceText: await readFile(process.argv[2], "utf8"),
		},
	]);
console.log(JSON.stringify(result));
if (!result.success) process.exitCode = 1;
