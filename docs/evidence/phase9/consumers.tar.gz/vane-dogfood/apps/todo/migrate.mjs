import pg from "pg";
import {
	applyPostgreSqlMigrationPlan,
	createPostgreSqlMigrationPlan,
} from "@lilka/vane";
import { result } from "./configuration.mjs";
const pool = new pg.Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
});
try {
	await applyPostgreSqlMigrationPlan(
		pool,
		createPostgreSqlMigrationPlan({
			previous: null,
			next: result.plan.storage,
		}),
	);
	console.log("Todo migration applied");
} finally {
	await pool.end();
}
