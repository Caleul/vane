import assert from "node:assert/strict";
import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import { randomUUID } from "node:crypto";
import { readFile, writeFile, rm, mkdir } from "node:fs/promises";
import pg from "pg";
import {
	compileServiceConfiguration,
	PostgreSqlSagaStore,
	PostgreSqlOperations,
	PostgreSqlModuleRuntime,
	PostgreSqlOutboxDispatcher,
	createEventEnvelope,
	createServiceRuntime,
} from "@lilka/vane";
import configuration from "./configuration.mjs";
import { createReporter } from "../../harness/evidence.mjs";
const reporter = createReporter("reservation");
const children = [];
let app, gateway;
const env = {
	...process.env,
	RESERVATION_SCHEMA:
		process.env.RESERVATION_SCHEMA ?? "dogfood_reservation_test",
	CONFIRMATION_LEDGER: new URL(
		"../../evidence/reservation-ledger.json",
		import.meta.url,
	).pathname,
	CONFIRMATION_CONTROL: new URL(
		"../../evidence/reservation-control.json",
		import.meta.url,
	).pathname,
};
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
const now = () => Math.floor(Date.now() / 1000);
const pool = new pg.Pool({
	connectionString: env.VANE_DOGFOOD_DATABASE_URL,
	max: 20,
});
const config = structuredClone(configuration);
config.profiles.test.topology.service.persistence.namespace =
	env.RESERVATION_SCHEMA;
const compiled = compileServiceConfiguration(config, "test");
if (!compiled.success) throw Error(JSON.stringify(compiled.diagnostics));
const storage = compiled.plan.storage;
const store = new PostgreSqlSagaStore(pool, storage);
const ops = new PostgreSqlOperations(pool, storage);
const table = (name) =>
	`"${env.RESERVATION_SCHEMA}"."${storage.tables.find((t) => t.semanticId === name).name}"`;
const eeRequirements = {
	"RB-01": ["EE-EVT-006", "EE-HTTP-002", "EE-HTTP-003"],
	"RB-02": ["EE-RUL-003", "EE-PG-005", "EE-PIVOT-002"],
	"RB-03": ["EE-SAGA-004", "EE-PG-006"],
	"RB-04": ["EE-RUL-003", "EE-PG-005", "EE-PIVOT-002"],
	"RB-05": ["EE-ACL-003", "EE-SAGA-005", "EE-SAGA-007", "EE-NFR-008"],
	"RB-06": ["EE-SAGA-003", "EE-SAGA-004", "EE-PG-006", "EE-NFR-008"],
	"RB-07": ["EE-EVT-007", "EE-PG-005", "EE-PG-006", "EE-NFR-008"],
	"RB-08": ["EE-ACL-005", "EE-SVC-018", "EE-HTTP-006"],
};
const spec = (id, action, expected) => ({
	id,
	requirements: [
		"VR-DX-001",
		"VR-DX-005",
		"VR-DX-008",
		"VR-LOCAL-001",
		...(eeRequirements[id] ?? []),
	],
	precondition:
		"Installed identified tarball, isolated PostgreSQL16 schema, real child processes",
	action,
	expected,
});
async function waitFor(fn, timeout = 12000) {
	const end = Date.now() + timeout;
	while (Date.now() < end) {
		const v = await fn();
		if (v) return v;
		await delay(15);
	}
	throw Error("Bounded wait timed out");
}
async function start(file, extra = {}) {
	const child = spawn(process.execPath, [file], {
		cwd: new URL(".", import.meta.url).pathname,
		env: { ...env, ...extra },
		stdio: ["ignore", "pipe", "pipe", "ipc"],
	});
	children.push(child);
	child.err = "";
	child.stderr.on("data", (c) => (child.err += c));
	child.done = new Promise((r) =>
		child.once("exit", (code, signal) => r({ code, signal })),
	);
	return await new Promise((resolve, reject) => {
		let text = "";
		const timer = setTimeout(
			() => reject(Error(`start timed out ${file}: ${child.err}`)),
			10000,
		);
		child.once("exit", () => {
			clearTimeout(timer);
			reject(Error(`start failed ${file}: ${child.err}`));
		});
		child.stdout.on("data", (c) => {
			text += c;
			if (text.includes("\n")) {
				clearTimeout(timer);
				const ready = JSON.parse(text.split("\n")[0]);
				resolve({ child, url: `http://127.0.0.1:${ready.address.port}` });
			}
		});
	});
}
async function stop(service, signal = "SIGTERM") {
	if (!service) return;
	service.child.kill(signal);
	const timeout = setTimeout(() => service.child.kill("SIGKILL"), 5000);
	const result = await service.child.done;
	clearTimeout(timeout);
	return result;
}
async function restart(extra = {}, signal = "SIGTERM") {
	await stop(app, signal);
	app = await start("server.mjs", { CONFIRMATION_URL: gateway.url, ...extra });
	return app;
}
async function request(path, data = {}) {
	const r = await fetch(app.url + path, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify(data),
		signal: AbortSignal.timeout(12000),
	});
	return { status: r.status, body: await r.json() };
}
async function terminal(sagaId) {
	const r = await fetch(`${app.url}/booking/sagas/${sagaId}`, {
		signal: AbortSignal.timeout(15000),
	});
	assert.equal(r.status, 200);
	const text = await r.text();
	assert.equal((text.match(/event:/g) || []).length, 1);
	assert.ok(/^event: (view|fail)\n/.test(text));
	assert.ok(!text.includes("compensation") && !text.includes("attempts"));
	return { kind: text.startsWith("event: view") ? "view" : "fail", text };
}
async function admit(path, data) {
	const r = await request(path, data);
	assert.equal(r.status, 202, JSON.stringify(r));
	return r.body.sagaId;
}
async function resource(capacity = 1) {
	const resourceId = randomUUID();
	const sagaId = await admit("/booking/events/Resource.Create", {
		resourceId,
		capacity,
	});
	assert.equal((await terminal(sagaId)).kind, "view");
	return resourceId;
}
async function reserve(resourceId, seconds = 60) {
	const id = randomUUID(),
		expiresAt = now() + seconds;
	const sagaId = await admit("/booking/events/Booking.Place", {
		id,
		resourceId,
		expiresAt,
	});
	const result = await terminal(sagaId);
	return { id, resourceId, expiresAt, sagaId, result };
}
async function booking(id) {
	return (await request("/booking/views/BookingDetails", { id })).body[0];
}
async function units(resourceId) {
	return (await request("/booking/views/ResourceDetails", { resourceId }))
		.body[0].reservedUnits;
}
async function settings(value) {
	await writeFile(env.CONFIRMATION_CONTROL, JSON.stringify(value));
}
async function ledger() {
	return JSON.parse(
		await readFile(env.CONFIRMATION_LEDGER, "utf8").catch(() => "{}"),
	);
}
async function tick(command = "tick", envelope) {
	const id = randomUUID();
	return await new Promise((resolve, reject) => {
		const timer = setTimeout(() => reject(Error("IPC tick timed out")), 10000);
		const listener = (m) => {
			if (m.tick === id) {
				clearTimeout(timer);
				app.child.off("message", listener);
				if (m.error) reject(Error(m.error));
				else resolve(m.result);
			}
		};
		app.child.on("message", listener);
		app.child.send({ command, id, envelope });
	});
}
async function expiryAdmissions(id) {
	const result = await pool.query(
		`SELECT count(*)::integer AS count FROM ${table("vane.infrastructure.sagas")} WHERE state->'steps' @> $1::jsonb`,
		[
			JSON.stringify([
				{ envelope: { eventIdentity: "Booking.Expire", payload: { id } } },
			]),
		],
	);
	return result.rows[0].count;
}
async function assertInvariant(resourceId) {
	const rows = (
		await pool.query(
			`SELECT * FROM ${table("Reservations.Resource")} WHERE id=$1`,
			[resourceId],
		)
	).rows;
	assert.equal(rows.length, 1);
	assert.ok(
		Number(rows[0].reserved_units) >= 0 &&
			Number(rows[0].reserved_units) <= Number(rows[0].capacity),
	);
	return rows[0];
}
try {
	await mkdir(new URL("../../evidence/", import.meta.url), { recursive: true });
	await rm(env.CONFIRMATION_LEDGER, { force: true });
	await rm(env.CONFIRMATION_LEDGER + ".effects.ndjson", { force: true });
	await settings({});
	gateway = await start("gateway.mjs");
	env.CONFIRMATION_URL = gateway.url;
	await promisify(execFile)(process.execPath, ["migrate.mjs", "--cleanup"], {
		env,
	});
	await promisify(execFile)(process.execPath, ["migrate.mjs"], { env });
	app = await start("server.mjs");
	await reporter.na(
		{
			id: "RB-AWS",
			requirements: [
				"VR-LOCAL-002",
				"VR-LOCAL-003",
				"VR-LOCAL-004",
				"VR-LOCAL-005",
				"VR-LOCAL-006",
			],
			precondition:
				"Reservation integrates a concrete local HTTP confirmation provider only",
			action: "Declare integration applicability",
			expected:
				"AWS/Moto bootstrap, reset, fidelity and smoke requirements apply only when an AWS service is used",
		},
		"AWS/Moto N/A: no AWS integration or AWS SDK in this consumer; real PostgreSQL and HTTP provider exercised instead.",
	);
	await reporter.case(
		spec(
			"RB-01",
			"Reserve free capacity, confirm, inspect persisted View, cancel and release",
			"Confirmed before persisted deadline, then capacity zero",
		),
		async () => {
			const r = await reserve(await resource());
			assert.equal(r.result.kind, "view");
			const confirm = await admit(`/confirm/${r.id}`);
			assert.equal((await terminal(confirm)).kind, "view");
			const row = await booking(r.id);
			assert.equal(row.status, "confirmed");
			assert.ok(row.decidedAt < row.expiresAt);
			assert.equal(await units(r.resourceId), 1);
			assert.equal(
				(await terminal(await admit(`/cancel/${r.id}`))).kind,
				"view",
			);
			assert.equal(await units(r.resourceId), 0);
			return { booking: row, resource: await assertInvariant(r.resourceId) };
		},
	);
	await reporter.case(
		spec(
			"RB-02",
			"50 synchronized capacity-one reservation races, restart and read durable rows",
			"Exactly one View and one domain fail per round; resource counter one",
		),
		async () => {
			const allocatingResource = await resource();
			await restart({ WORKERS: "off", SCHEDULER: "off" });
			const allocatingId = randomUUID(),
				allocatingDeadline = now() - 1;
			const allocatingSaga = await admit("/booking/events/Booking.Place", {
				id: allocatingId,
				resourceId: allocatingResource,
				expiresAt: allocatingDeadline,
			});
			await waitFor(async () => {
				await tick();
				return (await booking(allocatingId))?.status === "allocating";
			});
			const allocatingBefore = {
				booking: await booking(allocatingId),
				resource: await assertInvariant(allocatingResource),
				ledger: await ledger(),
			};
			const allocatingRequests = await Promise.all([
				request(`/confirm/${allocatingId}`),
				request(`/expire/${allocatingId}`),
			]);
			for (const result of allocatingRequests) {
				assert.equal(result.status, 409);
				assert.equal(result.body.code, "INVALID_BOOKING_STATE");
				assert.equal(result.body.sagaId, undefined);
			}
			assert.deepEqual(
				{
					booking: await booking(allocatingId),
					resource: await assertInvariant(allocatingResource),
					ledger: await ledger(),
				},
				allocatingBefore,
			);
			assert.equal(await expiryAdmissions(allocatingId), 0);
			await restart({ SCHEDULER: "off" });
			assert.equal((await terminal(allocatingSaga)).kind, "view");
			assert.equal(
				(await terminal(await admit(`/expire/${allocatingId}`))).kind,
				"view",
			);
			assert.equal(await units(allocatingResource), 0);
			const loserResource = await resource(),
				winner = await reserve(loserResource, 30);
			const loserId = randomUUID(),
				loserDeadline = now() - 1;
			const loserSaga = await admit("/booking/events/Booking.Place", {
				id: loserId,
				resourceId: loserResource,
				expiresAt: loserDeadline,
			});
			assert.equal((await terminal(loserSaga)).kind, "fail");
			assert.equal((await booking(loserId)).status, "cancelled");
			const loserBefore = {
				booking: await booking(loserId),
				resource: await assertInvariant(loserResource),
				ledger: await ledger(),
			};
			const loserRequests = await Promise.all([
				request(`/confirm/${loserId}`),
				request(`/expire/${loserId}`),
			]);
			for (const result of loserRequests) {
				assert.equal(result.status, 409);
				assert.equal(result.body.code, "INVALID_BOOKING_STATE");
				assert.equal(result.body.sagaId, undefined);
			}
			assert.deepEqual(
				{
					booking: await booking(loserId),
					resource: await assertInvariant(loserResource),
					ledger: await ledger(),
				},
				loserBefore,
			);
			assert.equal(await units(loserResource), 1);
			assert.equal(await expiryAdmissions(loserId), 0);
			assert.equal(
				(await terminal(await admit(`/confirm/${winner.id}`))).kind,
				"view",
			);
			const confirmedBefore = {
				booking: await booking(winner.id),
				resource: await assertInvariant(loserResource),
				ledger: await ledger(),
			};
			for (const path of [
				`/confirm/${loserId}`,
				`/expire/${loserId}`,
				`/confirm/${winner.id}`,
				`/expire/${winner.id}`,
			]) {
				assert.equal((await request(path)).status, 409);
			}
			assert.deepEqual(
				{
					booking: await booking(winner.id),
					resource: await assertInvariant(loserResource),
					ledger: await ledger(),
				},
				confirmedBefore,
			);
			assert.equal(
				(await terminal(await admit(`/cancel/${winner.id}`))).kind,
				"view",
			);
			const rounds = [];
			for (let round = 0; round < 50; round++) {
				const resourceId = await resource();
				const payloads = [0, 1].map(() => ({
					id: randomUUID(),
					resourceId,
					expiresAt: now() + 300,
				}));
				const ids = await Promise.all(
					payloads.map((p) => admit("/booking/events/Booking.Place", p)),
				);
				const outcomes = await Promise.all(ids.map(terminal));
				assert.deepEqual(outcomes.map((o) => o.kind).sort(), ["fail", "view"]);
				const rows = await Promise.all(payloads.map((p) => booking(p.id)));
				assert.deepEqual(rows.map((r) => r.status).sort(), [
					"cancelled",
					"pending",
				]);
				assert.equal(await units(resourceId), 1);
				const loser = rows.find((row) => row.status === "cancelled");
				const loserConfirmation = await request(`/confirm/${loser.id}`);
				assert.equal(loserConfirmation.status, 409);
				assert.equal(loserConfirmation.body.code, "INVALID_BOOKING_STATE");
				assert.equal(await units(resourceId), 1);
				rounds.push({ round, resourceId, ids, rows, loserConfirmation });
			}
			await restart({ SCHEDULER: "off" });
			for (const r of rounds) {
				assert.equal(await units(r.resourceId), 1);
				await assertInvariant(r.resourceId);
			}
			return {
				rounds,
				allocating: { before: allocatingBefore, requests: allocatingRequests },
				cancelledLoser: { before: loserBefore, requests: loserRequests },
				confirmedWinner: confirmedBefore,
			};
		},
	);
	await reporter.case(
		spec(
			"RB-03",
			"Reject forged early expiry without admission; restart scheduler before/after deadline; reject late confirmation; rerun expiry",
			"Persisted pending reservation expires, capacity released once",
		),
		async () => {
			const early = await reserve(await resource(), 30);
			const earlyBefore = {
				booking: await booking(early.id),
				resource: await assertInvariant(early.resourceId),
				admissions: await expiryAdmissions(early.id),
			};
			assert.ok(now() < early.expiresAt);
			const earlyResponse = await request(`/expire/${early.id}`, {
				decidedAt: early.expiresAt + 3600,
				expiresAt: 0,
			});
			assert.equal(earlyResponse.status, 409);
			assert.equal(earlyResponse.body.code, "DEADLINE_NOT_REACHED");
			assert.equal(earlyResponse.body.sagaId, undefined);
			const earlyAfter = {
				booking: await booking(early.id),
				resource: await assertInvariant(early.resourceId),
				admissions: await expiryAdmissions(early.id),
			};
			assert.deepEqual(earlyAfter, earlyBefore);
			assert.equal(earlyAfter.admissions, 0);
			assert.equal(
				(await terminal(await admit(`/confirm/${early.id}`))).kind,
				"view",
			);
			assert.equal(
				(await terminal(await admit(`/cancel/${early.id}`))).kind,
				"view",
			);
			const rounds = [];
			for (const after of [false, true]) {
				const r = await reserve(await resource(), 2);
				await restart({ SCHEDULER: "off" });
				if (after) await waitFor(() => now() >= r.expiresAt);
				await restart();
				await waitFor(async () => (await booking(r.id)).status === "expired");
				await waitFor(async () => (await units(r.resourceId)) === 0);
				const late = await request(`/confirm/${r.id}`);
				assert.equal(late.status, 409);
				assert.equal(late.body.code, "INVALID_BOOKING_STATE");
				assert.equal(
					(await terminal(await admit(`/expire/${r.id}`))).kind,
					"view",
				);
				assert.equal(await units(r.resourceId), 0);
				rounds.push({
					after,
					booking: await booking(r.id),
					resource: await assertInvariant(r.resourceId),
				});
			}
			return {
				rounds,
				early: {
					before: earlyBefore,
					response: earlyResponse,
					after: earlyAfter,
				},
			};
		},
	);
	await reporter.case(
		spec(
			"RB-04",
			"10 predeadline confirmation/forged-expiry races and 50 synchronized confirm/expire operations on/after persisted deadline",
			"Atomic single decision; strict confirm-before-deadline, expiry on/after deadline, never confirmed with released capacity",
		),
		async () => {
			await restart({ SCHEDULER: "off" });
			const predeadlineResources = await Promise.all(
				Array.from({ length: 10 }, () => resource()),
			);
			const predeadlineBookings = await Promise.all(
				predeadlineResources.map((resourceId) => reserve(resourceId, 40)),
			);
			const predeadlineRounds = await Promise.all(
				predeadlineBookings.map(async (r, round) => {
					assert.ok(now() < r.expiresAt);
					const [confirmation, expiry] = await Promise.all([
						request(`/confirm/${r.id}`, { decidedAt: 0, expiresAt: 0 }),
						request(`/expire/${r.id}`, {
							decidedAt: r.expiresAt + 3600,
							expiresAt: 0,
						}),
					]);
					assert.equal(confirmation.status, 202);
					assert.equal(expiry.status, 409);
					assert.equal(expiry.body.code, "DEADLINE_NOT_REACHED");
					assert.equal(expiry.body.sagaId, undefined);
					assert.equal((await terminal(confirmation.body.sagaId)).kind, "view");
					const row = await booking(r.id);
					assert.equal(row.status, "confirmed");
					assert.equal(row.decisionUnits, 1);
					assert.ok(row.decidedAt < row.expiresAt);
					assert.equal(await units(r.resourceId), 1);
					assert.equal(await expiryAdmissions(r.id), 0);
					const effect = Object.values(await ledger()).find(
						(item) => JSON.parse(item.payload).id === r.id,
					);
					assert.ok(effect);
					assert.ok(Date.parse(effect.at) < row.expiresAt * 1000);
					assert.equal(effect.effects, 1);
					const persistedResource = await assertInvariant(r.resourceId);
					assert.equal(
						(await terminal(await admit(`/cancel/${r.id}`))).kind,
						"view",
					);
					return {
						round,
						row,
						confirmation,
						expiry,
						effect,
						resourceBeforeCancellation: persistedResource,
					};
				}),
			);
			const resourceIds = await Promise.all(
				Array.from({ length: 50 }, () => resource()),
			);
			const bookings = await Promise.all(
				resourceIds.map((id) => reserve(id, 3)),
			);
			await waitFor(
				() => now() >= Math.max(...bookings.map((r) => r.expiresAt)),
			);
			const rounds = await Promise.all(
				bookings.map(async (r, round) => {
					const [confirmation, expiration] = await Promise.all([
						request(`/confirm/${r.id}`),
						request(`/expire/${r.id}`),
					]);
					assert.equal(expiration.status, 202);
					assert.equal((await terminal(expiration.body.sagaId)).kind, "view");
					if (confirmation.status === 202) {
						assert.equal(
							(await terminal(confirmation.body.sagaId)).kind,
							"fail",
						);
					} else {
						assert.equal(confirmation.status, 409);
						assert.equal(confirmation.body.code, "INVALID_BOOKING_STATE");
					}
					const ids = [
						confirmation.body.sagaId ?? null,
						expiration.body.sagaId,
					];
					const row = await booking(r.id);
					assert.equal(row.status, "expired");
					assert.equal(row.decisionUnits, 1);
					assert.ok(row.decidedAt >= row.expiresAt);
					assert.equal(await units(r.resourceId), 0);
					await assertInvariant(r.resourceId);
					return { round, ids, row, units: 0 };
				}),
			);
			return {
				rounds,
				predeadlineRounds,
				oracle:
					"decisionUnits atomic increment constrained maximum 1; confirm decidedAt < expiresAt, expire >= expiresAt; clock supplied only by application",
			};
		},
	);
	await reporter.case(
		spec(
			"RB-05",
			"External transient outage recovers; retry exhaustion and overdue response compensate",
			"Confirmed within deadline or safe fail with capacity released; compensation failure inspectable",
		),
		async () => {
			await settings({ unavailable: true });
			const r = await reserve(await resource());
			const sagaId = await admit(`/confirm/${r.id}`);
			await waitFor(async () => {
				const s = await store.read(sagaId);
				return !!s?.steps.find((x) => x.name === "external")?.retryAt;
			});
			await settings({});
			assert.equal((await terminal(sagaId)).kind, "view");
			const recovered = await ops.inspectSaga(sagaId);
			assert.ok(
				recovered.steps.find((s) => s.name === "external").attempts >= 2,
			);
			await settings({ delayMs: 1200 });
			const overlap = await reserve(await resource(), 30);
			const overlapSaga = await admit(`/confirm/${overlap.id}`);
			assert.equal((await terminal(overlapSaga)).kind, "view");
			await delay(1500);
			const overlapEffects = (
				await readFile(env.CONFIRMATION_LEDGER + ".effects.ndjson", "utf8")
			)
				.trim()
				.split("\n")
				.map(JSON.parse)
				.filter((e) => e.bookingId === overlap.id);
			assert.equal(overlapEffects.length, 1);
			const overlapLedger = Object.values(await ledger()).find(
				(v) => JSON.parse(v.payload).id === overlap.id,
			);
			assert.ok(overlapLedger.deliveries >= 2);
			await settings({ unavailable: true });
			const exhausted = await reserve(await resource());
			const exhaustedSaga = await admit(`/confirm/${exhausted.id}`);
			assert.equal((await terminal(exhaustedSaga)).kind, "fail");
			assert.equal(
				await units(exhausted.resourceId),
				0,
				"exhaustion compensation incomplete",
			);
			const exhaustedState = await ops.inspectSaga(exhaustedSaga);
			assert.equal(
				exhaustedState.steps.find((s) => s.name === "external").attempts,
				3,
			);
			// Prove successful Claim/Hold before testing an overdue external response.
			// Automatic expiry is a separate Saga and cannot justify this terminal.
			const overdueResource = await resource();
			await restart({ WORKERS: "off", SCHEDULER: "off" });
			await settings({ delayMs: 1200 });
			const overdue = {
				id: randomUUID(),
				resourceId: overdueResource,
				expiresAt: now() + 10,
			};
			const overdueReserve = await admit(
				"/booking/events/Booking.Place",
				overdue,
			);
			await waitFor(async () => {
				await tick();
				return (await store.read(overdueReserve))?.terminal;
			});
			const overdueSaga = await admit(`/confirm/${overdue.id}`);
			await waitFor(async () => {
				await tick();
				return (
					(await store.read(overdueSaga))?.steps.find((s) => s.name === "hold")
						?.status === "success"
				);
			});
			const held = await booking(overdue.id);
			assert.equal(held.status, "confirming");
			assert.ok(
				held.decidedAt < held.expiresAt,
				"Claim must commit before deadline",
			);
			assert.ok(
				now() < held.expiresAt,
				"External attempt must remain eligible",
			);
			await waitFor(() => now() >= held.expiresAt - 1);
			assert.ok(
				now() < held.expiresAt,
				"First external attempt must start before deadline",
			);
			await waitFor(async () => {
				await tick();
				return (await store.read(overdueSaga))?.terminal;
			});
			assert.equal((await terminal(overdueSaga)).kind, "fail");
			const overdueState = await ops.inspectSaga(overdueSaga);
			const overdueExternal = overdueState.steps.find(
				(s) => s.name === "external",
			);
			assert.equal(overdueExternal.status, "fail");
			assert.ok(
				overdueExternal.attempts >= 2,
				"Overdue external case must exercise timeout and retry",
			);
			assert.equal(
				await units(overdue.resourceId),
				0,
				`overdue compensation incomplete: ${JSON.stringify(overdueState)}`,
			);
			assert.equal(
				overdueState.steps.find((s) => s.name === "hold").compensationStatus,
				"success",
			);
			assert.equal((await booking(overdue.id)).status, "cancelled");
			assert.equal(
				Object.values(await ledger()).filter(
					(entry) => JSON.parse(entry.payload).id === overdue.id,
				).length,
				0,
			);
			await restart();
			await settings({ unavailable: true, delayMs: 150 });
			const broken = await reserve(await resource());
			const brokenSaga = await admit(`/confirm/${broken.id}`);
			await waitFor(async () => {
				const s = await store.read(brokenSaga);
				return s?.steps.find((x) => x.name === "hold")?.status === "success";
			});
			const release = createEventEnvelope({
				eventId: randomUUID(),
				eventIdentity: "Resource.Release",
				occurredAt: new Date().toISOString(),
				payload: { resourceId: broken.resourceId },
			});
			await tick("dispatch", release);
			assert.equal((await terminal(brokenSaga)).kind, "fail");
			const brokenState = await ops.inspectSaga(brokenSaga);
			assert.ok(brokenState.steps.some((s) => s.compensationStatus === "fail"));
			await settings({});
			return {
				recovered,
				overlapEffects,
				overlapLedger,
				exhaustedState,
				overdue: await booking(overdue.id),
				overdueState,
				brokenState,
			};
		},
	);
	await reporter.case(
		spec(
			"RB-06",
			"SIGKILL after reserve commit, external ledger effect, and expiry decision before release; restart unchanged package",
			"Stable Event identities, no orphan or duplicated effects/releases",
		),
		async () => {
			await restart({ WORKERS: "off", SCHEDULER: "off" });
			const resourceId = randomUUID();
			let s = await admit("/booking/events/Resource.Create", {
				resourceId,
				capacity: 1,
			});
			while (!(await store.read(s))?.terminal) await tick();
			const id = randomUUID(),
				expiresAt = now() + 2;
			s = await admit("/booking/events/Booking.Place", {
				id,
				resourceId,
				expiresAt,
			});
			await waitFor(async () => {
				await tick();
				return (await units(resourceId)) === 1;
			});
			const before = await store.read(s);
			const crash1 = await restart({}, "SIGKILL");
			assert.equal((await terminal(s)).kind, "view");
			await waitFor(async () => (await units(resourceId)) === 0);
			const after = await store.read(s);
			assert.deepEqual(
				before.steps.map((x) => x.envelope.eventId),
				after.steps.map((x) => x.envelope.eventId),
			);
			await settings({ holdAfterEffect: true });
			const external = await reserve(await resource(), 30);
			const confirm = await admit(`/confirm/${external.id}`);
			const effect = await waitFor(async () =>
				Object.entries(await ledger()).find(
					([, v]) => JSON.parse(v.payload).id === external.id,
				),
			);
			const pre = await store.read(confirm);
			await stop(app, "SIGKILL");
			await stop(gateway, "SIGKILL");
			await settings({});
			gateway = await start("gateway.mjs");
			env.CONFIRMATION_URL = gateway.url;
			app = await start("server.mjs");
			assert.equal((await terminal(confirm)).kind, "view");
			const post = await store.read(confirm);
			assert.deepEqual(
				pre.steps.map((x) => x.envelope.eventId),
				post.steps.map((x) => x.envelope.eventId),
			);
			const item = (await ledger())[effect[0]];
			assert.equal(item.effects, 1);
			assert.ok(item.deliveries >= 2);
			assert.ok(Date.parse(item.at) < external.expiresAt * 1000);
			const releaseBooking = await reserve(await resource(), 1);
			await restart({ CRASH_BARRIER: "release", SCHEDULER: "off" });
			await waitFor(() => now() >= releaseBooking.expiresAt);
			const barrier = new Promise((resolve, reject) => {
				const timeout = setTimeout(
					() => reject(Error("Release commit barrier timed out")),
					10000,
				);
				app.child.on("message", (m) => {
					if (m.barrier === "release-committed") {
						clearTimeout(timeout);
						resolve(m);
					}
				});
			});
			const expiry = await admit(`/expire/${releaseBooking.id}`);
			const committed = await barrier;
			const releaseBefore = await store.read(expiry);
			assert.equal(
				releaseBefore.steps.find((s) => s.name === "release").status,
				"executing",
			);
			assert.equal(await units(releaseBooking.resourceId), 0);
			const releaseRevision = (await assertInvariant(releaseBooking.resourceId))
				.__vane_revision;
			await restart({}, "SIGKILL");
			assert.equal((await terminal(expiry)).kind, "view");
			assert.equal(await units(releaseBooking.resourceId), 0);
			assert.equal(
				(await assertInvariant(releaseBooking.resourceId)).__vane_revision,
				releaseRevision,
			);
			assert.deepEqual(
				releaseBefore.steps.map((s) => s.envelope.eventId),
				(await store.read(expiry)).steps.map((s) => s.envelope.eventId),
			);
			return {
				signals: ["SIGKILL", "SIGKILL", "SIGKILL"],
				reserve: { before, after },
				external: { item, pre, post },
				release: { releaseBefore, after: await store.read(expiry) },
			};
		},
	);
	await reporter.case(
		spec(
			"RB-07",
			"Replay stored envelope, reclaim expired lease, exhaust publication and retry original ID, resolve and prune failures",
			"Exactly one mutation; stale lease rejected; stable Event ID; terminal invariant",
		),
		async () => {
			const r = await reserve(await resource());
			const state = await store.read(r.sagaId);
			const envelope = state.steps.find((s) => s.name === "take").envelope;
			const events = new PostgreSqlModuleRuntime({
				module: config.project.modules[0],
				pool,
				storage,
			});
			await events.start();
			const before = await assertInvariant(r.resourceId);
			const receipt = await events.dispatch(envelope);
			const repeated = await events.dispatch(envelope);
			assert.deepEqual(receipt, repeated);
			assert.deepEqual(await assertInvariant(r.resourceId), before);
			const dispatcher = new PostgreSqlOutboxDispatcher(pool, storage);
			const drain = {
				workerId: "drain",
				limit: 1000,
				leaseMilliseconds: 5000,
				publisher: { publish: async () => {} },
				retryAt: () => new Date().toISOString(),
			};
			while ((await dispatcher.dispatch(drain)).claimed) {}
			const fresh = createEventEnvelope({
				eventId: randomUUID(),
				eventIdentity: "Resource.Hold",
				occurredAt: new Date().toISOString(),
				payload: { resourceId: r.resourceId },
			});
			await events.dispatch(fresh);
			const first = (
				await dispatcher.claim({
					workerId: "lease-a",
					limit: 1,
					leaseMilliseconds: 30,
				})
			)[0];
			assert.equal(first.eventId, fresh.eventId);
			await delay(60);
			const second = (
				await dispatcher.claim({
					workerId: "lease-b",
					limit: 1,
					leaseMilliseconds: 5000,
				})
			)[0];
			assert.equal(second.eventId, fresh.eventId);
			assert.notEqual(first.leaseToken, second.leaseToken);
			await assert.rejects(
				() =>
					dispatcher.acknowledge({
						messageId: first.messageId,
						workerId: "lease-a",
						leaseToken: first.leaseToken,
						publishedAt: new Date().toISOString(),
					}),
				{ code: "VANE_OUTBOX_LEASE_LOST" },
			);
			await dispatcher.reschedule({
				messageId: second.messageId,
				workerId: "lease-b",
				leaseToken: second.leaseToken,
				availableAt: new Date().toISOString(),
				error: "deterministic publisher offline",
			});
			const exhausted = await dispatcher.dispatch({
				...drain,
				workerId: "failure",
				limit: 1,
				policy: {
					timeoutMs: 1000,
					retry: { attempts: 1, backoff: "fixed", delayMs: 0, maxDelayMs: 0 },
					idempotency: "required",
					deduplication: "durable",
				},
				publisher: {
					publish: async () => {
						throw Error("publisher offline");
					},
				},
			});
			assert.equal(exhausted.exhausted, 1);
			const failure = (await ops.failures(1000)).find(
				(f) =>
					f.event_id === fresh.eventId && f.code === "VANE_OUTBOX_EXHAUSTED",
			);
			assert.ok(failure);
			const terminalBefore = await store.read(r.sagaId);
			assert.equal(await ops.retryOutboxFailure(failure.failure_id), true);
			const published = [];
			const retried = await dispatcher.dispatch({
				...drain,
				publisher: { publish: async (e) => published.push(e.eventId) },
			});
			assert.equal(retried.published, 1);
			assert.deepEqual(published, [fresh.eventId]);
			assert.equal(await ops.resolveFailure(failure.failure_id), false);
			const domainFailure = (await ops.failures(1000)).find(
				(f) => f.status !== "resolved",
			);
			assert.ok(domainFailure);
			assert.equal(await ops.resolveFailure(domainFailure.failure_id), true);
			await delay(10);
			await ops.pruneResolvedFailures(new Date().toISOString(), 1000);
			assert.deepEqual(
				(await store.read(r.sagaId)).terminal,
				terminalBefore.terminal,
			);
			assert.deepEqual(await events.dispatch(envelope), receipt);
			const finalResource = await assertInvariant(r.resourceId);
			assert.equal(finalResource.reserved_units, before.reserved_units);
			assert.equal(
				Number(finalResource.__vane_revision),
				Number(before.__vane_revision) + 1,
			);
			await events.stop();
			return {
				envelope,
				receipt,
				first,
				second,
				exhausted,
				failure,
				published,
				terminalBefore: terminalBefore.terminal,
			};
		},
	);
	await reporter.case(
		spec(
			"RB-08",
			"Reject invalid capacity/bindings/adapter/policy; SSE reconnect and no public inspection",
			"Failures are safe; stale technical configurations do not reinterpret pending work",
		),
		async () => {
			const resourceId = randomUUID();
			const bad = await admit("/booking/events/Resource.Create", {
				resourceId,
				capacity: 0,
			});
			assert.equal((await terminal(bad)).kind, "fail");
			const policies = structuredClone(config);
			policies.profiles.test.policies.defaults.retry.attempts = 0;
			assert.equal(
				compileServiceConfiguration(policies, "test").success,
				false,
			);
			const bindings = structuredClone(config);
			bindings.profiles.test.contracts.Reservations.events[1].terminal.input =
				{};
			assert.equal(
				compileServiceConfiguration(bindings, "test").success,
				false,
			);
			const adapter = structuredClone(config);
			adapter.profiles.test.acls[
				"Reservations.Confirmation.Confirm"
			].responses[0].fields = { reference: "missing" };
			const adapterResult = compileServiceConfiguration(adapter, "test");
			if (adapterResult.success) {
				adapter.profiles.test.acls[
					"Reservations.Confirmation.Confirm"
				].provider = { kind: "acl", id: "absent" };
				assert.equal(
					compileServiceConfiguration(adapter, "test").success,
					false,
				);
			}
			const r = await reserve(await resource());
			assert.equal(
				(await terminal(r.sagaId)).text,
				(await terminal(r.sagaId)).text,
			);
			await restart({ WORKERS: "off", SCHEDULER: "off" });
			const pending = await admit(`/confirm/${r.id}`);
			const pendingBefore = await store.read(pending);
			const incompatible = structuredClone(config);
			incompatible.profiles.test.acls[
				"Reservations.Confirmation.Confirm"
			].version = "2";
			const changed = await createServiceRuntime(incompatible, "test", {
				pool,
				resolveSecret: (ref) => env[ref.name],
			});
			await changed.start();
			assert.equal(await changed.modules[0].sagas.runOnce(), false);
			assert.deepEqual(await store.read(pending), pendingBefore);
			await changed.stop();
			await restart({ SCHEDULER: "off" });
			assert.equal((await terminal(pending)).kind, "view");
			for (const path of [
				"/booking/inspect",
				"/booking/failures",
				"/inspect",
				"/failures",
			]) {
				assert.equal((await fetch(app.url + path)).status, 404);
			}
			return {
				invalidCapacity: bad,
				policyDiagnostics: compileServiceConfiguration(policies, "test")
					.diagnostics,
				bindingDiagnostics: compileServiceConfiguration(bindings, "test")
					.diagnostics,
				reconnectedSaga: r.sagaId,
			};
		},
	);
} catch (error) {
	await reporter.case(
		spec("RB-SETUP", "Set up process runtime", "Successful setup"),
		async () => {
			throw error;
		},
	);
} finally {
	for (const child of children)
		if (child.exitCode === null && child.signalCode === null)
			await stop({ child });
	await pool.end();
	await reporter.finish();
}
