import {
	ACL,
	ACLEvent,
	Column,
	Entity,
	Event,
	Module,
	Rule,
	Saga,
	View,
	add,
	column,
	create,
	eq,
	event,
	eventRef,
	fail,
	field,
	gte,
	input,
	literal,
	lt,
	lte,
	or,
	subtract,
	success,
	update,
} from "@lilka/vane";
@Entity()
export class Resource {
	id = Column({ type: "uuid", identity: true });
	capacity = Column({ type: "integer", minimum: 1 });
	reservedUnits = Column({ type: "integer", minimum: 0 });
	@Rule({ expression: lte(column("reservedUnits"), column("capacity")) })
	WithinCapacity() {}
	Create = Event({
		input: { resourceId: "uuid", capacity: "integer" },
		operation: create({
			id: input("resourceId"),
			capacity: input("capacity"),
			reservedUnits: literal(0),
		}),
	});
	Take = Event({
		input: { resourceId: "uuid" },
		operation: update(input("resourceId"), {
			reservedUnits: add(column("reservedUnits"), literal(1)),
		}),
	});
	Hold = Event({
		input: { resourceId: "uuid" },
		operation: update(input("resourceId"), {
			reservedUnits: column("reservedUnits"),
		}),
	});
	Release = Event({
		input: { resourceId: "uuid" },
		operation: update(input("resourceId"), {
			reservedUnits: subtract(column("reservedUnits"), literal(1)),
		}),
	});
}
@Entity()
export class Booking {
	id = Column({ type: "uuid", identity: true });
	resourceId = Column({ type: "uuid", references: field(Resource, "id") });
	expiresAt = Column({ type: "integer" });
	decidedAt = Column({ type: "integer" });
	decisionUnits = Column({ type: "integer", minimum: 0, maximum: 1 });
	status = Column({ type: "string" });
	@Rule({
		expression: or(
			eq(column("status"), literal("allocating")),
			or(
				eq(column("status"), literal("pending")),
				or(
					eq(column("status"), literal("cancelled")),
					or(
						eq(column("status"), literal("expired")),
						lt(column("decidedAt"), column("expiresAt")),
					),
				),
			),
		),
	})
	ConfirmBeforeDeadline() {}
	@Rule({
		expression: or(
			eq(column("status"), literal("allocating")),
			or(
				eq(column("status"), literal("pending")),
				or(
					eq(column("status"), literal("cancelled")),
					or(
						eq(column("status"), literal("confirming")),
						or(
							eq(column("status"), literal("confirmed")),
							gte(column("decidedAt"), column("expiresAt")),
						),
					),
				),
			),
		),
	})
	ExpireAfterDeadline() {}
	Place = Event({
		input: { id: "uuid", resourceId: "uuid", expiresAt: "integer" },
		operation: create({
			id: input("id"),
			resourceId: input("resourceId"),
			expiresAt: input("expiresAt"),
			decidedAt: literal(0),
			decisionUnits: literal(0),
			status: literal("allocating"),
		}),
	});
	Ready = Event({
		input: { id: "uuid" },
		operation: update(input("id"), { status: literal("pending") }),
	});
	Cancel = Event({
		input: { id: "uuid" },
		operation: update(input("id"), { status: literal("cancelled") }),
	});
	Claim = Event({
		input: { id: "uuid", decidedAt: "integer" },
		operation: update(input("id"), {
			decidedAt: input("decidedAt"),
			decisionUnits: add(column("decisionUnits"), literal(1)),
			status: literal("confirming"),
		}),
	});
	Confirm = Event({
		input: { id: "uuid" },
		operation: update(input("id"), { status: literal("confirmed") }),
	});
	Expire = Event({
		input: { id: "uuid", decidedAt: "integer" },
		operation: update(input("id"), {
			decidedAt: input("decidedAt"),
			decisionUnits: add(column("decisionUnits"), literal(1)),
			status: literal("expired"),
		}),
	});
}
@ACL()
export class Confirmation {
	Confirm = ACLEvent({
		input: { id: "uuid", expiresAt: "integer" },
		results: { approved: success({ reference: "string" }), declined: fail({}) },
	});
}
@View({
	input: { id: "uuid" },
	output: {
		id: field(Booking, "id"),
		resourceId: field(Booking, "resourceId"),
		status: field(Booking, "status"),
		expiresAt: field(Booking, "expiresAt"),
		decidedAt: field(Booking, "decidedAt"),
		decisionUnits: field(Booking, "decisionUnits"),
	},
	query: { root: Booking, where: eq(field(Booking, "id"), input("id")) },
})
export class BookingDetails {}
@View({
	input: {},
	output: {
		id: field(Booking, "id"),
		resourceId: field(Booking, "resourceId"),
		expiresAt: field(Booking, "expiresAt"),
	},
	query: {
		root: Booking,
		where: eq(field(Booking, "status"), literal("pending")),
	},
})
export class PendingBookings {}
@View({
	input: { resourceId: "uuid" },
	output: {
		id: field(Resource, "id"),
		capacity: field(Resource, "capacity"),
		reservedUnits: field(Resource, "reservedUnits"),
	},
	query: {
		root: Resource,
		where: eq(field(Resource, "id"), input("resourceId")),
	},
})
export class ResourceDetails {}
@Saga({
	input: { id: "uuid", resourceId: "uuid", expiresAt: "integer" },
	steps: {
		place: event(Booking, "Place", {
			compensateWith: eventRef(Booking, "Cancel"),
		}),
		take: event(Resource, "Take", {
			causedBy: ["place"],
			compensateWith: eventRef(Resource, "Release"),
		}),
		ready: event(Booking, "Ready", { causedBy: ["take"] }),
	},
	terminal: { step: "ready", view: BookingDetails },
})
export class Reserve {}
@Saga({
	input: {
		id: "uuid",
		resourceId: "uuid",
		decidedAt: "integer",
		expiresAt: "integer",
	},
	steps: {
		claim: event(Booking, "Claim", {
			compensateWith: eventRef(Booking, "Cancel"),
		}),
		hold: event(Resource, "Hold", {
			causedBy: ["claim"],
			compensateWith: eventRef(Resource, "Release"),
		}),
		external: event(Confirmation, "Confirm", { causedBy: ["hold"] }),
		finish: event(Booking, "Confirm", { causedBy: ["external"] }),
	},
	terminal: { step: "finish", view: BookingDetails },
})
export class ConfirmBooking {}
@Saga({
	input: { id: "uuid", resourceId: "uuid", decidedAt: "integer" },
	steps: {
		expire: event(Booking, "Expire"),
		release: event(Resource, "Release", { causedBy: ["expire"] }),
	},
	terminal: { step: "release", view: BookingDetails },
})
export class ExpireBooking {}
@Saga({
	input: { resourceId: "uuid", capacity: "integer" },
	steps: { create: event(Resource, "Create") },
	terminal: { step: "create", view: ResourceDetails },
})
export class CreateResource {}
@Saga({
	input: { id: "uuid", resourceId: "uuid" },
	steps: {
		cancel: event(Booking, "Cancel"),
		release: event(Resource, "Release", { causedBy: ["cancel"] }),
	},
	terminal: { step: "release", view: BookingDetails },
})
export class CancelBooking {}
@Module({
	entities: [Resource, Booking],
	views: [BookingDetails, PendingBookings, ResourceDetails],
	antiCorruptionLayers: [Confirmation],
	sagas: [
		Reserve,
		ConfirmBooking,
		ExpireBooking,
		CreateResource,
		CancelBooking,
	],
})
export class Reservations {}
