import { createServer } from "node:http";
import { randomUUID, createHash } from "node:crypto";
import pg from "pg";
import { createServiceRuntime, createEventEnvelope } from "@lilka/vane";
import configuration from "./configuration.mjs";
const pool = new pg.Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
	max: 20,
});
const runtime = await createServiceRuntime(configuration, "test", { pool });
await runtime.start();
const module = runtime.modules[0];
if (process.env.CRASH_BARRIER === "release") {
	const dispatch = module.events.dispatch.bind(module.events);
	module.events.dispatch = async (envelope, ...rest) => {
		const receipt = await dispatch(envelope, ...rest);
		if (envelope.eventIdentity === "Resource.Release") {
			process.send?.({ barrier: "release-committed", envelope, receipt });
			await new Promise(() => {});
		}
		return receipt;
	};
}
const plan = (name) => runtime.plan.runtime.sagas.find((p) => p.saga === name);
const uuid = (key) => {
	const h = createHash("sha256").update(key).digest("hex");
	return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
};
let scheduling = false;
async function expire(row) {
	const decidedAt = Math.floor(Date.now() / 1000);
	if (decidedAt < row.expiresAt) throw Error("DEADLINE_NOT_REACHED");
	const existing = uuid(`expire:${row.id}`);
	if (await module.store.read(existing)) return existing;
	return module.sagas.admit(
		plan("ExpireBooking"),
		{ id: row.id, resourceId: row.resourceId, decidedAt },
		{
			sagaId: uuid(`expire:${row.id}`),
			occurredAt: new Date(decidedAt * 1000).toISOString(),
		},
	);
}
async function scheduler() {
	if (scheduling) return;
	scheduling = true;
	try {
		const { rows } = await module.views.execute({
			view: "PendingBookings",
			input: {},
		});
		for (const row of rows)
			if (row.expiresAt <= Math.floor(Date.now() / 1000)) await expire(row);
	} catch (e) {
		console.error("scheduler", e.message);
	} finally {
		scheduling = false;
	}
}
const timer =
	process.env.SCHEDULER === "off" ? null : setInterval(scheduler, 30);
const workers =
	process.env.WORKERS === "off" ? Promise.resolve() : runtime.runWorkers();
workers.catch((e) => {
	console.error(e);
	process.exitCode = 1;
	server.close();
});
async function body(req) {
	let s = "";
	for await (const c of req) s += c;
	if (s.length > 8192) throw Error("too large");
	return JSON.parse(s || "{}");
}
function json(res, status, value) {
	res.writeHead(status, { "content-type": "application/json" });
	res.end(JSON.stringify(value));
}
const server = createServer(async (req, res) => {
	try {
		if (req.url === "/health") {
			json(res, 200, { ready: true });
			return;
		}
		if (req.method === "POST" && /^\/(confirm|expire|cancel)\//.test(req.url)) {
			const id = req.url.split("/")[2];
			const { rows } = await module.views.execute({
				view: "BookingDetails",
				input: { id },
			});
			const row = rows[0];
			if (!row) {
				json(res, 404, { error: "not found" });
				return;
			}
			if (req.url.startsWith("/cancel/")) {
				if (row.status !== "confirmed") {
					json(res, 409, { code: "INVALID_BOOKING_STATE" });
					return;
				}
				const sagaId = await module.sagas.admit(
					plan("CancelBooking"),
					{ id, resourceId: row.resourceId },
					{ sagaId: uuid(`cancel:${id}`) },
				);
				json(res, 202, { sagaId });
				return;
			}
			if (req.url.startsWith("/confirm/") && row.status !== "pending") {
				json(res, 409, { code: "INVALID_BOOKING_STATE" });
				return;
			}
			if (
				req.url.startsWith("/expire/") &&
				Math.floor(Date.now() / 1000) < row.expiresAt
			) {
				json(res, 409, { code: "DEADLINE_NOT_REACHED" });
				return;
			}
			if (req.url.startsWith("/expire/") && row.status !== "pending") {
				const previous =
					row.status === "expired"
						? await module.store.read(uuid(`expire:${id}`))
						: null;
				if (!previous) {
					json(res, 409, { code: "INVALID_BOOKING_STATE" });
					return;
				}
			}
			const sagaId = req.url.startsWith("/expire/")
				? await expire(row)
				: await module.sagas.admit(plan("ConfirmBooking"), {
						id,
						resourceId: row.resourceId,
						decidedAt: Math.floor(Date.now() / 1000),
						expiresAt: row.expiresAt,
					});
			json(res, 202, { sagaId });
			return;
		}
		await runtime.handler(req, res);
	} catch (e) {
		console.error("request failed", e.message);
		json(res, 400, {
			code: "RESERVATION_REQUEST_FAILED",
			message: "Request could not be completed.",
		});
	}
});
server.listen(Number(process.env.PORT ?? 0), "127.0.0.1", () =>
	console.log(JSON.stringify({ address: server.address() })),
);
async function stop() {
	if (timer) clearInterval(timer);
	server.close();
	await runtime.stop();
	await workers.catch(() => {});
	await pool.end();
}
process.once("SIGTERM", () =>
	stop().catch((e) => {
		console.error(e);
		process.exitCode = 1;
	}),
);

process.on("message", async (message) => {
	if (message?.command === "tick" || message?.command === "dispatch") {
		try {
			const result =
				message.command === "tick"
					? await module.sagas.runOnce()
					: await module.events.dispatch(message.envelope);
			process.send?.({ tick: message.id, result });
		} catch (e) {
			process.send?.({ tick: message.id, error: e.message });
		}
	}
});
