# Reservation / Booking consumer

This application installs the identified `../../artifacts/vane.tgz` as a normal npm file dependency. Node 24 and PostgreSQL 16 are required. No workspace links, private package imports, SQL domain handlers, or implicit framework scheduler are used. TypeScript describes the semantic model; runtime compilation consumes that source through the public compiler.

From this directory, run:

```sh
export VANE_DOGFOOD_DATABASE_URL=postgresql://vane:vane-local-only@127.0.0.1:55432/vane_dogfood
export CONFIRMATION_URL=http://127.0.0.1:1
npm ci
npm run typecheck
npm run build
npm run cleanup
npm run migrate
npm test
npm run cleanup
```

`npm test` starts its own durable confirmation HTTP provider and actual application processes in the `dogfood_reservation_test` schema, generates evidence through the external harness, then stops every child. It resets only that schema. Default cleanup removes both the interactive and test schemas; an explicit `RESERVATION_SCHEMA` limits cleanup to that selected schema. `RESERVATION_SCHEMA` can override the test schema with a name starting `dogfood_reservation`; this enables isolated simultaneous adopters. The command is bounded and returns nonzero for required FAIL/GAP. Dummy URL above is enough for migration because no ACL is executed there.

For interactive use, start `node gateway.mjs` and copy the printed port into `CONFIRMATION_URL=http://127.0.0.1:PORT`. Run `npm start` in another terminal after migration. Both processes print their bound address as JSON. `PORT` optionally pins the application port. `/booking/events/Resource.Create` accepts `{resourceId,capacity}`, and `/booking/events/Booking.Place` accepts `{id,resourceId,expiresAt}`. Both return durable admission (202); await the terminal SSE `/booking/sagas/SAGA_ID` before interpreting success. `expiresAt` is Unix seconds, persisted at reservation time. `/confirm/ID` supplies the application clock and looks up resource/deadline through the public BookingDetails View; callers cannot supply the decision timestamp. `/expire/ID` uses the persisted deadline, rejecting calls before the trusted application clock reaches that deadline with HTTP 409; its first admitted decision timestamp is the actual trusted clock and is retained unchanged on replay. `/cancel/ID` allows cancellation of confirmed reservations. Public Views are POST `/booking/views/BookingDetails` and `/booking/views/ResourceDetails`.

A new Booking begins as `allocating`. Only the Booking.Ready Event after a successful Resource.Take makes it `pending`. Confirm/expire admission requires `pending`, preventing a cancelled overbooking loser or an allocation still in flight from touching another Booking’s capacity. An already expired Booking may only reconnect to its existing deterministic expiration Saga. Capacity is protected by the Resource Rule and PostgreSQL transaction. Competing Booking decision Events atomically increment a constrained `decisionUnits` column: only one commit can change its value from zero to one. Confirmation requires `decidedAt < expiresAt`; expiration requires `decidedAt >= expiresAt`. The explicit application scheduler polls PendingBookings and admits an expiration Saga with a deterministic identity based on the Booking ID. It resumes missed deadlines after restart. It does not mutate domain tables directly. A confirming reservation belongs to its durable confirmation Saga; expiry polling does not race a committed confirmation claim. Retry/recovery either completes an external effect accepted before the deadline or compensates failed confirmation by releasing capacity.

The HTTP provider validates the persisted deadline using its own trusted clock before performing the confirmation effect. Its fsync-backed file ledger uses the persisted Event ID as idempotency key. An append-only fsync-backed effect journal records each actual confirmation action, independently of delivery counts; timeout/retry overlap tests assert one journal entry. Ledger identity is rechecked after every delayed boundary before the effect. Replay of an accepted predeadline effect returns the same reference without a second effect. The provider is a deterministic test adapter, not a production service. Test controls simulate outages, delay and an external crash barrier. Policies are fixed: 1000 ms timeout, three attempts, fixed 150 ms retry. Tests deliberately verify capacity races for 50 rounds and confirm/expire races for 50 on/afterdeadline rounds plus 10 predeadline rounds. Early expiration attempts with forged timestamps must return 409 without admission or mutation.

`WORKERS=off` and `SCHEDULER=off` provide explicit application supervision controls. The test supervisor uses process IPC to call the public `runOnce` and Event dispatch APIs at durable barriers. A public Event dispatch wrapper exposes a release-committed barrier after the saved receipt, while the Saga still awaits its checkpoint; SIGKILL there demonstrates mailbox deduplication rather than merely pausing before release. IPC is privileged, only available to the parent process, and never exposed as an HTTP inspection route. Tests use SIGKILL and independently restart processes against unchanged storage/plans/ledger. SQL is limited to migrations, schema cleanup and read-only assertions.

AWS is N/A: this consumer uses a concrete HTTP confirmation integration, without an AWS dependency.

## Adoption frictions and consultations

Implementer consulted the public README, docs/postgresql.md, docs/sagas.md, docs/service-configuration.md, docs/operations.md and the Sales/Billing reference. Implementer also inspected framework DSL/public runtime source to resolve update guards, runtime service topology shape, migration `previous:null`, public View array response, Saga worker/operations and outbox lease APIs. The exact consulted files and purposes are recorded in `consultations.json`; this implementation does not claim independent adoption.

- DX: a first migration requires `previous:null`; omission throws a TypeError instead of a diagnostic. Resolved in the consumer by following the CLI behavior; public docs should show null for an initial migration.
- DX: public HTTP Views return an array, while terminal SSE returns a View envelope. Resolved with explicit response parsing in tests.
- MISSING CAPABILITY: update has no conditional precondition or runtime-clock token. The app implements a constrained decision counter, status/deadline Rules, trusted application/provider clocks and persisted deadlines. This is an explicit domain pattern; no SQL workaround or core pivot is introduced.
- DX: Rules must reference two distinct Columns. Single-column decision bounds belong on Column constraints. Resolved in the model.

- F8-13 BUG P1 resolved: a cancelled overbooking loser or a Booking still allocating could formerly enter confirmation/expiration against another Booking’s capacity. `allocating` → Booking.Ready after Resource.Take and pending-only admission guards close both paths. RB02 asserts rejection, unchanged ledger/owner rows, and preservation of a confirmed winner. Expired replay returns only the existing deterministic Saga.
- F8-14 BUG P2 workaround: the public PostgreSQL startup comparison can falsely report CHECK drift when PostgreSQL flattens a left-associated OR subgroup. The two equivalent forms `or(or(a,b),c)` and `or(a,or(b,c))` preserve logical semantics, but the consumer uses the documented right-nested form; Two repeated same-plan migrations and two separate public service start/stop cycles accepted the installed constraint without drift (`../../evidence/reservation-schema-start.json`); the full RB-01–08 suite also passed its real process restarts. No capacity/deadline guarantee depends on the unsupported left-group representation.

Full scenario results, including any remaining FAIL/GAP, are in `../../evidence/reservation.json` and `.md`. No scenario is certified solely from code inspection.
