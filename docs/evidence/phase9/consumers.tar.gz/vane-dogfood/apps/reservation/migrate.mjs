import pg from "pg";
import {
	compileServiceConfiguration,
	createPostgreSqlMigrationPlan,
	applyPostgreSqlMigrationPlan,
} from "@lilka/vane";
import configuration from "./configuration.mjs";
const pool = new pg.Pool({
	connectionString: process.env.VANE_DOGFOOD_DATABASE_URL,
});
const result = compileServiceConfiguration(configuration, "test");
if (!result.success) throw Error(JSON.stringify(result.diagnostics));
try {
	if (process.argv.includes("--cleanup")) {
		const schemas = process.env.RESERVATION_SCHEMA
			? [process.env.RESERVATION_SCHEMA]
			: ["dogfood_reservation", "dogfood_reservation_test"];
		for (const schema of schemas) {
			if (!/^dogfood_reservation[a-z0-9_]*$/.test(schema))
				throw Error("Refusing non-dogfood schema");
			await pool.query(`DROP SCHEMA IF EXISTS "${schema}" CASCADE`);
		}
	} else
		await applyPostgreSqlMigrationPlan(
			pool,
			createPostgreSqlMigrationPlan({
				previous: null,
				next: result.plan.storage,
				renames: { tables: [], columns: [] },
			}),
		);
} finally {
	await pool.end();
}
