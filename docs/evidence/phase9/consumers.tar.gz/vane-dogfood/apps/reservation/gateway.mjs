import { createServer } from "node:http";
import {
	readFileSync,
	writeFileSync,
	renameSync,
	openSync,
	fsyncSync,
	closeSync,
	existsSync,
	appendFileSync,
} from "node:fs";
const file = process.env.CONFIRMATION_LEDGER ?? "confirmation-ledger.json";
const control = process.env.CONFIRMATION_CONTROL ?? "confirmation-control.json";
const ledger = existsSync(file) ? JSON.parse(readFileSync(file, "utf8")) : {};
function persist() {
	writeFileSync(file + ".tmp", JSON.stringify(ledger, null, 2));
	const fd = openSync(file + ".tmp", "r");
	fsyncSync(fd);
	closeSync(fd);
	renameSync(file + ".tmp", file);
}
const server = createServer(async (req, res) => {
	if (req.url === "/ledger") {
		res.setHeader("content-type", "application/json");
		res.end(JSON.stringify(ledger));
		return;
	}
	let text = "";
	for await (const chunk of req) text += chunk;
	const payload = JSON.parse(text || "{}");
	const key = req.headers["idempotency-key"];
	let settings = {};
	try {
		settings = JSON.parse(readFileSync(control, "utf8"));
	} catch {}
	if (!key) {
		res.writeHead(400);
		res.end("{}");
		return;
	}
	if (ledger[key]) {
		if (ledger[key].payload !== JSON.stringify(payload)) {
			res.writeHead(409);
			res.end("{}");
			return;
		}
		ledger[key].deliveries++;
		persist();
		res.writeHead(200, { "content-type": "application/json" });
		res.end(JSON.stringify({ reference: ledger[key].reference }));
		return;
	}
	if (settings.delayMs)
		await new Promise((r) => setTimeout(r, settings.delayMs));
	if (ledger[key]) {
		if (ledger[key].payload !== JSON.stringify(payload)) {
			res.writeHead(409);
			res.end("{}");
			return;
		}
		ledger[key].deliveries++;
		persist();
		res.writeHead(200, { "content-type": "application/json" });
		res.end(JSON.stringify({ reference: ledger[key].reference }));
		return;
	}
	if (settings.unavailable) {
		res.writeHead(503);
		res.end("{}");
		return;
	}
	if (Math.floor(Date.now() / 1000) >= payload.expiresAt) {
		res.writeHead(402);
		res.end("{}");
		return;
	}
	appendFileSync(
		file + ".effects.ndjson",
		JSON.stringify({
			eventId: key,
			bookingId: payload.id,
			at: new Date().toISOString(),
		}) + "\n",
	);
	const effectFd = openSync(file + ".effects.ndjson", "r");
	fsyncSync(effectFd);
	closeSync(effectFd);
	ledger[key] = {
		payload: JSON.stringify(payload),
		reference: `confirmation-${key}`,
		effects: 1,
		deliveries: 1,
		at: new Date().toISOString(),
	};
	persist();
	if (settings.holdAfterEffect) {
		return;
	}
	res.writeHead(200, { "content-type": "application/json" });
	res.end(JSON.stringify({ reference: ledger[key].reference }));
});
server.listen(0, "127.0.0.1", () =>
	console.log(JSON.stringify({ address: server.address() })),
);
process.once("SIGTERM", () => {
	server.close();
	server.closeAllConnections();
});
