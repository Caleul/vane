import { readFileSync } from "node:fs";
import {
	BUILTIN_PROVIDERS,
	compileProjectSources,
	env,
	http,
	httpAcl,
	monolith,
	node,
	postgres,
	postgresDeduplication,
	postgresFailureQueue,
	postgresMailbox,
	postgresOutbox,
	postgresSaga,
	serviceConfiguration,
	sse,
} from "@lilka/vane";
const compiled = compileProjectSources([
	{
		fileName: "booking.vane.ts",
		sourceText: readFileSync(
			new URL("./booking.vane.ts", import.meta.url),
			"utf8",
		),
	},
]);
if (!compiled.success) throw Error(JSON.stringify(compiled.diagnostics));
export default serviceConfiguration({
	application: "reservation-dogfood",
	project: compiled.ir,
	providers: BUILTIN_PROVIDERS,
	profiles: {
		test: {
			environment: "test",
			topology: monolith({
				name: "api",
				modules: ["Reservations"],
				runtime: node(),
				persistence: {
					provider: postgres(),
					namespace: process.env.RESERVATION_SCHEMA ?? "dogfood_reservation",
					targetVersion: 16,
					connection: env("VANE_DOGFOOD_DATABASE_URL"),
				},
			}),
			communication: {
				mailbox: postgresMailbox(),
				outbox: postgresOutbox(),
				deduplication: postgresDeduplication(),
				saga: postgresSaga(),
				failureQueue: postgresFailureQueue(),
			},
			http: {
				provider: http(),
				sagaStream: sse(),
				security: {
					authentication: "none",
					authorization: "allow",
					cors: [],
					rateLimit: null,
				},
			},
			telemetry: { exporter: "none" },
			policies: {
				defaults: {
					timeoutMs: 1000,
					retry: {
						attempts: 3,
						backoff: "fixed",
						delayMs: 150,
						maxDelayMs: 150,
					},
				},
			},
			acls: {
				"Reservations.Confirmation.Confirm": {
					provider: httpAcl(),
					version: "1",
					endpoint: env("CONFIRMATION_URL"),
					idempotencyHeader: "Idempotency-Key",
					responses: [
						{
							status: 200,
							result: "approved",
							fields: { reference: "reference" },
						},
						{ status: 402, result: "declined", fields: {} },
					],
				},
			},
			contracts: {
				Reservations: {
					basePath: "/booking",
					events: [
						{
							event: "Resource.Create",
							saga: "CreateResource",
							terminal: {
								view: "ResourceDetails",
								input: {
									resourceId: { kind: "eventInput", input: "resourceId" },
								},
							},
						},
						{
							event: "Booking.Place",
							saga: "Reserve",
							terminal: {
								view: "BookingDetails",
								input: { id: { kind: "eventInput", input: "id" } },
							},
						},
					],
					views: [{ view: "BookingDetails" }, { view: "ResourceDetails" }],
				},
			},
		},
	},
});
