import {
	readFile,
	writeFile,
	mkdir,
	readdir,
	lstat,
	rm,
} from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve, relative, dirname, sep } from "node:path";
import { fileURLToPath } from "node:url";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const manifestPath = resolve(root, "evidence/independent-reproduction.json");
const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
if (!manifest.finishedAt || !manifest.destination || !manifest.runId)
	throw new Error("Independent reproduction must be complete before export");
if (!/^[a-zA-Z0-9_-]+$/.test(manifest.runId))
	throw new Error("Invalid reproduction runId");
const source = resolve(manifest.destination);
const prefix = `evidence/reproduction/${manifest.runId}`;
const destination = resolve(root, prefix);
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
function sourceRelative(path) {
	const name = relative(source, resolve(path));
	if (name === ".." || name.startsWith(".." + sep) || resolve(path) === source)
		throw new Error(`Log must be inside reproduction directory: ${path}`);
	return name;
}
const assignment = (command) =>
	command.source === "Versioned consumer README" &&
	/^export [A-Z][A-Z0-9_]*=/.test(command.command ?? "") &&
	!command.log;
for (const command of manifest.commands ?? []) {
	if (assignment(command)) continue;
	if (!command.log) throw new Error("Documented command lacks actual log");
	const path = resolve(source, sourceRelative(command.log));
	if (!(await lstat(path)).isFile())
		throw new Error(`Missing actual command log: ${command.log}`);
	await readFile(path);
}
if (!Array.isArray(manifest.commands) || manifest.commands.length === 0)
	throw new Error("No actual reproduction commands to export");
await rm(destination, { recursive: true, force: true });
await mkdir(destination, { recursive: true });
const artifacts = [];
async function copyFiles(directory, path = "") {
	for (const entry of await readdir(directory, { withFileTypes: true })) {
		const current = resolve(directory, entry.name),
			name = path + entry.name;
		if (entry.isDirectory()) await copyFiles(current, name + "/");
		else if (entry.isFile()) {
			const bytes = await readFile(current),
				target = resolve(destination, name);
			await mkdir(dirname(target), { recursive: true });
			await writeFile(target, bytes);
			if (digest(await readFile(target)) !== digest(bytes))
				throw new Error(`Export byte mismatch: ${name}`);
			artifacts.push({
				original: current,
				exported: `${prefix}/${name}`,
				bytes: bytes.length,
				sha256: digest(bytes),
			});
		} else throw new Error(`Unsupported evidence file type: ${current}`);
	}
}
await copyFiles(resolve(source, "evidence"), "evidence/");
for (const app of manifest.apps ?? []) {
	const directory = resolve(source, "apps", app.app, "evidence");
	try {
		const stat = await lstat(directory);
		if (!stat.isDirectory()) throw new Error("App evidence must be directory");
		await copyFiles(directory, `apps/${app.app}/evidence/`);
	} catch (error) {
		if (error.code !== "ENOENT") throw error;
	}
}
for (const command of manifest.commands) {
	if (assignment(command)) continue;
	const path = sourceRelative(command.log),
		exportedLog = `${prefix}/${path}`;
	if (!artifacts.some((artifact) => artifact.exported === exportedLog))
		throw new Error(`Expected command log was not exported: ${command.log}`);
	command.exportedLog = exportedLog;
}
const index = {
	schema: "vane.reproduction-evidence-export",
	version: 1,
	runId: manifest.runId,
	tarballSha256: manifest.tarballSha256,
	scenarioStatus: manifest.status,
	exportedAt: new Date().toISOString(),
	commands: manifest.commands,
	artifacts: artifacts.sort((a, b) => a.exported.localeCompare(b.exported)),
};
await writeFile(
	resolve(destination, "index.json"),
	JSON.stringify(index, null, 2) + "\n",
);
manifest.evidenceExport = {
	index: `${prefix}/index.json`,
	files: artifacts.length,
	exportedAt: index.exportedAt,
};
await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + "\n");
console.log(
	JSON.stringify({
		status: "EXPORTED",
		runId: manifest.runId,
		scenarioStatus: manifest.status,
		files: artifacts.length,
		index: manifest.evidenceExport.index,
	}),
);
