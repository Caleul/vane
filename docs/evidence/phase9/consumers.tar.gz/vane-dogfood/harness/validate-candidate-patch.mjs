import { mkdtemp, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const source = resolve(process.argv[2] ?? "/workspace/vane");
const baseline = "3465e6c60353796d880022d09f6771d2f46509fe";
const expectedTree = "e4c8fa170d3d6a36bca533f9f3df0526e3678b59";
const directory = await mkdtemp(resolve(tmpdir(), "vane-patch-validation-"));
function run(command, args, cwd = directory) {
	const result = spawnSync(command, args, { cwd, encoding: "utf8" });
	if (result.status !== 0)
		throw new Error(`${command} ${args.join(" ")}: ${result.stderr}`);
	return result.stdout.trim();
}
try {
	run("git", ["clone", "--quiet", "--no-hardlinks", source, directory]);
	run("git", ["checkout", "--quiet", "--detach", baseline]);
	run("git", ["apply", "--index", resolve(root, "harness/candidate.patch")]);
	const tree = run("git", ["write-tree"]);
	if (tree !== expectedTree)
		throw new Error(`Unexpected reconstructed tree ${tree}`);
	run("git", [
		"-c",
		"user.name=Vane patch validation",
		"-c",
		"user.email=vane-patch-validation@users.noreply.github.com",
		"commit",
		"--quiet",
		"-m",
		"Reconstruct candidate for patch validation",
	]);
	if (run("git", ["status", "--porcelain"]))
		throw new Error("Reconstructed checkout is not clean");
	const result = {
		status: "PASS",
		baselineCommit: baseline,
		expectedTree,
		actualTree: tree,
		clean: true,
		build: false,
	};
	if (process.argv.includes("--build")) {
		run("npm", ["ci"]);
		run("npm", ["run", "build"]);
		const packed = JSON.parse(run("npm", ["pack", "--json"]));
		const actualSha256 = createHash("sha256")
			.update(await readFile(resolve(directory, packed[0].filename)))
			.digest("hex");
		const expectedSha256 = createHash("sha256")
			.update(await readFile(resolve(root, "artifacts/vane.tgz")))
			.digest("hex");
		if (actualSha256 !== expectedSha256)
			throw new Error(
				`Package bytes differ: ${actualSha256} versus ${expectedSha256}`,
			);
		Object.assign(result, { build: true, tarballSha256: actualSha256 });
	}
	console.log(JSON.stringify(result, null, 2));
} finally {
	await rm(directory, { recursive: true, force: true });
}
