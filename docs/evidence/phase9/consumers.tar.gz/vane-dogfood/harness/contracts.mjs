export const expectedIds = {
	todo: [
		...Array.from(
			{ length: 5 },
			(_, i) => `TD-${String(i + 1).padStart(2, "0")}`,
		),
		"TD-06-package",
	],
	commerce: Array.from(
		{ length: 7 },
		(_, i) => `CM-${String(i + 1).padStart(2, "0")}`,
	),
	reservation: Array.from(
		{ length: 8 },
		(_, i) => `RB-${String(i + 1).padStart(2, "0")}`,
	),
};
export function missingIds(app, cases) {
	return (expectedIds[app] ?? []).filter(
		(id) => !cases.some((c) => c.id === id),
	);
}
export function manifestValid(manifest, { app, runId, sha256 }) {
	return (
		manifest.app === app &&
		manifest.runId === runId &&
		manifest.tarballSha256 === sha256 &&
		manifest.status === "PASS" &&
		duplicateIds(manifest.cases ?? []).length === 0 &&
		missingIds(app, manifest.cases ?? []).length === 0 &&
		manifest.packageIntegrity?.matches === true
	);
}
export function duplicateIds(cases) {
	const seen = new Set(),
		duplicates = new Set();
	for (const item of cases) {
		if (seen.has(item.id)) duplicates.add(item.id);
		seen.add(item.id);
	}
	return [...duplicates];
}
