import { readdir, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
export async function sourceHashes(directory, prefix = "") {
	const hashes = {};
	async function visit(current, path) {
		for (const entry of await readdir(current, { withFileTypes: true })) {
			if (["node_modules", "dist", "evidence"].includes(entry.name)) continue;
			const relative = path + entry.name;
			if (entry.isDirectory())
				await visit(resolve(current, entry.name), relative + "/");
			else if (entry.isFile())
				hashes[relative] = createHash("sha256")
					.update(await readFile(resolve(current, entry.name)))
					.digest("hex");
		}
	}
	await visit(directory, prefix);
	return Object.fromEntries(
		Object.entries(hashes).sort(([a], [b]) => a.localeCompare(b)),
	);
}
export function sameHashes(actual, expected) {
	return (
		expected &&
		Object.keys(actual).length === Object.keys(expected).length &&
		Object.entries(actual).every(([key, value]) => expected[key] === value)
	);
}
