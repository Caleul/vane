import test from "node:test";
import assert from "node:assert/strict";
import { missingIds, manifestValid } from "./contracts.mjs";
const good = {
	app: "todo",
	runId: "fresh",
	tarballSha256: "correct",
	status: "PASS",
	packageIntegrity: { matches: true },
	cases: [
		...Array.from({ length: 5 }, (_, i) => ({
			id: `TD-0${i + 1}`,
			status: "PASS",
		})),
		{ id: "TD-06-package", status: "PASS" },
	],
};
const gate = { app: "todo", runId: "fresh", sha256: "correct" };
test("complete manifest accepted", () =>
	assert.equal(manifestValid(good, gate), true));
test("omitted and empty scenarios rejected", () => {
	assert.equal(missingIds("todo", []).length, 6);
	assert.equal(
		manifestValid({ ...good, cases: good.cases.slice(1) }, gate),
		false,
	);
});
test("changed artifact and changed installation rejected", () => {
	assert.equal(manifestValid(good, { ...gate, sha256: "changed" }), false);
	assert.equal(
		manifestValid({ ...good, packageIntegrity: { matches: false } }, gate),
		false,
	);
});
test("stale and cross app evidence rejected", () => {
	assert.equal(manifestValid(good, { ...gate, runId: "new" }), false);
	assert.equal(manifestValid(good, { ...gate, app: "commerce" }), false);
});
test("blocked report rejected", () =>
	assert.equal(manifestValid({ ...good, status: "BLOCKED" }, gate), false));

test("reporter catches a failed assertion and returns nonzero evidence", async () => {
	const { createReporter } = await import("./evidence.mjs");
	const { rm } = await import("node:fs/promises");
	const report = createReporter("harness-selftest-failure");
	await report.case({ id: "NEGATIVE" }, async () => {
		throw new Error("deliberate assertion failure");
	});
	const manifest = await report.finish();
	assert.equal(manifest.status, "BLOCKED");
	assert.equal(manifest.cases[0].status, "FAIL");
	assert.equal(process.exitCode, 1);
	process.exitCode = 0;
	await Promise.all(
		["json", "md"].map((extension) =>
			rm(
				new URL(
					`../evidence/harness-selftest-failure.${extension}`,
					import.meta.url,
				),
			),
		),
	);
});
test("reporter rejects an empty execution", async () => {
	const { createReporter } = await import("./evidence.mjs");
	const { rm } = await import("node:fs/promises");
	const manifest = await createReporter("harness-selftest-empty").finish();
	assert.equal(manifest.status, "BLOCKED");
	assert.equal(process.exitCode, 1);
	process.exitCode = 0;
	await Promise.all(
		["json", "md"].map((extension) =>
			rm(
				new URL(
					`../evidence/harness-selftest-empty.${extension}`,
					import.meta.url,
				),
			),
		),
	);
});

test("invented and empty requirement references rejected; exact catalog accepted", async () => {
	const { invalidRequirements, requirementOrigins } = await import(
		"./requirements.mjs"
	);
	assert.deepEqual(
		invalidRequirements(["EE-ENT-001", "VR-DX-008", "VR-LOCAL-006"]),
		[],
	);
	assert.equal(
		requirementOrigins(["EE-ENT-001"])[0].sources[0].id,
		"FR-ENT-001",
	);
	assert.deepEqual(invalidRequirements(["EE-INVENTED-001", "VR-DX-009"]), [
		"EE-INVENTED-001",
		"VR-DX-009",
	]);
	assert.equal(invalidRequirements([]).length, 1);
});
test("duplicate scenario IDs invalidate an otherwise complete report", () => {
	assert.equal(
		manifestValid({ ...good, cases: [...good.cases, good.cases[0]] }, gate),
		false,
	);
});
