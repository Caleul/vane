import { mkdir, writeFile, readFile, readdir } from "node:fs/promises";
import { createHash, randomUUID } from "node:crypto";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import {
	invalidRequirements,
	requirementOrigins,
	requirementCatalogSha256,
} from "./requirements.mjs";
import { missingIds, duplicateIds } from "./contracts.mjs";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
export function createReporter(app) {
	const cases = [],
		startedAt = new Date().toISOString();
	async function record(spec, status, observed, error) {
		if (
			status === "PASS" &&
			Array.isArray(spec.obligations) &&
			spec.obligations.some(
				(item) => item.status !== "PASS" && item.status !== "N/A",
			)
		)
			status = "GAP";
		const invalid = invalidRequirements(spec.requirements);
		let validationError;
		if (
			["todo", "commerce", "reservation"].includes(app) &&
			invalid.length &&
			status !== "GAP" &&
			spec.id !== "PACKAGE-INTEGRITY"
		) {
			status = "GAP";
			spec = { ...spec, required: true };
			validationError = `Unknown or absent requirement references: ${invalid.join(", ")}`;
		}
		if (cases.some((item) => item.id === spec.id)) {
			status = "GAP";
			spec = { ...spec, required: true };
			validationError = "Duplicate scenario ID";
		}
		const entry = {
			...spec,
			requirementOrigins: requirementOrigins(spec.requirements),
			validationError,
			required: spec.required !== false,
			status,
			observed,
			error: error?.stack,
			timestamp: new Date().toISOString(),
			command: process.argv.join(" "),
			exitCode:
				status === "FAIL" || (status === "GAP" && spec.required !== false)
					? 1
					: 0,
		};
		cases.push(entry);
		console.log(
			`${app} ${entry.id}: ${status}${error ? ` — ${error.message}` : ""}`,
		);
		return entry;
	}
	return {
		cases,
		async case(spec, run) {
			try {
				return await record(spec, "PASS", await run());
			} catch (error) {
				return record(spec, "FAIL", undefined, error);
			}
		},
		async gap(spec, observed) {
			return record(spec, "GAP", observed);
		},
		async na(spec, observed) {
			return record({ ...spec, required: false }, "N/A", observed);
		},
		async finish() {
			await mkdir(resolve(root, "evidence"), { recursive: true });
			let tarballSha256 = null;
			try {
				tarballSha256 = createHash("sha256")
					.update(await readFile(resolve(root, "artifacts/vane.tgz")))
					.digest("hex");
			} catch {}
			for (const id of missingIds(app, cases))
				await record(
					{ id, required: true, expected: "Required scenario must execute" },
					"GAP",
					"Required scenario was omitted",
				);
			let packageIntegrity = {
				matches: false,
				reason: "Installed package/lock not found",
			};
			const sourceHashes = {};
			const appRoot = resolve(root, "apps", app);
			try {
				const bytes = await readFile(resolve(root, "artifacts/vane.tgz"));
				const integrity =
					"sha512-" + createHash("sha512").update(bytes).digest("base64");
				const lock = JSON.parse(
					await readFile(resolve(appRoot, "package-lock.json"), "utf8"),
				);
				const installedLock = JSON.parse(
					await readFile(
						resolve(appRoot, "node_modules/.package-lock.json"),
						"utf8",
					),
				);
				const packageEntry = lock.packages["node_modules/@lilka/vane"];
				const installedEntry =
					installedLock.packages["node_modules/@lilka/vane"];
				let matches =
					packageEntry?.integrity === integrity &&
					installedEntry?.integrity === integrity;
				const archive = spawnSync(
					"tar",
					["-tzf", resolve(root, "artifacts/vane.tgz")],
					{ encoding: "utf8" },
				);
				if (archive.status !== 0) matches = false;
				let comparedFiles = 0;
				for (const name of archive.stdout
					.split("\n")
					.filter((n) => n.startsWith("package/") && !n.endsWith("/"))) {
					const packed = spawnSync("tar", [
						"-xOzf",
						resolve(root, "artifacts/vane.tgz"),
						name,
					]);
					const installed = await readFile(
						resolve(appRoot, "node_modules/@lilka/vane", name.slice(8)),
					);
					if (packed.status !== 0 || !packed.stdout.equals(installed))
						matches = false;
					comparedFiles++;
				}
				packageIntegrity = {
					matches,
					integrity,
					lockIntegrity: packageEntry?.integrity,
					installedIntegrity: installedEntry?.integrity,
					comparedFiles,
				};
			} catch (error) {
				packageIntegrity.reason = error.message;
			}
			async function hashSources(directory, prefix = "") {
				for (const entry of await readdir(directory, { withFileTypes: true })) {
					if (["node_modules", "dist"].includes(entry.name)) continue;
					const name = prefix + entry.name;
					if (entry.isDirectory())
						await hashSources(resolve(directory, entry.name), name + "/");
					else
						sourceHashes[name] = createHash("sha256")
							.update(await readFile(resolve(directory, entry.name)))
							.digest("hex");
				}
			}
			try {
				await hashSources(appRoot);
			} catch {}
			for (const directory of ["harness", ".github"]) {
				try {
					await hashSources(resolve(root, directory), `../${directory}/`);
				} catch {}
			}
			try {
				sourceHashes["../README.md"] = createHash("sha256")
					.update(await readFile(resolve(root, "README.md")))
					.digest("hex");
			} catch {}
			if (
				(app === "todo" || app === "commerce" || app === "reservation") &&
				!packageIntegrity.matches
			)
				await record(
					{ id: "PACKAGE-INTEGRITY", required: true },
					"FAIL",
					packageIntegrity,
				);
			const failed = cases.some((c) => c.exitCode !== 0) || cases.length === 0;
			let provenance = null;
			try {
				provenance = JSON.parse(
					await readFile(resolve(root, "artifacts/candidate.json"), "utf8"),
				);
			} catch {}
			let infrastructure = null;
			try {
				infrastructure = JSON.parse(
					await readFile(resolve(root, "evidence/infrastructure.json"), "utf8"),
				);
			} catch {}
			const manifest = {
				requirementCatalogSha256,
				infrastructure,
				runId: process.env.VANE_DOGFOOD_RUN_ID ?? randomUUID(),
				sourceHashes,
				packageIntegrity,
				timeoutMs: Number(process.env.VANE_DOGFOOD_TIMEOUT_MS ?? 120000),
				provenance,
				app,
				startedAt,
				finishedAt: new Date().toISOString(),
				node: process.version,
				seed: process.env.VANE_DOGFOOD_SEED ?? "phase-8-fixed",
				candidate:
					process.env.VANE_DOGFOOD_CANDIDATE ?? provenance?.commit ?? null,
				tarballSha256,
				status: failed ? "BLOCKED" : "PASS",
				exitCode: failed ? 1 : 0,
				cases,
			};
			await writeFile(
				resolve(root, `evidence/${app}.json`),
				JSON.stringify(manifest, null, 2) + "\n",
			);
			await writeFile(
				resolve(root, `evidence/${app}.md`),
				`# ${app}: ${manifest.status}\n\nNode: ${manifest.node}\nPackage SHA-256: ${tarballSha256}\n\n` +
					cases
						.map(
							(c) =>
								`## ${c.id}: ${c.status}\n\nRequirements: ${(c.requirements ?? []).join(", ")}\n\nPrecondition: ${c.precondition ?? ""}\n\nAction: ${c.action ?? ""}\n\nExpected: ${c.expected ?? ""}\n\nObserved: ${typeof c.observed === "string" ? c.observed : JSON.stringify(c.observed)}\n\n${c.error ?? ""}\n`,
						)
						.join("\n"),
			);
			if (failed) process.exitCode = 1;
			return manifest;
		},
	};
}
