import { mkdtemp, mkdir, cp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve, dirname, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash, randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { sourceHashes as hashSources } from "./source-hashes.mjs";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const names = process.argv.includes("--app")
	? [process.argv[process.argv.indexOf("--app") + 1]]
	: ["todo", "commerce", "reservation"];
if (names.some((name) => !["todo", "commerce", "reservation"].includes(name)))
	throw Error("Unknown consumer");
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const tarballSha256 = sha(await readFile(resolve(root, "artifacts/vane.tgz")));
const runId = process.env.VANE_DOGFOOD_RUN_ID ?? randomUUID();
const startedAt = new Date().toISOString(),
	started = Date.now();
const destination = await mkdtemp(resolve(tmpdir(), "vane-independent-"));
await mkdir(resolve(destination, "apps"), { recursive: true });
await cp(resolve(root, "artifacts"), resolve(destination, "artifacts"), {
	recursive: true,
});
await cp(resolve(root, "harness"), resolve(destination, "harness"), {
	recursive: true,
});
await cp(resolve(root, "public-docs"), resolve(destination, "public-docs"), {
	recursive: true,
});
await mkdir(resolve(destination, "evidence"), { recursive: true });
const provenance = JSON.parse(
	await readFile(resolve(root, "artifacts/candidate.json"), "utf8"),
);
const hashes = hashSources;
const docsHashes = await hashes(resolve(destination, "public-docs"));
const commands = [],
	apps = [];
const env = {
	...process.env,
	VANE_DOGFOOD_RUN_ID: runId,
	VANE_DOGFOOD_DATABASE_URL:
		process.env.VANE_DOGFOOD_DATABASE_URL ??
		"postgresql://vane:vane-local-only@127.0.0.1:55432/vane_dogfood",
	VANE_DOGFOOD_MOTO_URL:
		process.env.VANE_DOGFOOD_MOTO_URL ?? "http://127.0.0.1:55000",
	AWS_EC2_METADATA_DISABLED: "true",
};
async function command(app, args, executable = "npm") {
	const began = new Date().toISOString(),
		file = resolve(destination, "evidence", `${app}-${commands.length}.log`);
	const child = spawn(executable, args, {
		cwd: resolve(destination, "apps", app),
		env,
		detached: true,
		stdio: ["ignore", "pipe", "pipe"],
	});
	let output = "";
	child.stdout.on("data", (data) => (output += data));
	child.stderr.on("data", (data) => (output += data));
	const timer = setTimeout(() => {
		try {
			process.kill(-child.pid, "SIGKILL");
		} catch {}
	}, 180000);
	const code = await new Promise((accept, reject) => {
		child.once("error", reject);
		child.once("exit", accept);
	});
	clearTimeout(timer);
	await writeFile(file, output);
	commands.push({
		app,
		command: [executable, ...args].join(" "),
		startedAt: began,
		finishedAt: new Date().toISOString(),
		exitCode: code,
		log: file,
	});
	return { code, output, startedAt: began };
}
async function startAndStop(app) {
	const began = new Date().toISOString(),
		file = resolve(destination, "evidence", `${app}-start.log`);
	const child = spawn("npm", ["start"], {
		cwd: resolve(destination, "apps", app),
		env,
		detached: true,
		stdio: ["ignore", "pipe", "pipe"],
	});
	let output = "";
	child.stdout.on("data", (data) => (output += data));
	child.stderr.on("data", (data) => (output += data));
	const exited = new Promise((accept) =>
		child.once("exit", (code, signal) => accept({ code, signal })),
	);
	const end = Date.now() + 30000;
	let ready = false;
	try {
		while (Date.now() < end && child.exitCode === null) {
			ready = output.split("\n").some((line) => {
				try {
					const value = JSON.parse(line);
					return value.ready || value.application || value.address;
				} catch {
					return false;
				}
			});
			if (ready) break;
			await new Promise((accept) => setTimeout(accept, 30));
		}
		if (!ready) throw Error("Documented npm start never became ready");
	} finally {
		if (child.exitCode === null) {
			try {
				process.kill(-child.pid, "SIGTERM");
			} catch {}
		}
		const timer = setTimeout(() => {
			try {
				process.kill(-child.pid, "SIGKILL");
			} catch {}
		}, 10000);
		const outcome = await exited;
		clearTimeout(timer);
		await writeFile(file, output);
		commands.push({
			app,
			command: "npm start",
			startedAt: began,
			finishedAt: new Date().toISOString(),
			exitCode: outcome.code,
			signal: outcome.signal,
			ready,
			log: file,
		});
	}
}
for (const app of names) {
	const entry = {
		app,
		status: "BLOCKED",
		startedAt: new Date().toISOString(),
		coreSourceConsultations: 0,
	};
	apps.push(entry);
	try {
		await cp(resolve(root, "apps", app), resolve(destination, "apps", app), {
			recursive: true,
			filter: (file) =>
				!relative(resolve(root, "apps", app), file)
					.split("/")
					.some((part) => ["node_modules", "dist", "evidence"].includes(part)),
		});
		entry.sourceHashes = await hashes(resolve(destination, "apps", app));
		const readme = await readFile(
			resolve(destination, "apps", app, "README.md"),
			"utf8",
		);
		for (const match of readme.matchAll(
			/^export ([A-Z][A-Z0-9_]*)=([^\s]+)$/gm,
		)) {
			const [, name, value] = match;
			if (
				![
					"VANE_DOGFOOD_DATABASE_URL",
					"VANE_DOGFOOD_MOTO_URL",
					"AWS_EC2_METADATA_DISABLED",
					"CONFIRMATION_URL",
				].includes(name)
			)
				throw Error(`Undocumented environment handling needed: ${name}`);
			env[name] = value;
			commands.push({
				app,
				command: `export ${name}=${value}`,
				startedAt: new Date().toISOString(),
				exitCode: 0,
				source: "Versioned consumer README",
			});
		}
		for (const args of [
			["ci"],
			["run", "typecheck"],
			["run", "build"],
			["run", "cleanup"],
			["run", "migrate"],
		]) {
			const literal = ["npm", ...args].join(" ");
			if (!readme.includes(literal))
				throw Error(`README lacks literal command: ${literal}`);
			const result = await command(app, args);
			if (result.code !== 0)
				throw Error(`${literal} failed; inspect recorded log`);
		}
		const cli = "./node_modules/.bin/entity-event";
		const help = await command(app, ["--help"], cli);
		if (help.code !== 0 || !help.output.includes("Usage: entity-event"))
			throw Error("CLI help must print usage and exit successfully");
		const invalid = await command(app, ["unknown-dogfood-command"], cli);
		if (invalid.code !== 1 || !invalid.output.includes("Usage: entity-event"))
			throw Error("Invalid CLI command lacks nonzero actionable usage");
		const validated = await command(
			app,
			[
				"validate",
				"--config",
				"configuration.mjs",
				"--profile",
				"test",
				"--json",
			],
			cli,
		);
		if (validated.code !== 0)
			throw Error("Corrected public CLI validate failed");
		entry.cli = {
			requirements: ["VR-DX-007"],
			helpExitCode: help.code,
			invalidCommandExitCode: invalid.code,
			validateExitCode: validated.code,
			friction:
				"--help prints usage and exits 0; Phase 8 DX/P2 friction resolved",
		};
		if (!readme.includes("npm start")) throw Error("README lacks npm start");
		await startAndStop(app);
		// The documented second terminal runs the complete consumer test, which owns
		// actual HTTP servers and proves its first functional Event/View.
		if (!readme.includes("npm test")) throw Error("README lacks npm test");
		const result = await command(app, ["test"]);
		const manifest = JSON.parse(
			await readFile(resolve(destination, "evidence", `${app}.json`), "utf8"),
		);
		const failures = manifest.cases.filter(
			(item) =>
				item.status === "FAIL" || (item.required && item.status === "GAP"),
		);
		if (result.code !== 0 || failures.length)
			throw Error(
				`Consumer test failed: ${failures.map((item) => `${item.id}:${item.status}`).join(", ")}`,
			);
		if (
			!manifest.packageIntegrity?.matches ||
			manifest.tarballSha256 !== tarballSha256
		)
			throw Error("Installed artifact identity differs");
		entry.testCases = manifest.cases.map(({ id, status }) => ({ id, status }));
		const first = manifest.cases.find(
			(item) =>
				["TD-01", "CM-01", "RB-01"].includes(item.id) && item.status === "PASS",
		);
		if (!first)
			throw Error("First functional Event/View scenario did not pass");
		entry.firstFunctionalScenario = first.id;
		entry.firstFunctionalTimestamp = first.timestamp;
		entry.timeFromTestStartToFirstFunctionalEventViewMs =
			Date.parse(first.timestamp) - Date.parse(result.startedAt);
		entry.timeToFirstFunctionalEventViewMs =
			Date.parse(first.timestamp) - Date.parse(entry.startedAt);
		entry.reproductionDurationMs = Date.now() - started;
		entry.status = "PASS";
		const cleanup = await command(app, ["run", "cleanup"]);
		if (cleanup.code !== 0) throw Error("Documented cleanup failed");
	} catch (error) {
		entry.status = "BLOCKED";
		entry.error = error.stack;
	}
	entry.finishedAt = new Date().toISOString();
}
const status =
	names.length === 3 && apps.every((app) => app.status === "PASS")
		? "PASS"
		: "BLOCKED";
const sourceHashes = Object.fromEntries(
	apps.map((entry) => [entry.app, entry.sourceHashes]),
);
const manifest = {
	status,
	partial: names.length !== 3,
	runId,
	tarballSha256,
	provenance,
	docsHashes,
	sourceHashes,
	startedAt,
	finishedAt: new Date().toISOString(),
	destination,
	node: process.version,
	coreSourceConsultations: 0,
	method:
		"Independent reviewer supplied only external consumer files, tarball and public documentation. README install/build/migration/start/test/cleanup commands executed from fresh directories. Tests own real HTTP processes. TD-06 final coverage composes package fixture and this independent reproduction.",
	apps,
	commands,
};
await writeFile(
	resolve(root, "evidence/independent-reproduction.json"),
	JSON.stringify(manifest, null, 2) + "\n",
);
console.log(
	JSON.stringify({
		status,
		partial: manifest.partial,
		destination,
		apps: apps.map(({ app, status, error }) => ({ app, status, error })),
	}),
);
if (apps.some((app) => app.status !== "PASS")) process.exitCode = 1;
