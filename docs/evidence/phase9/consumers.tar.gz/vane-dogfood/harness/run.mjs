import { createHash, randomUUID } from "node:crypto";
import { sourceHashes, sameHashes } from "./source-hashes.mjs";
import { manifestValid } from "./contracts.mjs";
import { spawnSync } from "node:child_process";
import { writeFile, readFile, mkdir } from "node:fs/promises";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const operation = process.argv[2];
if (process.version !== "v24.19.0")
	throw new Error(`Requires Node 24.19.0; observed ${process.version}`);
const env = {
	...process.env,
	VANE_DOGFOOD_DATABASE_URL:
		process.env.VANE_DOGFOOD_DATABASE_URL ??
		"postgres://vane:vane-local-only@127.0.0.1:55432/vane_dogfood",
	VANE_DOGFOOD_MOTO_URL:
		process.env.VANE_DOGFOOD_MOTO_URL ?? "http://127.0.0.1:55000",
	AWS_ACCESS_KEY_ID: "dogfood-local",
	AWS_SECRET_ACCESS_KEY: "dogfood-local",
	AWS_DEFAULT_REGION: "us-east-1",
	AWS_REGION: "us-east-1",
	AWS_EC2_METADATA_DISABLED: "true",
	VANE_DOGFOOD_RUN_ID: randomUUID(),
};
const motoUrl = new URL(env.VANE_DOGFOOD_MOTO_URL);
if (
	!["127.0.0.1", "localhost", "[::1]"].includes(motoUrl.hostname) ||
	motoUrl.protocol !== "http:"
)
	throw new Error("Moto must use a loopback HTTP URL");
function run(command, args, { cwd = root, allowFailure = false } = {}) {
	const result = spawnSync(command, args, { cwd, env, stdio: "inherit" });
	if (result.status !== 0 && !allowFailure)
		throw new Error(
			`${command} ${args.join(" ")} exited ${result.status}: ${result.error ?? ""}`,
		);
	return result.status;
}
const docker = (args, options) =>
	run("docker", ["--host", "unix:///var/run/docker.sock", ...args], options);
const containers = ["vane-dogfood-postgres", "vane-dogfood-moto"];
async function cleanup() {
	for (const name of containers)
		docker(["rm", "-f", name], { allowFailure: true });
}
async function waitFor(url) {
	let last;
	for (let n = 0; n < 120; n++) {
		try {
			const response = await fetch(url, { redirect: "error" });
			if (response.ok) return;
		} catch (error) {
			last = error;
		}
		await new Promise((r) => setTimeout(r, 500));
	}
	throw new Error(`Health check timed out: ${url} ${last ?? ""}`);
}
async function infrastructure() {
	await cleanup();
	docker([
		"run",
		"-d",
		"--name",
		containers[0],
		"-p",
		"127.0.0.1:55432:5432",
		"-e",
		"POSTGRES_USER=vane",
		"-e",
		"POSTGRES_PASSWORD=vane-local-only",
		"-e",
		"POSTGRES_DB=vane_dogfood",
		"--health-cmd",
		"pg_isready -U vane -d vane_dogfood",
		"--health-interval",
		"1s",
		"--health-timeout",
		"5s",
		"--health-retries",
		"60",
		"postgres:16.15@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d",
	]);
	docker([
		"run",
		"-d",
		"--name",
		containers[1],
		"-p",
		"127.0.0.1:55000:5000",
		"-e",
		"MOTO_PORT=5000",
		"motoserver/moto:5.1.18@sha256:c99ea4ab0881e1d95af5601c2cd42ef4dac15eefdf6597532c59d9631068818a",
	]);
	for (let n = 0; n < 120; n++) {
		if (
			docker(
				[
					"exec",
					containers[0],
					"pg_isready",
					"-U",
					"vane",
					"-d",
					"vane_dogfood",
				],
				{ allowFailure: true },
			) === 0
		)
			break;
		if (n === 119) throw new Error("PostgreSQL healthcheck timeout");
		await new Promise((r) => setTimeout(r, 500));
	}
	await waitFor(env.VANE_DOGFOOD_MOTO_URL + "/moto-api/");
	const postgresVersion = spawnSync(
		"docker",
		[
			"--host",
			"unix:///var/run/docker.sock",
			"exec",
			containers[0],
			"psql",
			"-U",
			"vane",
			"-d",
			"vane_dogfood",
			"-Atc",
			"SHOW server_version",
		],
		{ encoding: "utf8" },
	).stdout.trim();
	const motoVersion = spawnSync(
		"docker",
		[
			"--host",
			"unix:///var/run/docker.sock",
			"exec",
			containers[1],
			"python",
			"-c",
			"import moto; print(moto.__version__)",
		],
		{ encoding: "utf8" },
	).stdout.trim();
	await mkdir(resolve(root, "evidence"), { recursive: true });
	await writeFile(
		resolve(root, "evidence/infrastructure.json"),
		JSON.stringify(
			{
				status:
					postgresVersion.startsWith("16.15") && motoVersion === "5.1.18.dev"
						? "PASS"
						: "FAIL",
				node: process.version,
				postgres: {
					version: postgresVersion,
					image:
						"postgres:16.15@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d",
					endpoint: "127.0.0.1:55432",
				},
				moto: {
					version: motoVersion,
					image:
						"motoserver/moto:5.1.18@sha256:c99ea4ab0881e1d95af5601c2cd42ef4dac15eefdf6597532c59d9631068818a",
					endpoint: env.VANE_DOGFOOD_MOTO_URL,
				},
				timestamp: new Date().toISOString(),
			},
			null,
			2,
		) + "\n",
	);
	await writeFile(
		resolve(root, ".env.local"),
		Object.entries(env)
			.filter(
				([key]) => key.startsWith("VANE_DOGFOOD_") || key.startsWith("AWS_"),
			)
			.map(([k, v]) => `${k}=${v}`)
			.join("\n") + "\n",
	);
}
const apps = ["todo", "commerce", "reservation"];
if (operation === "cleanup") await cleanup();
else if (operation === "reset") await infrastructure();
else if (operation === "setup") {
	await readFile(resolve(root, "artifacts/vane.tgz"));
	await infrastructure();
	for (const app of apps)
		run("npm", ["ci"], { cwd: resolve(root, "apps", app) });
} else if (["test", "typecheck"].includes(operation)) {
	let failed = false;
	if (operation === "test") {
		try {
			await readFile(resolve(root, "harness/reproduce.mjs"));
			if (run("node", ["harness/reproduce.mjs"], { allowFailure: true }) !== 0)
				failed = true;
		} catch {
			failed = true;
		}
	}
	for (const app of apps) {
		const code = run("npm", ["run", operation], {
			cwd: resolve(root, "apps", app),
			allowFailure: true,
		});
		if (code !== 0) failed = true;
	}
	if (operation === "test") {
		const summaries = [];
		for (const app of apps) {
			try {
				const evidence = JSON.parse(
					await readFile(resolve(root, "evidence", `${app}.json`), "utf8"),
				);
				summaries.push({
					app,
					status: evidence.status,
					cases: evidence.cases.length,
					tarballSha256: evidence.tarballSha256,
				});
				const sha256 = createHash("sha256")
					.update(await readFile(resolve(root, "artifacts/vane.tgz")))
					.digest("hex");
				if (
					!manifestValid(evidence, {
						app,
						runId: env.VANE_DOGFOOD_RUN_ID,
						sha256,
					})
				)
					failed = true;
			} catch {
				summaries.push({
					app,
					status: "GAP",
					reason: "missing evidence manifest",
				});
				failed = true;
			}
		}
		try {
			const independent = JSON.parse(
				await readFile(
					resolve(root, "evidence", "independent-reproduction.json"),
					"utf8",
				),
			);
			const sha256 = createHash("sha256")
				.update(await readFile(resolve(root, "artifacts/vane.tgz")))
				.digest("hex");
			if (
				independent.partial === true ||
				apps.some(
					(app) =>
						!independent.apps?.some(
							(entry) => entry.app === app && entry.status === "PASS",
						),
				) ||
				independent.status !== "PASS" ||
				independent.runId !== env.VANE_DOGFOOD_RUN_ID ||
				independent.tarballSha256 !== sha256
			)
				failed = true;
			for (const app of apps) {
				if (
					!sameHashes(
						await sourceHashes(resolve(root, "apps", app)),
						independent.sourceHashes?.[app],
					)
				)
					failed = true;
			}
			if (
				!sameHashes(
					await sourceHashes(resolve(root, "public-docs")),
					independent.docsHashes,
				)
			)
				failed = true;
			summaries.push({
				app: "independent-reproduction",
				status: independent.status,
				runId: independent.runId,
				tarballSha256: independent.tarballSha256,
			});
			summaries.push({
				app: "TD-06-composite",
				status: failed ? "BLOCKED" : "PASS",
				components: [
					"todo TD-06-package",
					"independent-reproduction all apps with matching package/source/docs identities",
				],
			});
		} catch {
			failed = true;
			summaries.push({
				app: "independent-reproduction",
				status: "GAP",
				reason: "Independent adoption gate not recorded",
			});
		}
		await mkdir(resolve(root, "evidence"), { recursive: true });
		await writeFile(
			resolve(root, "evidence", "manifest.json"),
			JSON.stringify(
				{
					status: failed ? "BLOCKED" : "PASS",
					timestamp: new Date().toISOString(),
					apps: summaries,
				},
				null,
				2,
			) + "\n",
		);
		if (
			run("node", ["harness/export-evidence.mjs"], { allowFailure: true }) !== 0
		)
			failed = true;
	}
	if (failed) process.exitCode = 1;
} else
	throw new Error(
		"Usage: node harness/run.mjs setup|test|typecheck|reset|cleanup",
	);
