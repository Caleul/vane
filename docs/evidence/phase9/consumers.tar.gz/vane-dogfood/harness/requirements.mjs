import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
const catalogBytes = readFileSync(
	new URL("./ee-catalog.json", import.meta.url),
);
const catalog = JSON.parse(catalogBytes);
export const requirementCatalogSha256 = createHash("sha256")
	.update(catalogBytes)
	.digest("hex");
const origins = new Map(
	catalog.requirements.map((req) => [
		req.id,
		{
			authority: "Entity Event conformance catalog",
			statement: req.statement,
			sources: req.sources,
		},
	]),
);
for (const [prefix, count] of [
	["VR-DX", 8],
	["VR-LOCAL", 6],
])
	for (let i = 1; i <= count; i++)
		origins.set(`${prefix}-${String(i).padStart(3, "0")}`, {
			authority: "Validation & Release PRD",
			url: "https://www.notion.so/3d251cfc265c81ec965fc7a54f78b8d8",
			note: "Phase 8 requirement reference; original PRD defines normative text",
		});
export function invalidRequirements(ids) {
	if (!Array.isArray(ids) || ids.length === 0)
		return ["Missing nonempty requirements array"];
	return ids.filter((id) => !origins.has(id));
}
export function requirementOrigins(ids) {
	return (Array.isArray(ids) ? ids : [])
		.filter((id) => origins.has(id))
		.map((id) => ({ id, ...origins.get(id) }));
}
