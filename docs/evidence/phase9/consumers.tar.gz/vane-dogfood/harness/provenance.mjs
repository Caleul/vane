import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
const source = resolve(process.argv[2] ?? "../vane-candidate");
const artifact = resolve("artifacts/vane.tgz");
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const git = (args) => {
	const result = spawnSync("git", args, { cwd: source, encoding: "utf8" });
	if (result.status !== 0) throw new Error(result.stderr);
	return result.stdout.trim();
};
if (git(["status", "--porcelain"]))
	throw new Error("Candidate checkout must be clean before provenance");
const tree = git(["rev-parse", "HEAD^{tree}"]);
if (
	process.env.VANE_DOGFOOD_EXPECTED_TREE &&
	tree !== process.env.VANE_DOGFOOD_EXPECTED_TREE
)
	throw new Error("Candidate tree differs from expected tree");
const packageMetadata = JSON.parse(
	await readFile(resolve(source, "package.json"), "utf8"),
);
const docs = {};
for (const file of [
	"README.md",
	"examples/sales-billing/README.md",
	"docs/operations.md",
	"docs/semantic-compiler.md",
	"docs/service-configuration.md",
	"docs/sagas.md",
])
	docs[file] = digest(await readFile(resolve(source, file)));
await mkdir("artifacts", { recursive: true });
await writeFile(
	"artifacts/candidate.json",
	JSON.stringify(
		{
			createdAt: new Date().toISOString(),
			package: packageMetadata.name,
			version: packageMetadata.version,
			baselineCommit: process.env.VANE_DOGFOOD_BASELINE_COMMIT ?? null,
			expectedTree: process.env.VANE_DOGFOOD_EXPECTED_TREE ?? null,
			node: process.version,
			commit: git(["rev-parse", "HEAD"]),
			tree: git(["rev-parse", "HEAD^{tree}"]),
			sha256: digest(await readFile(artifact)),
			docs,
		},
		null,
		2,
	) + "\n",
);
