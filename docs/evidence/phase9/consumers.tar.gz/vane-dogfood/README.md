# Vane Phase 8 external consumers

Three independent consumers install `artifacts/vane.tgz` using normal npm dependencies and lockfiles. No workspaces or private package imports are used. This directory must remain outside the Vane repository.

Requires Node **24.19.0**, npm, Docker Engine, and a tarball built by the coordinator from an identified clean candidate checkout.

```sh
npm run setup
npm run typecheck
npm test
npm run cleanup
```

Setup starts disposable PostgreSQL **16.15** on `127.0.0.1:55432` and Moto **5.1.18** on `127.0.0.1:55000`, with local dummy AWS credentials. Containers use no persistent volumes. Reset deletes both containers and their data. `.env.local` records consumer variables; the orchestrator supplies them automatically. Individual consumers may source this file before running their own scripts. The PostgreSQL connection is `postgres://vane:vane-local-only@127.0.0.1:55432/vane_dogfood`; each app isolates its schema.

`npm test` runs all consumers even if one fails, then writes `evidence/manifest.json`. Required FAIL/GAP and absent manifests return nonzero. Per-app JSON and Markdown reports include observed scenario results, timestamps, package digest and process commands. PASS applies only to actually executed scenarios. Independent documentation reproduction and final acceptance remain separate coordinator gates.

Shared reporting is optional: import `createReporter` from `../../harness/evidence.mjs`, call `reporter.case({id, requirements, precondition, action, expected}, async () => observed)` using real assertions, report unimplemented cases with `reporter.gap(spec, reason)`, then `await reporter.finish()`. Exceptions become FAIL; required GAP/FAIL set exit code 1.

Image tags pin exact releases; infrastructure provenance also records the resolved immutable image digests. Evidence artifacts are retained after cleanup.

A complete root run also executes `harness/reproduce.mjs` from an empty consumer copy and requires a fresh independent reproduction manifest for that same run and package. Missing reproduction is GAP. Reporters reject omitted required scenario IDs, duplicate IDs, and unknown or empty requirement references. Valid references come from the versioned `harness/ee-catalog.json`, plus `VR-DX-001` through `VR-DX-008` and `VR-LOCAL-001` through `VR-LOCAL-006`. Requirements retain their catalog source references; describing an app assertion does not establish full PRD coverage.

Run `node --test harness/contracts.test.mjs` to verify report rejection paths. Infrastructure reset is deliberately explicit: call `npm run reset` only between suites, since it removes all app schemas and Moto objects. Moto's fixed release image reports Python package version `5.1.18.dev`; both its tag and immutable image digest identify this artifact.

The final candidate is currently unpublished. CI checks out public baseline `3465e6c60353796d880022d09f6771d2f46509fe`, applies the reviewed `harness/candidate.patch`, and requires tree `e4c8fa170d3d6a36bca533f9f3df0526e3678b59` before making a local CI commit and building. The CI commit identity can differ from the coordinator's local commit; identical tree and package bytes are the reproducibility criteria. `harness/provenance.mjs` refuses dirty candidate checkouts, records the actual commit, dynamic package name/version, baseline and expected tree, package digest, and document hashes. CI copies public documentation from that reconstructed tree for independent adoption.

Validate the unpublished patch independently with `node harness/validate-candidate-patch.mjs /path/to/vane --build`. It clones into a disposable directory, reconstructs the exact candidate tree from the public baseline, commits locally, requires a clean checkout, builds and packs it, and compares the resulting tarball SHA-256 with the consumer artifact. It removes its temporary checkout on completion.

The root test command exports completed independent reproduction logs automatically after recording the scenario manifest. Run `node harness/export-evidence.mjs` again to rebuild portable evidence from a retained reproduction directory. Export preserves original command facts and adds `exportedLog` paths plus a SHA-256 artifact index under `evidence/reproduction/<runId>/`. README environment assignments retain their original records; spawned commands require actual log files. Export failures return nonzero and cannot hide an earlier scenario failure. CI attempts export even after a failed gate and uploads available evidence afterward.
