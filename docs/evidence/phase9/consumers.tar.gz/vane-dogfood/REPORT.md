# Vane — fase 8: implementação e aceite

**PASS** no gate local completo e na [revisão independente](REVIEW.md), executado em 2026-10-10T01:39:51.203Z. Run ID: `6282d09a-bb44-4181-9b45-6dca4f3c5378`. Os 21 grupos obrigatórios passaram na entrega e na reprodução em diretórios vazios. TD-06 reúne os testes do pacote e a adoção independente; o resultado composto está no [manifesto agregado](evidence/manifest.json).

## Identidade e escopo

- Autoridade: [Fase 8 — DevXP & Dogfood](https://www.notion.so/3d251cfc265c81ec965fc7a54f78b8d8), transcrita em [PHASE8-SPEC.md](PHASE8-SPEC.md).
- Plano: fases A–E, tasks e gate em `docs/phase-8-plan.md` do framework; também disponível no [patch do candidato](harness/candidate.patch).
- Core: commit `12ee6a1182f7c6750e02cf3cf6dd4a3b5663ac2e`, árvore `e4c8fa170d3d6a36bca533f9f3df0526e3678b59`; baseline público PR #14 `3465e6c60353796d880022d09f6771d2f46509fe`.
- Pacote: `@lilka/vane@0.0.0`, SHA-256 `786c90654e9430cb32233d2b7647656c09a8cf8a2bbae54de2b1d2a6cf5ce043`. [Proveniência](artifacts/candidate.json), [tarball](artifacts/vane.tgz).
- Fontes dos consumidores congeladas no commit local `ed474e0`; hashes de cada fonte e documento registrados na [reprodução](evidence/independent-reproduction.json). O commit final também inclui os relatórios gerados.
- Node 24.19.0, PostgreSQL 16.15 real, Moto 5.1.18 com imagens por digest. [Ambiente](evidence/infrastructure.json).

## Implementação

Três projetos externos independentes instalam o mesmo tarball com dependências npm e lockfiles próprios: [Todo/Project](apps/todo/README.md), [Commerce](apps/commerce/README.md) e [Reservation/Booking](apps/reservation/README.md). Usam imports públicos, Events do owner para mutações e Views para leitura. O harness externo provisiona, migra, inicia processos reais, exercita HTTP/SSE, captura crashes SIGKILL e retorna erro em FAIL/GAP ou evidência ausente/obsoleta.

Commerce combina ACL, Saga, compensações, ledger externo durável e comprovantes S3/Moto. Reservation usa alocação explícita, decisão atômica por Rule, relógio confiável e scheduler de aplicação. O modelo `allocating → pending` só libera confirmação após Resource.Take; pedidos sobre alocação incompleta ou reserva perdedora são rejeitados e preservam a capacidade da vencedora.

No framework, corrigimos a instalação Docker com CA opcional do proxy e a propriedade dos arquivos para USER node sob umask restritiva. Atualizamos a documentação de sagas duráveis, APIs públicas e migração inicial.

## Verificação executada

| Verificação | Resultado |
| --- | --- |
| Framework: lint, tipos, build e testes unitários | PASS; 248 testes |
| Self-tests de conformidade | PASS; 14 testes |
| Integração PostgreSQL no commit final | PASS; 48 testes |
| Conformidade do tarball final, incluindo imagem gerada real | PASS; 107 casos, 161 requisitos PASS, 0 FAIL/GAP, 1 N/A |
| Harness externo, rejeição de evidências inválidas | PASS; 9 testes |
| Setup limpo e typecheck dos três consumidores | PASS; exit 0 |
| Gate integrado dos três consumidores | PASS; exit 0; 21 grupos obrigatórios |
| Reprodução independente dos três consumidores | PASS; zero consultas ao source do core |
| Identidade do pacote instalado | PASS; SHA-512 dos locks e 155 arquivos comparados por app |
| Reserva concorrente de capacidade 1 | PASS; 50 rodadas |
| Confirmação versus expiração | PASS; 50 rodadas no/após deadline, mais 10 antes |
| Reconstrução baseline + patch, build e pack | PASS; árvore e SHA-256 idênticos |

Logs e comandos do framework: [manifesto](evidence/framework/manifest.json). Gate integrado: [log](evidence/framework/consumer-gate.log). Reconstrução: [resultado](evidence/candidate-patch-validation.json). Os tempos para o primeiro cenário funcional na adoção foram 5.529s (Todo), 7.743s (Commerce) e 5.396s (Reservation); medem execução do exemplo fornecido, sem representar criação de um domínio novo do zero.

## Matriz dos cenários

| Grupo | Resultado | Requisitos rastreados | Evidência |
| --- | --- | --- | --- |
| TD-01 | PASS | VR-DX-001, VR-LOCAL-001, EE-EVT-005, EE-VIEW-003, EE-VIEW-004 | [JSON](evidence/todo.json) / [relato](evidence/todo.md) |
| TD-02 | PASS | VR-DX-004, EE-EVT-010, EE-EVT-016 | [JSON](evidence/todo.json) / [relato](evidence/todo.md) |
| TD-03 | PASS | VR-DX-004, EE-EVT-005, EE-COMP-003 | [JSON](evidence/todo.json) / [relato](evidence/todo.md) |
| TD-04 | PASS | VR-LOCAL-004, EE-PG-006 | [JSON](evidence/todo.json) / [relato](evidence/todo.md) |
| TD-05 | PASS | VR-LOCAL-005, EE-PG-005, EE-RUN-005, EE-NFR-008 | [JSON](evidence/todo.json) / [relato](evidence/todo.md) |
| TD-06 | PASS | VR-DX-002, VR-DX-003, VR-DX-006 | [JSON](evidence/todo.json) / [relato](evidence/todo.md) |
| CM-01 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, VR-LOCAL-002, EE-EVT-004, EE-VIEW-006, EE-HTTP-002 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| CM-02 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-COMP-003, EE-ACL-002 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| CM-03 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-SVC-018, EE-NFR-008 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| CM-04 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, VR-LOCAL-002, VR-LOCAL-003, VR-LOCAL-004, EE-SAGA-004 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| CM-05 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-SAGA-003, EE-PG-006, EE-NFR-008 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| CM-06 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-SAGA-007, EE-HTTP-006, EE-OBS-005 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| CM-07 | PASS | VR-DX-001, VR-DX-002, VR-DX-003, VR-DX-005, VR-DX-008, VR-LOCAL-001, VR-LOCAL-002, VR-LOCAL-003, VR-LOCAL-004, VR-LOCAL-005, VR-LOCAL-006, EE-PG-006 | [JSON](evidence/commerce.json) / [relato](evidence/commerce.md) |
| RB-01 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-EVT-006, EE-HTTP-002, EE-HTTP-003 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-02 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-RUL-003, EE-PG-005, EE-PIVOT-002 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-03 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-SAGA-004, EE-PG-006 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-04 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-RUL-003, EE-PG-005, EE-PIVOT-002 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-05 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-ACL-003, EE-SAGA-005, EE-SAGA-007, EE-NFR-008 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-06 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-SAGA-003, EE-SAGA-004, EE-PG-006, EE-NFR-008 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-07 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-EVT-007, EE-PG-005, EE-PG-006, EE-NFR-008 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |
| RB-08 | PASS | VR-DX-001, VR-DX-005, VR-DX-008, VR-LOCAL-001, EE-ACL-005, EE-SVC-018, EE-HTTP-006 | [JSON](evidence/reservation.json) / [relato](evidence/reservation.md) |

TD-06 composto comprova VR-DX-006 pela reprodução independente; as verificações da CLI comprovam VR-DX-007. O manifest bruto de TD-06-package preserva uma referência contextual a VR-LOCAL-002, que não representa evidência AWS de Todo; para Todo, AWS é N/A. A matriz acima corrige essa atribuição e Commerce fornece a evidência Moto aplicável.

Referências EE apontam ao catálogo versionado com origem; os cenários de domínio fornecem evidência aplicada, sem substituir a suíte geral de conformidade. AWS/Moto é N/A para Todo e Reservation; Commerce executa S3/Moto. Não houve smoke em AWS real.

## Evidências e limites

[Índice portátil de reprodução](evidence/reproduction/6282d09a-bb44-4181-9b45-6dca4f3c5378/index.json) contém 49 arquivos com SHA-256, logs de comandos e manifests/raw snapshots. O relatório mantém caminhos originais e acrescenta `exportedLog`, permitindo revisão fora do diretório temporário. Há transcripts HTTP/SSE, snapshots, migration/Storage IR, ledgers, compensações, hashes S3 e timelines de crash nos relatórios e artefatos de cada app.

[FRICTIONS.md](FRICTIONS.md) registra as correções e limites. Não há P0/P1 aberto ou pivô conceitual pendente. Permanecem P2 explícitos: normalização associativa de CHECK usa forma equivalente right-nested validada; CLI `--help` imprime Usage e sai com código 1; Moto perde objetos ao reiniciar e exige recriação; APIs sem CAS/clock genérico usam padrão declarado de domínio. [Migrações e starts repetidos](evidence/reservation-schema-start.json) comprovam o workaround de CHECK.

Implementadores consultaram source do core em alguns pontos e registraram essas consultas; a adoção independente usa pacote, documentação e código do consumidor, com zero consultas ao core. A tentativa de gate interrompida antes das correções está preservada em `evidence/framework/superseded-gate.log` e não integra o aceite. O workflow GitHub foi preparado; sua execução remota não foi realizada. Publicação pertence à fase seguinte.

## Reproduzir

Com Node 24.19.0 e Docker disponíveis:

```sh
npm run setup
npm run typecheck
npm test
npm run cleanup
```

`setup` remove os containers de dogfood anteriores e seus dados; não usa volumes persistentes. Cada README contém os comandos individuais de migração, execução e limpeza. O patch e seu validador permitem reconstruir o candidato sem depender de um commit local publicado.
