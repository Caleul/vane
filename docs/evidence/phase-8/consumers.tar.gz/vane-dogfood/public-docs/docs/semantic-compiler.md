# Semantic compiler boundary

Vane has a mandatory two-stage compiler:

1. `TypeScript DSL -> declarations -> Semantic IR`
2. `Semantic IR + ServiceConfiguration + profile -> materialization IRs`

Stage one is the executable specification. It preserves meaning and rejects an
invalid model without selecting a database, framework, protocol, queue,
credential, retry policy, or deployment topology. Those choices require a
`ServiceConfiguration` and belong to stage two.

## Public TypeScript DSL

`@lilka/vane` exports the decorators, member factories, and helpers accepted by the static parser.
The same API is checked by TypeScript fixtures, so examples cannot drift away
from the package surface.

```ts
import {
  Column,
  Entity,
  Event,
  Module,
  Rule,
  column,
  create,
  gt,
  input,
  optional,
} from "@lilka/vane";

@Entity()
class Subscription {
  id = Column({ type: "uuid", identity: true, generated: "uuid" });

  startDate = Column({ type: "date" });
  endDate = Column({ type: "date" });
  couponCode = Column({ type: "string", nullable: true });

  @Rule({ expression: gt(column("endDate"), column("startDate")) })
  EndsAfterStart() {}

  CreateSubscription = Event({
    input: {
      startDate: "date",
      endDate: "date",
      couponCode: optional("string"),
    },
    operation: create({
      startDate: input("startDate"),
      endDate: input("endDate"),
      couponCode: input("couponCode"),
    }),
  });
}

@Module({ entities: [Subscription] })
class Sales {}
```

The parser reads the TypeScript AST directly. It never imports, transpiles, or
executes the user's source. Declaration configuration must therefore consist of
inline objects and arrays, literal values, class identifiers, and recognized
helper calls. Spreads, shorthand properties, computed properties and arbitrary function calls
are rejected with source locations. Configuration variables are rejected, except
for the explicitly supported local named View declaration described below.

An Entity Event declares its owner mutation in the same static grammar. The
closed operations are `create`, `update`, `remove` (serialized as `delete`) and
`upsert`. Their value expressions may read declared inputs, literals and current
owner Columns; `add` and `subtract` provide atomic integer/decimal changes. The
operation cannot target another Entity, execute I/O or call an arbitrary
handler. This keeps instruction, execution and persisted change as one Event.

Column constraints include nullability, uniqueness, identity, reference,
generation, string length, numeric bounds, and static defaults. Contradictions
such as nullable identities, an incompatible generator, `minLength >
maxLength`, or generation combined with a default fail semantic compilation.

## Statically validated references

Column and Event factories return opaque semantic member types and preserve
their option contracts. Reference helpers require a class and a string name:

```ts
customerId = Column({ type: "uuid", references: reference(Customer, "id") });

field(Order, "customerId");
eventRef(Order, "Cancel");
event(Order, "Place", {
  compensateWith: eventRef(Order, "Cancel"),
});
```

TypeScript validates the helper shape, while the static compiler is authoritative
for member existence, ownership, and kind. This split is deliberate: TypeScript's
structural type system can copy an inferred value type with `typeof`, but cannot
prove that a property originated from a particular initializer expression. The
compiler reads that expression from the AST and rejects unknown, ordinary,
private, static, or wrong-kind members. The parser continues to understand the
earlier `Customer.id` and `Order.Place` forms for source compatibility, but the
helper form is the public grammar.

## Views and explicit relations

A View owns its query, never persists, and is the only successful public result
shape. Output types and nullability are inferred from projected Columns and
aggregates.

```ts
@View({
  input: { customerId: "uuid", limit: "integer" },
  output: {
    orderId: field(Order, "id"),
    customerName: field(Customer, "name"),
  },
  query: {
    root: Order,
    relations: {
      customer: relation(
        field(Order, "customerId"),
        field(Customer, "id"),
      ),
    },
    where: eq(field(Order, "customerId"), input("customerId")),
    orderBy: [desc(field(Customer, "name"))],
    pagination: { limit: input("limit") },
  },
})
class OrderDetails {}
```

Every relation must follow an actual Column reference, use compatible types,
and form one unique, acyclic path from the query root to each Entity. Vane does
not infer joins or choose between two instances of the same Entity.
Filters use typed Columns, declared inputs, literals, comparison operators, and
logical composition. Ordering and pagination remain ordered query properties.

`count`, `sum`, `avg`, `min`, and `max` are supported. Until grouping has its
own semantic vocabulary, a View cannot mix scalar and aggregate outputs or
order an aggregate-only result by an ungrouped Column. Rejection is preferable
to accidental SQL semantics.

## Inferred Event payloads and named View contracts

The public `EventInput`, `ViewInput` and `ViewOutput` type helpers infer consumer
payloads without duplicating interfaces. `EventInput` takes an **instance member**
type. `ViewInput` and `ViewOutput` take the named View declaration token; a class
decorator cannot change the TypeScript type of the class it decorates.

```ts
import {
  Column, Entity, Event, Module, View, create, eq, field, input,
  type EventInput, type ViewInput, type ViewOutput,
} from "@lilka/vane";

@Entity()
class Book {
  id = Column({ type: "uuid", identity: true });
  copies = Column({ type: "integer" });
  note = Column({ type: "string", nullable: true });

  Add = Event({
    input: { id: "uuid", copies: "integer" },
    operation: create({
      id: input("id"), copies: input("copies"),
    }),
  });
}

const BookCardContract = View({
  input: { id: "uuid" },
  output: {
    id: field(Book, "id"),
    copies: field(Book, "copies"),
    note: field(Book, "note"),
  },
  query: { root: Book, where: eq(field(Book, "id"), input("id")) },
});

@BookCardContract
class BookCard {}

@Module({ entities: [Book], views: [BookCard] })
class Books {}

type AddBook = EventInput<Book["Add"]>;
// { id: string; copies: number }
type CardInput = ViewInput<typeof BookCardContract>;
// { id: string }
type CardRow = ViewOutput<typeof BookCardContract>;
// { id: string; copies: number; note: string | null }
```

`ViewOutput` denotes **one row**, not the array returned by a View query.
Integer and decimal values infer `number`; string, UUID, date and datetime infer
`string`; booleans infer `boolean`; JSON infers the public `JsonValue` type.
Date/datetime are serialized values, not JavaScript `Date` objects. Optional
inputs are optional object properties. Nullable Columns include `null` in output.
`count` infers a nonnullable number; `sum`/`avg` infer `number | null`;
`min`/`max` retain the source value type and include `null` for an empty result.
These match the public View result representation; they do not promise arbitrary
precision beyond JavaScript numbers.

Named View declarations must be a preceding **top-level local `const`**, directly
initialized by the imported `View` helper with the same static inline options as
`@View(...)`. Explicit variable annotations, `let`/`var`, imported tokens,
chained aliases, callbacks and dynamically computed declarations are rejected.
The compiler resolves the initializer AST and never evaluates the token. Inline
`@View({...})` remains supported with identical semantics; use a named token only
when a consumer needs to extract its TypeScript input/output types.

Type inference does not establish semantic member provenance. Unknown or
ordinary properties may produce `unknown` at the TypeScript helper boundary;
the static compiler still rejects missing, copied-brand or wrong-kind members.
No structural type assertion can turn a regular property into a Column/Event.

## Anti-Corruption Layers and terminal outcomes

An ACL owns Events that interpret external results as `success` or `fail` but
does not define how the external system is reached. Result names and fields are
semantic; endpoints, protocols, credentials, status mappings, timeouts, retries,
and idempotency belong to `ServiceConfiguration`.

Every Entity and ACL Event records a common public terminal contract in the
Semantic IR: success can only be exposed as a View; fail requires a stable code,
a safe message, and correlation identity. The IR does not expose raw exceptions
or ACL payloads as public success responses.

## Sagas

A Saga is a causal DAG of Entity or ACL Events. Steps do not return awaited
intermediate values. Compensation references another known Event, every branch
converges on one terminal step, and only the final View or fail is visible.

```ts
@Saga({
  input: { orderId: "uuid" },
  steps: {
    place: event(Order, "Place", {
      compensateWith: eventRef(Order, "Cancel"),
    }),
    authorize: event(PaymentGateway, "Authorize", {
      causedBy: ["place"],
    }),
  },
  terminal: { step: "authorize", view: PaymentReceipt },
})
class PlaceOrder {}
```

The IR preserves causal identifiers, durable Saga state, terminal-only stream
visibility, and internal intermediate results. A later materializer decides how
to store and transport those guarantees.

## Module composition

Modules compose explicitly across source files:

```ts
@Module({ entities: [Customer] })
class Core {}

@Module({ imports: [Core], entities: [Order], views: [OrderDetails] })
class Sales {}
```

Use `compileProjectSources` for source files or `compileSemanticProject` for
declarations. The project compiler rejects unknown, duplicate, self, and cyclic
imports. Entity references, View relations, Saga Events, and terminal Views may
resolve through the transitive import graph. Same-named visible concepts are
rejected instead of selected by import order.

## Determinism and failure model

Declarations are normalized before serialization. Semantically equivalent
input order produces byte-identical output from `serializeSemanticIr` and
`serializeSemanticProjectIr`.

Validation is all-or-nothing. Failures contain a stable code, semantic path,
cause, likely correction, and source location when compiled from TypeScript.
No failure exposes a partial IR to a downstream materializer.

## Stage-two boundary

The following remain deliberately outside Semantic IR:

- database schemas, migrations, transactions, locks, and provider capability;
- HTTP, SSE, queues, serialization, status codes, and generated contracts;
- ACL endpoints, credentials, timeout, retry, and idempotency mappings;
- Saga storage engines, workers, schedules, and telemetry exporters;
- runtime framework and infrastructure topology.

They are not missing phase-one semantics. They are materialization decisions
that cannot be compiled correctly before `ServiceConfiguration` exists.
